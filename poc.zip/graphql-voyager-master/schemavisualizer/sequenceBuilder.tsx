import * as React from 'react';
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import { Dialog, DialogContent, } from '@material-ui/core';
import { TransitionProps } from '@material-ui/core/transitions';
// import CloseIcon from '@material-ui/icons/Close';
import DeleteOutlineIcon from '@material-ui/icons/DeleteOutline';
import QueryBuilderIcon from '@material-ui/icons/QueryBuilder';
import { AppBar, Toolbar } from '@material-ui/core';
import { List, ListItem, ListItemSecondaryAction, ListItemText, ListItemIcon } from '@material-ui/core';
import { Card, CardHeader, Grid, Slide, CardActions } from '@material-ui/core';
import UpdateIcon from '@material-ui/icons/Update';
import { Checkbox, TextField, Button, IconButton, Typography } from '@material-ui/core';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import InputAdornment from '@material-ui/core/InputAdornment';
import ListIcon from '@material-ui/icons/List';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';


const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        appBar: {
            position: 'relative',
        },
        title: {
            marginLeft: theme.spacing(2),
            flex: 1,
        },
        textFieldDropDown: {
            backgroundColor: "#FFFFFF",
            width: 270,
            height: 50,
            marginLeft: 20,
        },
        activityListDropDown: {
            backgroundColor: "#FFFFFF",
            width: 220,
            height: 30,
            marginTop: -7
        },
        taskListDropDown: {
            backgroundColor: "#FFFFFF",
            width: 175,
            height: 2,

        },
    }),
);


const activityList = {
    "activities": [
        {
            "activity_name": "SalesHub",
            "activity_desc": "Sales Hub",
            "user_interfaces": [
                {
                    "ui_name": "Sales Hub UI-1",
                    "ui_desc": "Sales Hub-1"
                },
                {
                    "ui_name": "Sales Hub UI-2",
                    "ui_desc": "Sales Hub-2"
                }
            ]
        },
        {
            "activity_name": "ManageTask",
            "activity_desc": "Mange Task",
            "user_interfaces": [
                {
                    "ui_name": "ImportSpec",
                    "ui_desc": "Import Specifications"
                },
            ]
        },
    ]
}

const taskNameMock = {
    "tasks": [
        {
            "name": "SAOmainscauthorLk",
            "desc": "Template Action for the Template im08",
            "type": "Link"
        },
        {
            "name": "SAOmainscauthorLk1",
            "desc": "Template Action for the Template im08",
            "type": "Link"
        },
        {
            "name": "SAOmainscauthorLk2",
            "desc": "Template Action for the Template im08",
            "type": "Link"
        },
        {
            "name": "SAOmainscauthorLk3",
            "desc": "Template Action for the Template im08",
            "type": "Link"
        },
        {
            "name": "SAOmainscauthorTr",
            "desc": "Authorize",
            "type": "Trans"
        },
        {
            "name": "SAOmainsccreateTr",
            "desc": "Create SO",
            "type": "Trans"
        },
        {
            "name": "SAOmainsccurrecHP",
            "desc": "Help on Currency",
            "type": "Help"
        },
        {
            "name": "SAOmainsccustoeUI",
            "desc": "On Enter of Customer",
            "type": "UI"
        }
    ]
};

const Transition = React.forwardRef(function Transition(
    props: TransitionProps & { children?: React.ReactElement },
    ref: React.Ref<unknown>,
) {
    return <Slide direction="up" ref={ref} {...props} />;
});

export default function SequenceBuilderDialog(props: any) {
    const { openTaskBuilderModel, showSequenceBuilder, taskSequenceList, getTaskParent, setErrorMsg, taskData } = props;
    const [framedQueryList, setFramedQueryList] = React.useState([]);
    const [draggedValue, setDraggedValue] = React.useState<any>({});
    const [droppedSequence, setDroppedSequence] = React.useState(1);
    const [updatedValue, setUpdatedValue] = React.useState<any>({});
    const [taskName, setTaskName] = React.useState<any>('');
    const [selectedActivityDescription, setSelectedActivityDescription] = React.useState<any>('');
    const [selectedUiDescription, setSelectedUiDescription] = React.useState<any>('');
    const [showTaskTable, setShowTaskTable] = React.useState<any>(false);
    const [selectedTaskRow, setSelectedTaskRow] = React.useState<any>({});
    const [taskDataList, setTaskDataList] = React.useState<any[]>(taskNameMock.tasks);
    const [activityDropDown, setActivityList] = React.useState<any[]>([]);
    const [uiList, setUiList] = React.useState<any[]>([]);
    const [taskParentObject, setTaskParentObject] = React.useState<any>({});
    const [taskTypeList, setTaskTypeList] = React.useState<any>([]);
    const ttlOption = ['short', 'medium', 'long'];

    const classes = useStyles();
    const handleClose = () => {
        openTaskBuilderModel();
    };

    const handleParentSave = () => {
        frameTaskParentObject()

    };

    React.useEffect(() => {
        if (framedQueryList.length == 0) {
            setDroppedSequence(1);
        } else {
            setDroppedSequence(framedQueryList.length + 1);
        }

    }, [framedQueryList]);

    React.useEffect(() => {
        if (getTaskParent(taskParentObject)) {
            openTaskBuilderModel();
        };
    }, [taskParentObject]);


    React.useEffect(() => {
        if (taskData) {
            setTaskParentObject(taskData);
        }
    }, [taskData]);


    React.useEffect(() => {
        setTaskName('');
        setFramedQueryList([]);
    }, [taskTypeList]);


    React.useEffect(() => {
        if (uiList.length != 0) {
            setSelectedUiDescription(uiList[0].ui_desc);
        }
    }, [uiList]);



    React.useEffect(() => {
        if (showSequenceBuilder && activityList && activityList.activities.length != 0) {
            setActivityList(activityList.activities);
            setUiList(activityList.activities[0].user_interfaces);
            setSelectedActivityDescription(activityList.activities[0].activity_desc);
            setSelectedUiDescription(activityList.activities[0].user_interfaces[0].ui_desc);
            setTaskDataList([...taskNameMock.tasks]);
        }
        if (!showSequenceBuilder) {
            setTaskParentObject({});
            setTaskTypeList([]);
            setUpdatedValue({});
            setDraggedValue({});
            setFramedQueryList([]);
            setDroppedSequence(0);
            setTaskName('');
            setSelectedActivityDescription('');
            setSelectedUiDescription('');
            setShowTaskTable(false);
            setSelectedTaskRow({});
            setTaskDataList([]);
            setActivityList([]);
            setUiList([]);
        }

    }, [showSequenceBuilder])



    const handleDragStart = (e, value) => {
        console.log("handleDragStart", e);
        setDraggedValue(value);
    }


    const handleDragOver = (e) => {
        e.preventDefault();
    }


    const frameTaskParentObject = () => {
        var framedTypeList = [];
        var inserted = false;
        if (taskData && taskData.tasks.length != 0 && taskTypeList.length != 0) {
            var parentTask = taskData.tasks
            var newlyAddedTask = [];
            for (var i = 0; i < taskTypeList.length; i++) {
                for (var j = 0; j < parentTask.length; j++) {
                    if (parentTask[j].name == taskTypeList[i].name) {
                        parentTask[j].queries = taskTypeList[i].queries;
                        inserted = true;
                        break;
                    }
                }

            };
            newlyAddedTask = taskTypeList;
            const searchIndex = (value)=>{
                var taskIndex :any
                 newlyAddedTask.map((task,index)=>{
                    if(task.name == value){
                        taskIndex =  index;
                    }
                })
            
                return taskIndex;
            }
            if (inserted) {
                parentTask.forEach((edited) => {
                    taskTypeList.forEach(element => {
                        if (edited.name == element.name) {
                            var removalIndex = searchIndex(edited.name)
                            newlyAddedTask.splice(removalIndex, 1);
                        }
                    });
                })
                console.log("uniqueChars", newlyAddedTask);
                parentTask = [...parentTask, ...newlyAddedTask];
            }
            else {
                parentTask = [...parentTask, ...taskTypeList];
            }
            framedTypeList = parentTask;
        }
        else {
            framedTypeList = taskTypeList
        }

        framedTypeList = framedTypeList.filter((tasks)=>{
            if(tasks.queries.length!==0){
                return  tasks
            }
        })

        var tempTaskObj = {
            "customer": "ramco",
            "project": "Systesting",
            "changeRequest": " SAO_ECR_00033",
            "processDescription": "Sales and Shipping",
            "componentDescription": "Sales Order",
            "activityDescription": selectedActivityDescription,
            "uiDescription": selectedUiDescription,
            "tasks": framedTypeList,
        }
        console.log("tempTaskObj", tempTaskObj);
        console.log("taskParentObject", taskParentObject);
        console.log("task", taskData);
        setTaskParentObject({ ...tempTaskObj })



    }



    const handleDrop = (e) => {
        try {
            e.preventDefault();
            if (Object.keys(draggedValue).length != 0) {
                var tempObj = {
                    "queryName": draggedValue.queryName,
                    "version": draggedValue.version,
                    "type": draggedValue.type,
                    "sequence": droppedSequence,
                    "alias": "",
                    "iscached": false,
                    "ttl": "",
                    "args": [],
                    "inputFields": [],
                    "fields": []
                }
                console.log("framedQueryList", framedQueryList);
                setFramedQueryList([...framedQueryList, tempObj]);
                setDraggedValue({});
            }

        } catch (error) {
            handleError(error.message);
        }



    }

    const handleError = (errorMsg: any) => {
        if (errorMsg != '') {
            setErrorMsg(errorMsg);
        }

    }


    const handleDelete = (index) => {
        try {
            var tempList = framedQueryList;
            if (Object.keys(updatedValue).length != 0 && index == updatedValue.index) {
                setFramedQueryList([...framedQueryList]);
            } else {
                tempList.splice(index, 1);
                setFramedQueryList([...tempList]);
            }
            setUpdatedValue({});

        } catch (error) {
            handleError(error.message)
        }

    };


 

    const handleUpdate = (index, item) => {
        try {
            if (Object.keys(item).length != 0) {
                item.index = index;
                setUpdatedValue({ ...item });
            }
        } catch (error) {
            handleError(error.message);
        }

    }


    const handleChange = (e, row) => {
        console.log("e", e);
        row.iscached = !row.iscached;
        setUpdatedValue({ ...row });
    }

    const handleTTL = (e, row) => {
        row.ttl = e.target.value;
        setUpdatedValue({ ...row });
    };
    const handleAlias = (e, row) => {
        row.alias = e.target.value;
        setUpdatedValue({ ...row });
    };
    const handleSequence = (e, row) => {
        try {
            row.sequence = (e.target.value <= framedQueryList.length && e.target.value > 1) ? e.target.value : 1;
            setUpdatedValue({ ...row });

        } catch (error) {
            handleError(error.message);
        }

    };

    const handleSave = () => {
        try {
            var tempList = framedQueryList;
            var sequenceArrangeList = [];
            var tempUpdatedRow = updatedValue;
            if (tempList.length != 0 && Object.keys(tempUpdatedRow).length != 0) {
                tempList[tempUpdatedRow.index] = tempUpdatedRow;
                tempList.map((item: any) => {
                    sequenceArrangeList.splice(item.sequence - 1, 0, item);
                })
                setFramedQueryList([...sequenceArrangeList]);
                setUpdatedValue({});
            }

        } catch (error) {
            handleError(error.message);
        }


    }


    const handleSaveTask = () => {
        try {
            if ( Object.keys(selectedTaskRow).length != 0 && selectedTaskRow.name != '') {
                var filteredList = [];
                var tempTaskObj = {
                    "name": selectedTaskRow.name,
                    "type": selectedTaskRow.type,
                    "desc": selectedTaskRow.desc,
                    "queries": framedQueryList,
                };
                var tempList = [...taskTypeList];

                filteredList = tempList.filter((item: any) => {
                    return item.name !== selectedTaskRow.name
                })

                filteredList.push(tempTaskObj);
                setTaskTypeList([...filteredList]);
                setSelectedTaskRow({});
            }

        } catch (error) {
            handleError(error.message);
        }



    }




    const renderDraggerQueryList = () => {
        return (
            <List>
                {
                    taskSequenceList.map((taskItem: any, index: any) => {
                        return (<ListItem button key={index} >
                            <ListItemIcon>
                                <QueryBuilderIcon />
                            </ListItemIcon>
                            <ListItemText draggable="true"
                                onDragStart={(e) => handleDragStart(e, taskItem)} primary={taskItem.queryName}
                            />
                        </ListItem>)
                    })
                }

            </List>

        )
    }

    const renderFramedQueryList = () => {
        if (framedQueryList.length != 0) {
            return (
                <List >
                    {
                        framedQueryList.map((taskItem: any, index: any) => {
                            return (<ListItem button key={index}>
                                <ListItemIcon onClick={() => handleDelete(index)}>
                                    <DeleteOutlineIcon />
                                </ListItemIcon>
                                <ListItemText primary={taskItem.queryName}
                                />
                                <ListItemSecondaryAction>
                                    <IconButton edge="end" aria-label="update" onClick={() => handleUpdate(index, taskItem)}>
                                        <UpdateIcon />
                                    </IconButton>
                                </ListItemSecondaryAction>
                            </ListItem>)
                        })
                    }

                </List>

            )
        }

    };

    const onSelectTask = (row) => {
        console.log("row", row);
        console.log("taskTypeList", taskTypeList);
        console.log("taskData", taskData);
        console.log("taskParentObject", taskParentObject);
        var tempList = [...taskTypeList];
        if (taskData && taskData.tasks.length != 0) {
            var parentTaskList = taskData.tasks;
            parentTaskList.map((parentTaskItem: any) => {
                if (parentTaskItem.name == row.name) {
                    var parentQueryList = parentTaskItem.queries;
                    setFramedQueryList([...parentQueryList]);
                }

            })
        }
        if (tempList.length != 0 && framedQueryList.length == 0) {
            tempList.map((taskItem: any) => {
                if (taskItem.name == row.name) {
                    var tempQueryList = taskItem.queries;
                    setFramedQueryList([...tempQueryList]);
                }

            })
        }
        setSelectedTaskRow(row);
        setShowTaskTable(false);
        setTaskName(row.name);
        setTaskDataList([...taskNameMock.tasks]);
    }


    const selectActivityDescription = (value) => {
        setSelectedActivityDescription(value);
        var tempUiList = activityDropDown.filter((item) => {
            if (item.activity_desc == value) {
                return item
            }
        })
        var uiList = tempUiList.length != 0 ? tempUiList[0].user_interfaces : [];
        setUiList([...uiList]);
    }

    const selectUiDescription = (uiValue) => {
        setSelectedUiDescription(uiValue);
    }

    const requestSearch = (searchedVal: string) => {
        try {
            setTaskName(searchedVal);
            if (searchedVal != '') {
                if (Array.isArray(taskDataList) && taskDataList.length != 0) {
                    var a = undefined;
                    const filteredRows = a.filter((row) => {
                        if (row.name && row.name != '' && row.name.toLowerCase().includes(searchedVal.toLowerCase())
                            || row.desc && row.desc != '' && row.desc.toLowerCase().includes(searchedVal.toLowerCase())
                            || (row.type && row.type != '' && row.type.toLowerCase().includes(searchedVal.toLowerCase()))) {
                            return row;
                        }
                    });
                    if (filteredRows.length != 0) {
                        setTaskDataList([...filteredRows]);
                    } else {
                        setTaskDataList([...taskNameMock.tasks]);
                    }

                }
            } else {
                setTaskDataList([...taskNameMock.tasks]);
                setSelectedTaskRow({});
            }

        } catch (error) {
            handleError(error.message);

        }



    };


    const renderPrimeTable = () => {
        return (
            <>
                <DataTable value={taskDataList} resizableColumns selectionMode="single" onSelectionChange={e => onSelectTask(e.value)} dataKey="id"
                    scrollable scrollHeight="400px">
                    <Column field="name" header="Task Name"></Column>
                    <Column field="desc" header="Task Description" style={{ width: '40%' }}></Column>
                    <Column field="type" header="Task Type" style={{ width: '40%' }}></Column>
                </DataTable>
            </>
        )

    }



    const handleClickShowTaskTable = () => {
        setShowTaskTable(!showTaskTable);
    }


    const renderPropertyChange = (row) => {
        return (
            <Grid
                container
                direction="column"
                justifyContent="center"
                alignItems="center"
            >
                <Grid container item xs={12} style={{ marginBottom: 20 }} >
                    <Grid item xs={3} style={{ marginLeft: 7 }} >
                        <Typography variant="body1" >
                            Query Name:
                        </Typography>
                    </Grid>
                    <Grid item xs={7} style={{ marginTop: -8 }}>
                        <TextField id="outlined-queryName" disabled value={row.queryName} variant="outlined" style={{ width: 300 }} />
                    </Grid>
                </Grid>
                <Grid container item xs={12} style={{ marginBottom: 20 }}>
                    <Grid item xs={3} style={{ marginLeft: 7 }}>
                        <Typography variant="body1"  >
                            version:
                        </Typography>
                    </Grid>
                    <Grid item xs={7} style={{ marginTop: -8 }}>
                        <TextField id="outlined-version" disabled value={row.version} variant="outlined" style={{ width: 300 }} />
                    </Grid>
                </Grid>
                <Grid container item xs={12} style={{ marginBottom: 20 }}>
                    <Grid item xs={3} style={{ marginLeft: 7 }}>
                        <Typography variant="body1"  >
                            Type:
                        </Typography>
                    </Grid>
                    <Grid item xs={7} style={{ marginTop: -8 }}>
                        <TextField id="outlined-version" disabled value={row.type} variant="outlined" style={{ width: 300 }} />
                    </Grid>
                </Grid>
                <Grid container item xs={12} style={{ marginBottom: 20 }}>
                    <Grid item xs={3} style={{ marginLeft: 7 }} >
                        <Typography variant="body1" >
                            Sequence:
                        </Typography>
                    </Grid>
                    <Grid item xs={7} style={{ marginTop: -8 }}>
                        <TextField id="outlined-sequence" type='number' value={row.sequence} variant="outlined" onChange={(e) => handleSequence(e, row)} style={{ width: 300 }} />
                    </Grid>
                </Grid>
                <Grid container item xs={12} style={{ marginBottom: 20 }}>
                    <Grid item xs={3} style={{ marginLeft: 8 }} >
                        <Typography variant="body1" className={classes.title}>
                            Alias:
                        </Typography>
                    </Grid>
                    <Grid item xs={7} style={{ marginTop: -8 }}>
                        <TextField id="outlined-alias" value={row.alias} variant="outlined" style={{ width: 300 }} onChange={(e) => handleAlias(e, row)} />
                    </Grid>
                </Grid>
                <Grid container item xs={12} style={{ marginBottom: 20 }}>
                    <Grid item xs={3} >
                        <Typography variant="body1" className={classes.title}>
                            catched:
                        </Typography>
                    </Grid>
                    <Grid item xs={7}>
                        <Checkbox
                            checked={row.iscached}
                            onChange={(e) => handleChange(e, row)}
                            color="primary"
                            inputProps={{ 'aria-label': 'primary checkbox' }}
                        />
                    </Grid>
                </Grid>
                <Grid container item xs={12} style={{ marginBottom: 20 }}>
                    <Grid item xs={3} style={{ marginTop: 17, marginLeft: 8 }}>
                        <Typography variant="body1" className={classes.title}>
                            TTL:
                        </Typography>
                    </Grid>
                    <Grid item xs={7} style={{ marginTop: -8, marginLeft: -19 }}>
                        <TextField
                            select
                            value={row.ttl}
                            margin='dense'
                            onChange={(e) => handleTTL(e, row)}
                            InputProps={{ className: classes.textFieldDropDown }}
                            SelectProps={{
                                native: true,
                            }}
                            variant="outlined"
                        >
                            {ttlOption.map((item: any, index: any) => (
                                <option key={index} value={item}>
                                    {item}
                                </option>
                            ))}
                        </TextField>
                    </Grid>
                </Grid>
                <Grid container item xs={12} style={{ marginBottom: 20 }}>
                    <Grid item xs={6} style={{ marginLeft: 125 }}>
                        <Button variant="contained" color="primary" onClick={handleSave}>
                            save
                        </Button>
                    </Grid>
                    <Grid item xs={6} style={{ marginLeft: 215, marginTop: -32 }}>
                        <Button variant="contained" color="primary" onClick={() => setUpdatedValue({})}>
                            close
                        </Button>
                    </Grid>

                </Grid>



            </Grid>
        )

    }

    return (
        <div>
            <Dialog fullScreen open={showSequenceBuilder} onClose={handleClose} TransitionComponent={Transition}>
                <AppBar className={classes.appBar}>
                    <Toolbar>

                        <Typography variant="h6" className={classes.title}>
                            Sequence Builder
                        </Typography>
                        <Button autoFocus color="inherit" onClick={handleParentSave}>
                            Save
                        </Button>
                        <Button autoFocus color="inherit" onClick={handleClose}>
                            Close
                        </Button>
                    </Toolbar>
                </AppBar>
                <DialogContent dividers>
                    <div>
                        <Grid container component={Card} style={{ backgroundColor: '#e9d6eb' }}>
                            <Grid container item xs={12} style={{ padding: 15 }}>
                                <Grid container item xs={4} >
                                    <Grid item xs={3} >
                                        <Typography variant="h6" >
                                            Customer
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={3} style={{ marginTop: 5 }}>
                                        <Typography variant="body1" >
                                            ramco
                                        </Typography>
                                    </Grid>

                                </Grid>
                                <Grid container item xs={3} >
                                    <Grid item xs={3} >
                                        <Typography variant="h6" >
                                            Project
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={3} style={{ marginTop: 5 }}>
                                        <Typography variant="body1" >
                                            Systesting
                                        </Typography>
                                    </Grid>

                                </Grid>
                                <Grid container item xs={3} >
                                    <Grid item xs={9} >
                                        <Typography variant="h6" >
                                            Engineering change Request
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={3} style={{ marginTop: 5 }}>
                                        <Typography variant="body1" >
                                            SAO_ECR_00033
                                        </Typography>
                                    </Grid>

                                </Grid>


                            </Grid>
                            <Grid container item xs={12} style={{ padding: 15 }}>
                                <Grid container item xs={3} >
                                    <Grid item xs={6} >
                                        <Typography variant="h6" >
                                            Process Description
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={6} style={{ marginTop: 5 }}>
                                        <Typography variant="body1" >
                                            Sales and Shipping
                                        </Typography>
                                    </Grid>

                                </Grid>
                                <Grid container item xs={3} style={{ marginLeft: 105 }} >
                                    <Grid item xs={7} >
                                        <Typography variant="h6" >
                                            Component Description
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={3} style={{ marginTop: 5 }}>
                                        <Typography variant="body1" >
                                            Sales Order
                                        </Typography>
                                    </Grid>

                                </Grid>



                            </Grid>
                            <Grid container item xs={12} style={{ padding: 15 }}>
                                <Grid container item xs={3} >
                                    <Grid item xs={6} >
                                        <Typography variant="h6" >
                                            Activity Description
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={6} style={{ marginTop: 5 }}>
                                        <TextField
                                            select
                                            value={selectedActivityDescription}
                                            margin='dense'
                                            onChange={(event) => selectActivityDescription(event.target.value)}
                                            InputProps={{ className: classes.activityListDropDown }}
                                            SelectProps={{
                                                native: true,
                                            }}
                                            variant="outlined"
                                        >
                                            <option aria-label="None" value="" disabled />
                                            {
                                                activityDropDown.map((activity: any) => (

                                                    <option value={activity.activity_desc}>
                                                        {activity.activity_desc}
                                                    </option>


                                                ))}
                                        </TextField>
                                    </Grid>

                                </Grid>
                                <Grid container item xs={3} style={{ marginLeft: 105 }} >
                                    <Grid item xs={7} >
                                        <Typography variant="h6" >
                                            UI Description
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={3} style={{ marginTop: 5 }}>
                                        <TextField
                                            select
                                            value={selectedUiDescription}
                                            margin='dense'
                                            onChange={(event) => selectUiDescription(event.target.value)}
                                            InputProps={{ className: classes.activityListDropDown }}
                                            SelectProps={{
                                                native: true,
                                            }}
                                            variant="outlined"
                                        >
                                            <option aria-label="None" value="" disabled />
                                            {uiList.map((uiItem: any) => (
                                                <option value={uiItem.ui_desc}>
                                                    {uiItem.ui_desc}
                                                </option>
                                            ))}
                                        </TextField>
                                    </Grid>

                                </Grid>



                            </Grid>
                            <Grid container item xs={12} style={{ padding: 15 }}>
                                <Grid container item xs={6} >
                                    <Grid item xs={2} >
                                        <Typography variant="h6" >
                                            Task Name
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={10} style={{ marginTop: -25, marginLeft: 160 }}>
                                        <OutlinedInput
                                            id="outlined-adornment-password"
                                            type={'text'}
                                            value={taskName}
                                            onChange={(e) => requestSearch(e.target.value)}
                                            inputProps={{ className: classes.taskListDropDown }}
                                            endAdornment={
                                                <InputAdornment position="end">
                                                    <IconButton
                                                        aria-label="toggle password visibility"
                                                        onClick={handleClickShowTaskTable}
                                                        edge="end"
                                                    >
                                                        <ListIcon />
                                                    </IconButton>
                                                </InputAdornment>
                                            }
                                        />
                                        {showTaskTable && renderPrimeTable()}
                                    </Grid>

                                </Grid>

                                <Grid container item xs={3} style={{ marginLeft: -220 }}  >
                                    <Grid item xs={6} >
                                        <Typography variant="h6" >
                                            Task Description
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={6} style={{ marginTop: 5 }}>
                                        <Typography variant="body1" >
                                            {selectedTaskRow.desc || ''}
                                        </Typography>
                                    </Grid>

                                </Grid>
                                <Grid container item xs={3}>
                                    <Grid item xs={4} >
                                        <Typography variant="h6" >
                                            Task Type
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={3} style={{ marginTop: 5 }}>
                                        <Typography variant="body1" >
                                            {selectedTaskRow.type || ''}
                                        </Typography>
                                    </Grid>

                                </Grid>





                            </Grid>
                        </Grid>
                    </div>
                    {taskName != '' && Object.keys(selectedTaskRow).length != 0 && <div style={{ paddingTop: 15 }}>
                        <Grid container spacing={3}>
                            <Grid item xs>
                                {taskSequenceList.length != 0 && <Card >
                                    <CardHeader
                                        title="Drag Zone"
                                    />
                                    {renderDraggerQueryList()}
                                </Card>
                                }
                            </Grid>
                            <Grid item xs>
                                {
                                    <div id='target'
                                        onDragOver={handleDragOver}
                                        onDrop={handleDrop} >
                                        <Card>
                                            <CardHeader
                                                title="Drop Zone"
                                            />

                                            {renderFramedQueryList()}
                                            { <CardActions>
                                                <Button size="large"
                                                    style={{ color: 'white', marginLeft: 100, background: 'black' }}
                                                    variant='outlined'
                                                    onClick={handleSaveTask}>Save</Button>
                                                  
                                            </CardActions>}

                                        </Card>

                                    </div>
                                }
                            </Grid>
                            <Grid item xs>{
                                Object.keys(updatedValue).length != 0 && framedQueryList.length != 0 && <Card>
                                    <CardHeader
                                        title="Property Change"
                                    />

                                    {renderPropertyChange(updatedValue)}


                                </Card>
                            }

                            </Grid>
                        </Grid>
                    </div>}
                </DialogContent>


            </Dialog>
        </div>
    );
}
