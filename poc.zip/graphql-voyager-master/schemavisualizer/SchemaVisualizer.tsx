import * as React from 'react';
import { MuiThemeProvider } from '@material-ui/core/styles';

import { theme } from '../src/components/MUITheme';
import { GraphQLVoyager } from '../src';

import Button from '@material-ui/core/Button';
import SequenceBuilderDialog from './sequenceBuilder';



import './components.css';

function SchemaVisualizer(props: any) {
  const { introspectionQuery, taskObject, queryMappingObject, controlIdList, taskSequenceList } = props;
  const [introspection, setIntrospection] = React.useState(introspectionQuery || {});
  const [taskObj, setTaskObject] = React.useState(taskObject || {});
  const [queryMapping, setQueryMappingObject] = React.useState(queryMappingObject || {});
  const [listOfControlId, setListOfControlId] = React.useState(controlIdList || []);
  const [showSequenceBuilder, setShowSequenceBuilder] = React.useState(false);
  const [errorMsg, setErrorMsg] = React.useState('');



  React.useEffect(() => {
    setIntrospection(introspectionQuery);
    setTaskObject(taskObj);
    console.log("!!queryMapping",queryMapping);
    console.log("!!taskObj",taskObj);
    setQueryMappingObject(queryMapping);
    setListOfControlId(listOfControlId)
  }, [introspectionQuery, taskObj, queryMapping, listOfControlId]);


  React.useEffect(() => {
    const { url, withCredentials } = getQueryParams();
    if (url) {
      const introspectionFun: any = (introspectionQuery) => fetch(url, {
        method: 'post',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ query: introspectionQuery }),
        ...(withCredentials === 'true'
          ? { credentials: 'include', mode: 'cors' }
          : {}),
      }
      ).then((response) => response.json());
      setIntrospection(introspectionFun);
    }
  });

  React.useEffect(() => {
   if(errorMsg!=''){
    openTaskBuilderModel();
   }
  }, [errorMsg]);


  const openTaskBuilderModel = () => {
    setShowSequenceBuilder(!showSequenceBuilder);
    setErrorMsg('');
  }

  const getTaskParent = (value:any) =>{
    console.log("value",value);
    console.log("taskObj",taskObj);
    if (Object.keys(value).length != 0){
      // var tempObj = taskObj;
      // var tasks = value.tasks;
      // tempObj = {...tempObj,...value};
      // tempObj.tasks = tasks;
      setTaskObject({...value});
      return true;
    }
    return false;
  }


  return (
    <MuiThemeProvider theme={theme}>
      <GraphQLVoyager introspection={introspection} taskObject={taskObj} queryMappingObject={queryMapping} controlIdList={listOfControlId} setTaskObject={setTaskObject} setQueryMappingObject={setQueryMappingObject} 
      sequenceErrorMsg={errorMsg}>
        <GraphQLVoyager.PanelHeader>
          <div className="voyager-panel">
            <div className="voyager-logo">
              <a>
                <div className="logo">
                  <h2 className="title">
                  <strong>Schema</strong> Visualizer
                  </h2>
                </div>
              </a>
            </div>
            <Button
              color="primary"
              style={{ color: 'white' }}
              variant="contained"
              className="choosebutton"
              onClick={openTaskBuilderModel}
            >
              Task Builder
            </Button>

          </div>
        </GraphQLVoyager.PanelHeader>
       
      </GraphQLVoyager>
    
      <SequenceBuilderDialog openTaskBuilderModel={openTaskBuilderModel} showSequenceBuilder={showSequenceBuilder} taskSequenceList={taskSequenceList} getTaskParent={getTaskParent}
      taskData={taskObj}
      setErrorMsg={setErrorMsg}/>
    </MuiThemeProvider>
  );
}


function getQueryParams(): { [key: string]: string } {
  const query = window.location.search.substring(1);
  const params = {};

  for (const param of query.split('&')) {
    const [key, value] = param.split('=');
    params[key] = value ? decodeURIComponent(value.replace(/\+/g, ' ')) : '';
  }
  return params;
}

export default SchemaVisualizer;




