import * as React from 'react';
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import { Card, Grid, TextField } from '@material-ui/core';
import { IconButton, Typography, Button } from '@material-ui/core';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import InputAdornment from '@material-ui/core/InputAdornment';
import ListIcon from '@material-ui/icons/List';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Panel } from 'primereact/panel';
// 
const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        appBar: {
            position: 'relative',
        },
        title: {
            marginLeft: theme.spacing(2),
            flex: 1,
        },
        textFieldDropDown: {
            backgroundColor: "#FFFFFF",
            width: 270,
            height: 50,
            marginLeft: 20,
        },
        queryListDropDown: {
            backgroundColor: "#FFFFFF",
            width: 365,
            height: 30,
            // marginTop: -7
        },
        taskListDropDown: {
            backgroundColor: "#FFFFFF",
            width: 175,
            height: 2,

        },
    }),
);









export default function TaskBuilder(props: any) {

    var { taskData, setQueryMappingObject,renderErrorDialog } = props;
    const [taskName, setTaskName] = React.useState<any>('');

    const [showTaskTable, setShowTaskTable] = React.useState<any>(false);
    const [selectedTaskRow, setSelectedTaskRow] = React.useState<any>({});
    const [taskDataList, setTaskDataList] = React.useState<any[]>([]);
    const [queryList, setQueryList] = React.useState<any[]>([]);
    const [selectedQuery, setSelectedQuery] = React.useState<any>({});
    const [collapsedFlag, setCollapsedFlag] = React.useState<boolean>(false);


    console.log("taskData", taskData);



    const classes = useStyles();


    React.useEffect(() => {
        if (taskData && Object.keys(taskData).length != 0 && taskData.tasks.length != 0) {
            setTaskDataList([...taskData.tasks]);
            setTaskName('');

        }
    }, [taskData]);

    React.useEffect(() => {
        if (queryList.length != 0) {
            console.log("queryList",queryList);
            setSelectedQuery(queryList[0]);
        }
    }, [queryList]);

    React.useEffect(() => {
        if (taskName ==='' && queryList.length != 0) {
            setSelectedQuery({});
            setQueryList([]);
        }
    }, [taskName]);





    React.useEffect(() => {
        if (Object.keys(selectedTaskRow).length != 0 && selectedTaskRow.queries.length != 0) {
            console.log("@@",selectedTaskRow);
            console.log("@@Q",selectedTaskRow.queries)
            setQueryList([...selectedTaskRow.queries]);

        }
    }, [selectedTaskRow]);





    const onSelectTask = (row) => {
        console.log("row", row);
        setSelectedTaskRow({...row});
        setShowTaskTable(false);
        setTaskName(row.name);
        setTaskDataList([...taskData.tasks]);
    }

    const selectQuery = (event: any) => {
        try {
            console.log("row", event.target.value);
            var value = event.target.value;
            if (value != '') {
                var queryStringList = value.split("::")
                var queryValue = {
                    queryName: queryStringList[0],
                    sequence: queryStringList[1]
                }
                console.log("queryValue", queryValue);
                setSelectedQuery(queryValue);
            }
        } catch (error) {
            renderErrorDialog(true,error.message);
        }
       

    }




    const handleSaveQueryMap = () => {
        if (taskName != '' && selectedQuery && selectedQuery.queryName != '') {
            var queryObj = {
                "taskName": taskName,
                "queryName": selectedQuery.queryName,
                "sequence": selectedQuery.sequence
            }
            setQueryMappingObject(queryObj);
            setCollapsedFlag(true);
        }

    }




    const requestSearch = (searchedVal: string) => {
        try {
            setTaskName(searchedVal);
            if (searchedVal != '') {
                if (Array.isArray(taskDataList) && taskDataList.length != 0) {
                    const filteredRows = taskDataList.filter((row) => {
                        if (row.name && row.name != '' && row.name.toLowerCase().includes(searchedVal.toLowerCase())
                            || row.desc && row.desc != '' && row.desc.toLowerCase().includes(searchedVal.toLowerCase())
                            || (row.type && row.type != '' && row.type.toLowerCase().includes(searchedVal.toLowerCase()))) {
                            return row;
                        }
                    });
                    if (filteredRows.length != 0) {
                        setTaskDataList([...filteredRows]);
                    } else {
                        setTaskDataList([...taskData.tasks]);
                    }
    
                }
            } else {
                setTaskDataList([...taskData.tasks]);
                setSelectedTaskRow({});
            }
            
        } catch (error) {
            renderErrorDialog(true,error.message);
        }
       


    };


    const renderPrimeTable = () => {
        return (
            <>
                <DataTable value={taskDataList} resizableColumns selectionMode="single" onSelectionChange={e => onSelectTask(e.value)} dataKey="id"
                    scrollable scrollHeight="400px">
                    <Column field="name" header="Task Name"></Column>
                    <Column field="desc" header="Task Description" style={{ width: '40%' }}></Column>
                    <Column field="type" header="Task Type" style={{ width: '40%' }}></Column>
                </DataTable>
            </>
        )

    }



    const handleClickShowTaskTable = () => {
        setShowTaskTable(!showTaskTable);
    }




    return (
        <Panel header="Task Selector" toggleable collapsed={collapsedFlag} onToggle={(e) => setCollapsedFlag(e.value)} style={{ width: '77%', position: 'absolute', marginLeft: 320 }}>
            <div style={{ overflowY: 'scroll', height: 380 }}>
                <Grid container component={Card} style={{ backgroundColor: '#e9d6eb' }}>
                    <Grid container item xs={12} style={{ padding: 15 }}>
                        <Grid container item xs={4} >
                            <Grid item xs={3} >
                                <Typography variant="h6" >
                                    Customer
                                </Typography>
                            </Grid>
                            <Grid item xs={3} style={{ marginTop: 5 }}>
                                <Typography variant="body1" >
                                    {taskData.customer || ''}
                                </Typography>
                            </Grid>

                        </Grid>
                        <Grid container item xs={3} >
                            <Grid item xs={3} >
                                <Typography variant="h6" >
                                    Project
                                </Typography>
                            </Grid>
                            <Grid item xs={3} style={{ marginTop: 5 }}>
                                <Typography variant="body1" >
                                {taskData.project || ''}
                                </Typography>
                            </Grid>

                        </Grid>
                        <Grid container item xs={3} >
                            <Grid item xs={9} >
                                <Typography variant="h6" >
                                    Engineering change Request
                                </Typography>
                            </Grid>
                            <Grid item xs={3} style={{ marginTop: 5 }}>
                                <Typography variant="body1" >
                                {taskData.changeRequest || ''}
                                </Typography>
                            </Grid>

                        </Grid>


                    </Grid>
                    <Grid container item xs={12} style={{ padding: 15 }}>
                        <Grid container item xs={6} >
                            <Grid item xs={4} >
                                <Typography variant="h6" >
                                    Process Description
                                </Typography>
                            </Grid>
                            <Grid item xs={3} style={{ marginTop: 5, marginLeft: 10 }}>
                                <Typography variant="body1" >
                                {taskData.processDescription || ''}
                                </Typography>
                            </Grid>

                        </Grid>
                        <Grid container item xs={6} style={{ marginLeft: 328, marginTop: -27 }} >
                            <Grid item xs={6} >
                                <Typography variant="h6" >
                                    Component Description
                                </Typography>
                            </Grid>
                            <Grid item xs={3} style={{ marginTop: 5, marginLeft: 10 }}>
                                <Typography variant="body1" >
                                {taskData.componentDescription || ''}
                                </Typography>
                            </Grid>

                        </Grid>



                    </Grid>
                    <Grid container item xs={12} style={{ padding: 15 }}>
                        <Grid container item xs={6} >
                            <Grid item xs={4} >
                                <Typography variant="h6" >
                                    Activity Description
                                </Typography>
                            </Grid>
                            <Grid item xs={6} style={{ marginTop: 5, marginLeft: 10 }}>
                                <Typography variant="body1" >
                                {taskData.activityDescription || ''}
                                </Typography>
                            </Grid>

                        </Grid>
                        <Grid container item xs={6} style={{ marginLeft: 330, marginTop: -25 }} >
                            <Grid item xs={4} >
                                <Typography variant="h6" >
                                    UI Description
                                </Typography>
                            </Grid>
                            <Grid item xs={4} style={{ marginTop: 5, marginLeft: 10 }}>
                                <Typography variant="body1" >
                                {taskData.uiDescription || ''}
                                </Typography>
                            </Grid>

                        </Grid>



                    </Grid>
                    <Grid container item xs={12} style={{ padding: 15 }}>
                        <Grid container item xs={6} >
                            <Grid item xs={3} >
                                <Typography variant="h6" >
                                    Task Name
                                </Typography>
                            </Grid>
                            <Grid item xs={9} >
                                <OutlinedInput
                                    id="outlined-adornment-password"
                                    type={'text'}
                                    value={taskName}
                                    onChange={(e) => requestSearch(e.target.value)}
                                    inputProps={{ className: classes.taskListDropDown }}
                                    endAdornment={
                                        <InputAdornment position="end">
                                            <IconButton
                                                aria-label="toggle password visibility"
                                                onClick={handleClickShowTaskTable}
                                                edge="end"
                                            >
                                                <ListIcon />
                                            </IconButton>
                                        </InputAdornment>
                                    }
                                />
                                {showTaskTable && renderPrimeTable()}
                            </Grid>

                        </Grid>
                        <Grid container item xs={6} >
                            <Grid item xs={3} >
                                <Typography variant="h6" >
                                    Query
                                </Typography>
                            </Grid>
                            <Grid item xs={9} >
                                <TextField
                                    
                                    select
                                    value={`${selectedQuery.queryName}::${selectedQuery.sequence}`}
                                    onChange={selectQuery}

                                    InputProps={{ className: classes.queryListDropDown }}

                                    SelectProps={{
                                        native: true,
                                    }}
                                    variant="outlined"
                                >
                                    <option aria-label="None" value="" disabled />
                                    {queryList.map((query: any) => (
                                        <option value={`${query.queryName}::${query.sequence}`} >
                                            {`${query.queryName}::${query.sequence}`}
                                        </option>
                                    ))}
                                </TextField>
                            </Grid>

                        </Grid>



                    </Grid>
                    <Grid container item xs={12} style={{ padding: 15 }}>
                        <Button size="large" style={{ color: 'white', marginLeft: 400, background: 'black' }} variant='outlined' onClick={handleSaveQueryMap}>Save</Button>
                    </Grid>
                </Grid>

            </div>
        </Panel>
    );
}
