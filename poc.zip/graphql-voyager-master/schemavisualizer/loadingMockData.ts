export const loadingData = {

"taskObject":{
    "tasks": [
      // {
      //   "name": "saomainsccreatetr",
      //   "type": "Trans",
      //   "queries": [
      //     {
      //       "name": "saleorder_SH_ScreenLaunch",
      //       "type": "Mutation",
      //       "version": "1.0.0",
      //       "sequence": "1",
      //       "args": [],
      //       "inputFields": [
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.categoryDesc",
      //           "control_id": "cmbcategory",
      //           "view_name": "cmbcategory",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.reqLocation",
      //           "control_id": "cmbreqlocation",
      //           "view_name": "cmbreqlocation",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.reqStatusDesc",
      //           "control_id": "cmbreqstatus",
      //           "view_name": "cmbreqstatus",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.reqStatusCode",
      //           "control_id": "cmbreqstatus",
      //           "view_name": "hhdnreqstatus",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.saleType",
      //           "control_id": "cmbsaletype",
      //           "view_name": "cmbsaletype",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.liveTrack",
      //           "control_id": "dlklivetrack",
      //           "view_name": "dlklivetrack",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.liveTrackingAll",
      //           "control_id": "dlklivetrackall",
      //           "view_name": "dlklivetrackall",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.liveTrackingChennai",
      //           "control_id": "dlklivetrackch",
      //           "view_name": "dlklivetrackch",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.liveTrackingDelhi",
      //           "control_id": "dlklivetrackdh",
      //           "view_name": "dlklivetrackdh",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.liveTrackingMumbai",
      //           "control_id": "dlklivetrackmb",
      //           "view_name": "dlklivetrackmb",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.rfqno",
      //           "control_id": "dsprfqno",
      //           "view_name": "dsprfqno",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.docType",
      //           "control_id": "grddetgrid",
      //           "view_name": "1",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.liveTrackingAll",
      //           "control_id": "grddetgrid",
      //           "view_name": "10",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.stockStatusCode",
      //           "control_id": "grddetgrid",
      //           "view_name": "1002",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.liveTrackingChennai",
      //           "control_id": "grddetgrid",
      //           "view_name": "11",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.liveTrackingMumbai",
      //           "control_id": "grddetgrid",
      //           "view_name": "12",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.liveTrackingDelhi",
      //           "control_id": "grddetgrid",
      //           "view_name": "13",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.authorized",
      //           "control_id": "grddetgrid",
      //           "view_name": "2",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.amendmentNo",
      //           "control_id": "grddetgrid",
      //           "view_name": "3",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.stockStatusDesc",
      //           "control_id": "grddetgrid",
      //           "view_name": "4",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.currentPosition",
      //           "control_id": "grddetgrid",
      //           "view_name": "5",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.availableStock",
      //           "control_id": "grddetgrid",
      //           "view_name": "6",
      //           "data_type": "Int",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.currentPositionTPL",
      //           "control_id": "grddetgrid",
      //           "view_name": "7",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.viewGR",
      //           "control_id": "grddetgrid",
      //           "view_name": "8",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.modeFlag",
      //           "control_id": "grddetgrid",
      //           "view_name": "modeflag",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.rowNo",
      //           "control_id": "grddetgrid",
      //           "view_name": "rowno",
      //           "data_type": "Int",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.itemCode",
      //           "control_id": "grditemgrid",
      //           "view_name": "1",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.orderType",
      //           "control_id": "grditemgrid",
      //           "view_name": "10",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.customerPoNo",
      //           "control_id": "grditemgrid",
      //           "view_name": "11",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.quoteNo",
      //           "control_id": "grditemgrid",
      //           "view_name": "12",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.currency",
      //           "control_id": "grditemgrid",
      //           "view_name": "13",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.itemImage",
      //           "control_id": "grditemgrid",
      //           "view_name": "2",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.itemDesc",
      //           "control_id": "grditemgrid",
      //           "view_name": "3",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.itemType",
      //           "control_id": "grditemgrid",
      //           "view_name": "7",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.itemPrice",
      //           "control_id": "grditemgrid",
      //           "view_name": "8",
      //           "data_type": "Int",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.itemRemarks",
      //           "control_id": "grditemgrid",
      //           "view_name": "9",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.modeFlag",
      //           "control_id": "grditemgrid",
      //           "view_name": "modeflag",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.rowNo",
      //           "control_id": "grditemgrid",
      //           "view_name": "rowno",
      //           "data_type": "Int",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.contextOu",
      //           "control_id": "numhdnhdrou",
      //           "view_name": "numhdnhdrou",
      //           "data_type": "Int",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.totalAmount",
      //           "control_id": "numtotalamount",
      //           "view_name": "numtotalamount",
      //           "data_type": "Int",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.mode",
      //           "control_id": "rbgmode",
      //           "view_name": "rbgmode",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.remarks",
      //           "control_id": "txaremarks",
      //           "view_name": "txaremarks",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.currency",
      //           "control_id": "txtcurrency",
      //           "view_name": "txtcurrency",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.customerPoNo",
      //           "control_id": "txtcustomerpono",
      //           "view_name": "txtcustomerpono",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.orderType",
      //           "control_id": "txtordertype",
      //           "view_name": "txtordertype",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.priority",
      //           "control_id": "txtpriority",
      //           "view_name": "txtpriority",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.quoteNo",
      //           "control_id": "txtquoteno",
      //           "view_name": "txtquoteno",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.customer",
      //           "control_id": "uicustomerlist",
      //           "view_name": "uicustomerlist",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         }
      //       ],
      //       "fields": []
      //     }
      //   ]
      // },
      // {
      //   "name": "saomainscfth",
      //   "type": "Fetch",
      //   "queries": [
      //     {
      //       "name": "saleorder_SH_ScreenLaunch.getMetaList",
      //       "alias": "Location",
      //       "type": "Mutation",
      //       "version": "1.0.0",
      //       "sequence": "1",
      //       "args": [
      //         {
      //           "default_value": "Location",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.getMetaList.entityType",
      //           "control_id": "",
      //           "view_name": "",
      //           "data_type": "String",
      //           "mapped":"no"
      //         }
      //       ],
      //       "inputFields": [],
      //       "fields": [
      //         {
      //           "usage": "lookup value",
      //           "name": "saleorder_SH_ScreenLaunch.getMetaList.data.descr",
      //           "control_id": "cmbreqlocation",
      //           "view_name": "cmbreqlocation",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         }
      //       ]
      //     },
      //     {
      //       "name": "saleorder_SH_ScreenLaunch.getMetaList",
      //       "alias": "StockStatus",
      //       "type": "Mutation",
      //       "version": "1.0.0",
      //       "sequence": "2",
      //       "args": [
      //         {
      //           "default_value": "StockStatus",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.getMetaList.entityType",
      //           "control_id": "",
      //           "view_name": "",
      //           "data_type": "String"
      //         }
      //       ],
      //       "inputFields": [],
      //       "fields": [
      //         {
      //           "usage": "lookup value",
      //           "name": "saleorder_SH_ScreenLaunch.getMetaList.data.code",
      //           "control_id": "grddetgrid",
      //           "view_name": "1002",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "lookup value",
      //           "name": "saleorder_SH_ScreenLaunch.getMetaList.data.descr",
      //           "control_id": "grddetgrid",
      //           "view_name": "4",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         }
      //       ]
      //     },
      //     {
      //       "name": "saleorder_SH_ScreenLaunch.getMetaList",
      //       "alias": "Customer",
      //       "type": "Mutation",
      //       "version": "1.0.0",
      //       "sequence": "3",
      //       "args": [
      //         {
      //           "default_value": "Customer",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.getMetaList.entityType",
      //           "control_id": "",
      //           "view_name": "",
      //           "data_type": "String"
      //         }
      //       ],
      //       "inputFields": [],
      //       "fields": [
      //         {
      //           "usage": "lookup value",
      //           "name": "saleorder_SH_ScreenLaunch.getMetaList.data.descr",
      //           "control_id": "uicustomerlist",
      //           "view_name": "uicustomerlist1",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "lookup value",
      //           "name": "saleorder_SH_ScreenLaunch.getMetaList.data.code",
      //           "control_id": "uicustomerlist",
      //           "view_name": "uicustomerlist2",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         }
      //       ]
      //     },
      //     {
      //       "name": "saleorder_SH_ScreenLaunch.getMetaList",
      //       "alias": "Status",
      //       "type": "Mutation",
      //       "version": "1.0.0",
      //       "sequence": "4",
      //       "args": [
      //         {
      //           "default_value": "Status",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.getMetaList.entityType",
      //           "control_id": "",
      //           "view_name": "",
      //           "data_type": "String"
      //         }
      //       ],
      //       "inputFields": [],
      //       "fields": [
      //         {
      //           "usage": "lookup value",
      //           "name": "saleorder_SH_ScreenLaunch.getMetaList.data.descr",
      //           "control_id": "cmbreqstatus",
      //           "view_name": "cmbreqstatus",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "lookup value",
      //           "name": "saleorder_SH_ScreenLaunch.getMetaList.data.code",
      //           "control_id": "cmbreqstatus",
      //           "view_name": "hhdnreqstatus",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         }
      //       ]
      //     },
      //     {
      //       "name": "saleorder_SH_ScreenLaunch.getMetaList",
      //       "alias": "Type",
      //       "type": "Mutation",
      //       "version": "1.0.0",
      //       "sequence": "5",
      //       "args": [
      //         {
      //           "default_value": "Type",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.getMetaList.entityType",
      //           "control_id": "",
      //           "view_name": "",
      //           "data_type": "String"
      //         }
      //       ],
      //       "inputFields": [],
      //       "fields": [
      //         {
      //           "usage": "lookup value",
      //           "name": "saleorder_SH_ScreenLaunch.getMetaList.data.descr",
      //           "control_id": "grditemgrid",
      //           "view_name": "7",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         }
      //       ]
      //     },
      //     {
      //       "name": "saleorder_SH_ScreenLaunch.getMetaList",
      //       "alias": "SaleType",
      //       "type": "Mutation",
      //       "version": "1.0.0",
      //       "sequence": "6",
      //       "args": [
      //         {
      //           "default_value": "SaleType",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.getMetaList.entityType",
      //           "control_id": "",
      //           "view_name": "",
      //           "data_type": "String"
      //         }
      //       ],
      //       "inputFields": [],
      //       "fields": [
      //         {
      //           "usage": "lookup value",
      //           "name": "saleorder_SH_ScreenLaunch.getMetaList.data.descr",
      //           "control_id": "cmbsaletype",
      //           "view_name": "cmbsaletype",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         }
      //       ]
      //     },
      //     {
      //       "name": "saleorder_SH_ScreenLaunch.getMetaList",
      //       "alias": "Category",
      //       "type": "Mutation",
      //       "version": "1.0.0",
      //       "sequence": "7",
      //       "args": [
      //         {
      //           "default_value": "Category",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.getMetaList.entityType",
      //           "control_id": "",
      //           "view_name": "",
      //           "data_type": "String"
      //         }
      //       ],
      //       "inputFields": [],
      //       "fields": [
      //         {
      //           "usage": "lookup value",
      //           "name": "saleorder_SH_ScreenLaunch.getMetaList.data.descr",
      //           "control_id": "cmbcategory",
      //           "view_name": "cmbcategory",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         }
      //       ]
      //     },
      //     {
      //       "name": "saleorder_SH_ScreenLaunch",
      //       "type": "Mutation",
      //       "version": "1.0.0",
      //       "sequence": "8",
      //       "args": [
      //         {
      //           "default_value": "",
      //           "required": "no",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.customerCode",
      //           "control_id": "uicustomerlist",
      //           "view_name": "uicustomerlist",
      //           "data_type": "String"
      //         }
      //       ],
      //       "inputFields": [],
      //       "fields": [
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.urgent",
      //           "control_id": "chkurgent",
      //           "view_name": "chkurgent",
      //           "data_type": "Int",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.categoryCode",
      //           "control_id": "cmbcategory",
      //           "view_name": "cmbcategory",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.reqLocation",
      //           "control_id": "cmbreqlocation",
      //           "view_name": "cmbreqlocation",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.reqStatus",
      //           "control_id": "cmbreqstatus",
      //           "view_name": "cmbreqstatus",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.saleType",
      //           "control_id": "cmbsaletype",
      //           "view_name": "cmbsaletype",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.rfqDate",
      //           "control_id": "datrfqdate",
      //           "view_name": "datrfqdate",
      //           "data_type": "LocalDateTime",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.liveTrack",
      //           "control_id": "dlklivetrack",
      //           "view_name": "dlklivetrack",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.liveTrackingAll",
      //           "control_id": "dlklivetrackall",
      //           "view_name": "dlklivetrackall",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.liveTrackingChennai",
      //           "control_id": "dlklivetrackch",
      //           "view_name": "dlklivetrackch",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.liveTrackingDelhi",
      //           "control_id": "dlklivetrackdh",
      //           "view_name": "dlklivetrackdh",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.liveTrackingMumbai",
      //           "control_id": "dlklivetrackmb",
      //           "view_name": "dlklivetrackmb",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.rfqno",
      //           "control_id": "dsprfqno",
      //           "view_name": "dsprfqno",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.dispatchDate",
      //           "control_id": "dttdispatchdate",
      //           "view_name": "dttdispatchdate",
      //           "data_type": "LocalDateTime",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.docType",
      //           "control_id": "grddetgrid",
      //           "view_name": "1",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.liveTrackingAll",
      //           "control_id": "grddetgrid",
      //           "view_name": "10",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.liveTrackingChennai",
      //           "control_id": "grddetgrid",
      //           "view_name": "11",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.liveTrackingMumbai",
      //           "control_id": "grddetgrid",
      //           "view_name": "12",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.liveTrackingDelhi",
      //           "control_id": "grddetgrid",
      //           "view_name": "13",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.authorized",
      //           "control_id": "grddetgrid",
      //           "view_name": "2",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.amendmentNo",
      //           "control_id": "grddetgrid",
      //           "view_name": "3",
      //           "data_type": "String",
      //           "mapped":"yes"
                
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.stockStatusCode",
      //           "control_id": "grddetgrid",
      //           "view_name": "4",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.currentPosition",
      //           "control_id": "grddetgrid",
      //           "view_name": "5",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.availableStock",
      //           "control_id": "grddetgrid",
      //           "view_name": "6",
      //           "data_type": "Int",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.currentPositionTPL",
      //           "control_id": "grddetgrid",
      //           "view_name": "7",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.viewGR",
      //           "control_id": "grddetgrid",
      //           "view_name": "8",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.additionalDocs",
      //           "control_id": "grddetgrid",
      //           "view_name": "9",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.itemCode",
      //           "control_id": "grditemgrid",
      //           "view_name": "1",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.orderType",
      //           "control_id": "grditemgrid",
      //           "view_name": "10",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.customerPoNo",
      //           "control_id": "grditemgrid",
      //           "view_name": "11",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.quoteNo",
      //           "control_id": "grditemgrid",
      //           "view_name": "12",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.currency",
      //           "control_id": "grditemgrid",
      //           "view_name": "13",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.itemImage",
      //           "control_id": "grditemgrid",
      //           "view_name": "2",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.itemDesc",
      //           "control_id": "grditemgrid",
      //           "view_name": "3",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.stockUpdatedDate",
      //           "control_id": "grditemgrid",
      //           "view_name": "4",
      //           "data_type": "LocalDateTime",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.stockDispatchedDate",
      //           "control_id": "grditemgrid",
      //           "view_name": "5",
      //           "data_type": "LocalDateTime",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.stockReceivedTime",
      //           "control_id": "grditemgrid",
      //           "view_name": "6",
      //           "data_type": "LocalDateTime",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.itemType",
      //           "control_id": "grditemgrid",
      //           "view_name": "7",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.itemPrice",
      //           "control_id": "grditemgrid",
      //           "view_name": "8",
      //           "data_type": "Float",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.itemRemarks",
      //           "control_id": "grditemgrid",
      //           "view_name": "9",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.customer",
      //           "control_id": "lstcustomer",
      //           "view_name": "lstcustomer",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.contextOu",
      //           "control_id": "numhdnhdrou",
      //           "view_name": "numhdnhdrou",
      //           "data_type": "Int",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.totalAmount",
      //           "control_id": "numtotalamount",
      //           "view_name": "numtotalamount",
      //           "data_type": "Int",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.mode",
      //           "control_id": "rbgmode",
      //           "view_name": "rbgmode",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.deliveryTime",
      //           "control_id": "timdeliverytime",
      //           "view_name": "timdeliverytime",
      //           "data_type": "LocalDateTime",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.remarks",
      //           "control_id": "txaremarks",
      //           "view_name": "txaremarks",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.currency",
      //           "control_id": "txtcurrency",
      //           "view_name": "txtcurrency",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.customerPoNo",
      //           "control_id": "txtcustomerpono",
      //           "view_name": "txtcustomerpono",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.orderType",
      //           "control_id": "txtordertype",
      //           "view_name": "txtordertype",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.priority",
      //           "control_id": "txtpriority",
      //           "view_name": "txtpriority",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         },
      //         {
      //           "usage": "value",
      //           "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.quoteNo",
      //           "control_id": "txtquoteno",
      //           "view_name": "txtquoteno",
      //           "data_type": "String",
      //           "mapped":"yes"
      //         }
      //       ]
      //     }
      //   ]
      // }
    ],
    "hidden_views": {
      "cmbreqstatus": [
        {
          "view_name": "cmbreqstatus",
          "hidden_view_name": "hhdnreqstatus",
          "datalength": 500,
          "btsynonym": "hdnreqstatus",
          "datatype": "Char"
        }
      ],
      "imgsupportdocs": [
        {
          "view_name": "imgsupportdocs",
          "hidden_view_name": "hdnsupportdocsDBC",
          "datalength": 60,
          "btsynonym": "supportdocsdbc",
          "datatype": "Char"
        }
      ],
      "grddetgrid": [
        {
          "view_name": "4",
          "hidden_view_name": "1002",
          "datalength": 500,
          "btsynonym": "hdnstockstatus",
          "datatype": "Char"
        },
        {
          "view_name": "9",
          "hidden_view_name": "1001",
          "datalength": 60,
          "btsynonym": "additionaldocsdbc",
          "datatype": "Char"
        }
      ],
      "grditemgrid": [
        {
          "view_name": "2",
          "hidden_view_name": "1001",
          "datalength": 60,
          "btsynonym": "item_imagedbc",
          "datatype": "Char"
        }
      ]
    },
    "subscription": {
      "saomainsccurrechp": {
        "linkid": "1010",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "ordertypervw",
        "dataitems": [
          {
            "name": "currency",
            "control_id": "txtcurrency",
            "view_name": "txtcurrency",
            "flow_direction": "2"
          },
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          }
        ]
      },
      "saomainsccustophp": {
        "linkid": "1009",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "ordertypervw",
        "dataitems": [
          {
            "name": "customerpono",
            "control_id": "txtcustomerpono",
            "view_name": "txtcustomerpono",
            "flow_direction": "2"
          }
        ]
      },
      "saomainsclivetalk": {
        "linkid": "1003",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackinggql",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "reqstatus",
            "control_id": "cmbreqstatus",
            "view_name": "cmbreqstatus",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          }
        ]
      },
      "saomainsclivetclk": {
        "linkid": "1005",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackingrvw",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "deliverytime",
            "control_id": "timdeliverytime",
            "view_name": "timdeliverytime",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "reqstatus",
            "control_id": "cmbreqstatus",
            "view_name": "cmbreqstatus",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          }
        ]
      },
      "saomainsclivetklk": {
        "linkid": "1006",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackingrvw",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "deliverytime",
            "control_id": "timdeliverytime",
            "view_name": "timdeliverytime",
            "flow_direction": "1"
          },
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "reqstatus",
            "control_id": "cmbreqstatus",
            "view_name": "cmbreqstatus",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          }
        ]
      },
      "saomainsclivetmlk": {
        "linkid": "1004",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackinggql",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "reqstatus",
            "control_id": "cmbreqstatus",
            "view_name": "cmbreqstatus",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          }
        ]
      },
      "saomainscorderthp": {
        "linkid": "1007",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "ordertypegql",
        "dataitems": [
          {
            "name": "ordertype",
            "control_id": "txtordertype",
            "view_name": "txtordertype",
            "flow_direction": "2"
          }
        ]
      },
      "saomainscpriorihp": {
        "linkid": "1001",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "salespriority",
        "dataitems": [
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "2"
          }
        ]
      },
      "saomainscpriorllk": {
        "linkid": "1006",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackingrvw",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "reqstatus",
            "control_id": "cmbreqstatus",
            "view_name": "cmbreqstatus",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          }
        ]
      },
      "saomainscpriormlk": {
        "linkid": "1004",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackinggql",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "deliverytime",
            "control_id": "timdeliverytime",
            "view_name": "timdeliverytime",
            "flow_direction": "1"
          },
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "reqstatus",
            "control_id": "cmbreqstatus",
            "view_name": "cmbreqstatus",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          }
        ]
      },
      "saomainscpriortlk": {
        "linkid": "1003",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackinggql",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "deliverytime",
            "control_id": "timdeliverytime",
            "view_name": "timdeliverytime",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "reqstatus",
            "control_id": "cmbreqstatus",
            "view_name": "cmbreqstatus",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          }
        ]
      },
      "saomainscpriorylk": {
        "linkid": "1005",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackingrvw",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "reqstatus",
            "control_id": "cmbreqstatus",
            "view_name": "cmbreqstatus",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          }
        ]
      },
      "saomainscquotenhp": {
        "linkid": "1008",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "ordertypegql",
        "dataitems": [
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          },
          {
            "name": "quoteno",
            "control_id": "txtquoteno",
            "view_name": "txtquoteno",
            "flow_direction": "2"
          }
        ]
      },
      "saomainscvwadddlk": {
        "linkid": "1011",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackinggql",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "reqstatus",
            "control_id": "cmbreqstatus",
            "view_name": "cmbreqstatus",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          }
        ]
      },
      "saotblta_curreyhp": {
        "linkid": "1010",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackingrvw",
        "dataitems": [
          {
            "name": "currencyml",
            "control_id": "grditemgrid",
            "view_name": "13",
            "flow_direction": "2"
          },
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          }
        ]
      },
      "saotblta_custoohp": {
        "linkid": "1009",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackingrvw",
        "dataitems": [
          {
            "name": "customerponoml",
            "control_id": "grditemgrid",
            "view_name": "11",
            "flow_direction": "2"
          }
        ]
      },
      "saotblta_orderyhp": {
        "linkid": "1007",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackinggql",
        "dataitems": [
          {
            "name": "ordertypeml",
            "control_id": "grditemgrid",
            "view_name": "10",
            "flow_direction": "2"
          }
        ]
      },
      "saotblta_quoteohp": {
        "linkid": "1008",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackinggql",
        "dataitems": [
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          },
          {
            "name": "quotenoml",
            "control_id": "grditemgrid",
            "view_name": "12",
            "flow_direction": "2"
          }
        ]
      },
      "saotbltabamendmhp": {
        "linkid": "1002",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "salespriority",
        "dataitems": [
          {
            "name": "amendmentno",
            "control_id": "grddetgrid",
            "view_name": "3",
            "flow_direction": "2"
          }
        ]
      },
      "saotbltablivetblk": {
        "linkid": "1004",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackinggql",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "deliverytime",
            "control_id": "timdeliverytime",
            "view_name": "timdeliverytime",
            "flow_direction": "1"
          },
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          },
          {
            "name": "stockstatus",
            "control_id": "grddetgrid",
            "view_name": "4",
            "flow_direction": "1"
          }
        ]
      },
      "saotbltablivetdlk": {
        "linkid": "1006",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackingrvw",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          },
          {
            "name": "stockstatus",
            "control_id": "grddetgrid",
            "view_name": "4",
            "flow_direction": "1"
          }
        ]
      },
      "saotbltablivethlk": {
        "linkid": "1005",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackingrvw",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          },
          {
            "name": "stockstatus",
            "control_id": "grddetgrid",
            "view_name": "4",
            "flow_direction": "1"
          }
        ]
      },
      "saotbltablivetllk": {
        "linkid": "1003",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackinggql",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "deliverytime",
            "control_id": "timdeliverytime",
            "view_name": "timdeliverytime",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          },
          {
            "name": "stockstatus",
            "control_id": "grddetgrid",
            "view_name": "4",
            "flow_direction": "1"
          }
        ]
      }
    },
    "publications": {
      "1014": [
        {
          "name": "additionaldocs",
          "control_id": "grddetgrid",
          "view_name": "9",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "amendmentno",
          "control_id": "grddetgrid",
          "view_name": "3",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "authorized",
          "control_id": "grddetgrid",
          "view_name": "2",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "availablestock",
          "control_id": "grddetgrid",
          "view_name": "6",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "category",
          "control_id": "cmbcategory",
          "view_name": "cmbcategory",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "csou",
          "control_id": "rvwrt_lctxt_ou",
          "view_name": "rvwrt_lctxt_ou",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "currency",
          "control_id": "txtcurrency",
          "view_name": "txtcurrency",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "currencyml",
          "control_id": "grditemgrid",
          "view_name": "13",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "currentposition",
          "control_id": "grddetgrid",
          "view_name": "5",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "currentpositiontpl",
          "control_id": "grddetgrid",
          "view_name": "7",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "customer",
          "control_id": "lstcustomer",
          "view_name": "lstcustomer",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "customerpono",
          "control_id": "txtcustomerpono",
          "view_name": "txtcustomerpono",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "customerponoml",
          "control_id": "grditemgrid",
          "view_name": "11",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "deliverytime",
          "control_id": "timdeliverytime",
          "view_name": "timdeliverytime",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "dispatchdate",
          "control_id": "dttdispatchdate",
          "view_name": "dttdispatchdate",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "doccount",
          "control_id": "dvhdoctemplate",
          "view_name": "2",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "docstatus",
          "control_id": "dvhdoctemplate",
          "view_name": "1",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "doctemplate_rid",
          "control_id": "hdndoctemplate_rid",
          "view_name": "hdndoctemplate_rid",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "doctplid",
          "control_id": "dvhdoctemplate",
          "view_name": "3",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "doctype",
          "control_id": "grddetgrid",
          "view_name": "1",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "hdnhdrou",
          "control_id": "numhdnhdrou",
          "view_name": "numhdnhdrou",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "hdnrt_stcontrol",
          "control_id": "hdnhdnrt_stcontrol",
          "view_name": "hdnhdnrt_stcontrol",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_code",
          "control_id": "grditemgrid",
          "view_name": "1",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_desc",
          "control_id": "grditemgrid",
          "view_name": "3",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_image",
          "control_id": "grditemgrid",
          "view_name": "2",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_price",
          "control_id": "grditemgrid",
          "view_name": "8",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_remarks",
          "control_id": "grditemgrid",
          "view_name": "9",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_type",
          "control_id": "grditemgrid",
          "view_name": "7",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "livetrackallml",
          "control_id": "grddetgrid",
          "view_name": "10",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "livetrackchml",
          "control_id": "grddetgrid",
          "view_name": "11",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "livetrackdhml",
          "control_id": "grddetgrid",
          "view_name": "13",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "livetrackmbml",
          "control_id": "grddetgrid",
          "view_name": "12",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "ordertype",
          "control_id": "txtordertype",
          "view_name": "txtordertype",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "ordertypeml",
          "control_id": "grditemgrid",
          "view_name": "10",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "priority",
          "control_id": "txtpriority",
          "view_name": "txtpriority",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "prj_hdn_ctrl",
          "control_id": "hdnprj_hdn_ctrl",
          "view_name": "hdnprj_hdn_ctrl",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "quoteno",
          "control_id": "txtquoteno",
          "view_name": "txtquoteno",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "quotenoml",
          "control_id": "grditemgrid",
          "view_name": "12",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "remarks",
          "control_id": "txaremarks",
          "view_name": "txaremarks",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "reqlocation",
          "control_id": "cmbreqlocation",
          "view_name": "cmbreqlocation",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "reqstatus",
          "control_id": "cmbreqstatus",
          "view_name": "cmbreqstatus",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "rfqdate",
          "control_id": "datrfqdate",
          "view_name": "datrfqdate",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "rfqno",
          "control_id": "dsprfqno",
          "view_name": "dsprfqno",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "saletype",
          "control_id": "cmbsaletype",
          "view_name": "cmbsaletype",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "stock_dispatched_date",
          "control_id": "grditemgrid",
          "view_name": "5",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "stock_received_time",
          "control_id": "grditemgrid",
          "view_name": "6",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "stock_updated_date",
          "control_id": "grditemgrid",
          "view_name": "4",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "stockstatus",
          "control_id": "grddetgrid",
          "view_name": "4",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "supportdocs",
          "control_id": "imgsupportdocs",
          "view_name": "imgsupportdocs",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "totalamount",
          "control_id": "numtotalamount",
          "view_name": "numtotalamount",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "urgent",
          "control_id": "chkurgent",
          "view_name": "chkurgent",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "viewgr",
          "control_id": "grddetgrid",
          "view_name": "8",
          "flow_direction": "0",
          "multi_instance": "no"
        }
      ],
      "1015": [
        {
          "name": "additionaldocs",
          "control_id": "grddetgrid",
          "view_name": "9",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "amendmentno",
          "control_id": "grddetgrid",
          "view_name": "3",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "authorized",
          "control_id": "grddetgrid",
          "view_name": "2",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "availablestock",
          "control_id": "grddetgrid",
          "view_name": "6",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "category",
          "control_id": "cmbcategory",
          "view_name": "cmbcategory",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "csou",
          "control_id": "rvwrt_lctxt_ou",
          "view_name": "rvwrt_lctxt_ou",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "currency",
          "control_id": "txtcurrency",
          "view_name": "txtcurrency",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "currencyml",
          "control_id": "grditemgrid",
          "view_name": "13",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "currentposition",
          "control_id": "grddetgrid",
          "view_name": "5",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "currentpositiontpl",
          "control_id": "grddetgrid",
          "view_name": "7",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "customer",
          "control_id": "lstcustomer",
          "view_name": "lstcustomer",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "customerpono",
          "control_id": "txtcustomerpono",
          "view_name": "txtcustomerpono",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "customerponoml",
          "control_id": "grditemgrid",
          "view_name": "11",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "deliverytime",
          "control_id": "timdeliverytime",
          "view_name": "timdeliverytime",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "dispatchdate",
          "control_id": "dttdispatchdate",
          "view_name": "dttdispatchdate",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "doccount",
          "control_id": "dvhdoctemplate",
          "view_name": "2",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "docstatus",
          "control_id": "dvhdoctemplate",
          "view_name": "1",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "doctemplate_rid",
          "control_id": "hdndoctemplate_rid",
          "view_name": "hdndoctemplate_rid",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "doctplid",
          "control_id": "dvhdoctemplate",
          "view_name": "3",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "doctype",
          "control_id": "grddetgrid",
          "view_name": "1",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "hdnhdrou",
          "control_id": "numhdnhdrou",
          "view_name": "numhdnhdrou",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "hdnrt_stcontrol",
          "control_id": "hdnhdnrt_stcontrol",
          "view_name": "hdnhdnrt_stcontrol",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_code",
          "control_id": "grditemgrid",
          "view_name": "1",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_desc",
          "control_id": "grditemgrid",
          "view_name": "3",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_image",
          "control_id": "grditemgrid",
          "view_name": "2",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_price",
          "control_id": "grditemgrid",
          "view_name": "8",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_remarks",
          "control_id": "grditemgrid",
          "view_name": "9",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_type",
          "control_id": "grditemgrid",
          "view_name": "7",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "livetrackallml",
          "control_id": "grddetgrid",
          "view_name": "10",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "livetrackchml",
          "control_id": "grddetgrid",
          "view_name": "11",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "livetrackdhml",
          "control_id": "grddetgrid",
          "view_name": "13",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "livetrackmbml",
          "control_id": "grddetgrid",
          "view_name": "12",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "ordertype",
          "control_id": "txtordertype",
          "view_name": "txtordertype",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "ordertypeml",
          "control_id": "grditemgrid",
          "view_name": "10",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "priority",
          "control_id": "txtpriority",
          "view_name": "txtpriority",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "prj_hdn_ctrl",
          "control_id": "hdnprj_hdn_ctrl",
          "view_name": "hdnprj_hdn_ctrl",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "quoteno",
          "control_id": "txtquoteno",
          "view_name": "txtquoteno",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "quotenoml",
          "control_id": "grditemgrid",
          "view_name": "12",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "remarks",
          "control_id": "txaremarks",
          "view_name": "txaremarks",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "reqlocation",
          "control_id": "cmbreqlocation",
          "view_name": "cmbreqlocation",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "reqstatus",
          "control_id": "cmbreqstatus",
          "view_name": "cmbreqstatus",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "rfqdate",
          "control_id": "datrfqdate",
          "view_name": "datrfqdate",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "rfqno",
          "control_id": "dsprfqno",
          "view_name": "dsprfqno",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "saletype",
          "control_id": "cmbsaletype",
          "view_name": "cmbsaletype",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "stock_dispatched_date",
          "control_id": "grditemgrid",
          "view_name": "5",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "stock_received_time",
          "control_id": "grditemgrid",
          "view_name": "6",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "stock_updated_date",
          "control_id": "grditemgrid",
          "view_name": "4",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "stockstatus",
          "control_id": "grddetgrid",
          "view_name": "4",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "supportdocs",
          "control_id": "imgsupportdocs",
          "view_name": "imgsupportdocs",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "totalamount",
          "control_id": "numtotalamount",
          "view_name": "numtotalamount",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "urgent",
          "control_id": "chkurgent",
          "view_name": "chkurgent",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "viewgr",
          "control_id": "grddetgrid",
          "view_name": "8",
          "flow_direction": "0",
          "multi_instance": "no"
        }
      ]
    },
    "disposal": "saomainscdis",
    "posttask": {
      "saomainsccustophp": {
        "posthelp": "saomainsccustoeui"
      },
      "saomainscpriortlk": {
        "postlink": "saomainscprintstr"
      }
    }
  },
"introspectionQuery":{
    "data": {
      "__schema": {
        "queryType": {
          "name": "Query"
        },
        "mutationType": {
          "name": "Mutation"
        },
        "subscriptionType": null,
        "types": [
          {
            "kind": "OBJECT",
            "name": "__Directive",
            "description": "A Directive provides a way to describe alternate runtime execution and type validation behavior in a GraphQL document.\n\nIn some cases, you need to provide options to alter GraphQL's execution behavior in ways field arguments will not suffice, such as conditionally including or skipping a field. Directives provide this by describing additional information to the executor.",
            "fields": [
              {
                "name": "name",
                "description": null,
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "String",
                    "ofType": null
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "description",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "locations",
                "description": null,
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "LIST",
                    "name": null,
                    "ofType": {
                      "kind": "NON_NULL",
                      "name": null,
                      "ofType": {
                        "kind": "ENUM",
                        "name": "__DirectiveLocation",
                        "ofType": null
                      }
                    }
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "args",
                "description": null,
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "LIST",
                    "name": null,
                    "ofType": {
                      "kind": "NON_NULL",
                      "name": null,
                      "ofType": {
                        "kind": "OBJECT",
                        "name": "__InputValue",
                        "ofType": null
                      }
                    }
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "isRepeatable",
                "description": null,
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "Boolean",
                    "ofType": null
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "onOperation",
                "description": null,
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "Boolean",
                    "ofType": null
                  }
                },
                "isDeprecated": true,
                "deprecationReason": "Use `locations`."
              },
              {
                "name": "onFragment",
                "description": null,
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "Boolean",
                    "ofType": null
                  }
                },
                "isDeprecated": true,
                "deprecationReason": "Use `locations`."
              },
              {
                "name": "onField",
                "description": null,
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "Boolean",
                    "ofType": null
                  }
                },
                "isDeprecated": true,
                "deprecationReason": "Use `locations`."
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "ENUM",
            "name": "__DirectiveLocation",
            "description": "A Directive can be adjacent to many parts of the GraphQL language, a __DirectiveLocation describes one such possible adjacencies.",
            "fields": null,
            "inputFields": null,
            "interfaces": null,
            "enumValues": [
              {
                "name": "QUERY",
                "description": "Location adjacent to a query operation.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "MUTATION",
                "description": "Location adjacent to a mutation operation.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "SUBSCRIPTION",
                "description": "Location adjacent to a subscription operation.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "FIELD",
                "description": "Location adjacent to a field.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "FRAGMENT_DEFINITION",
                "description": "Location adjacent to a fragment definition.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "FRAGMENT_SPREAD",
                "description": "Location adjacent to a fragment spread.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "INLINE_FRAGMENT",
                "description": "Location adjacent to an inline fragment.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "VARIABLE_DEFINITION",
                "description": "Location adjacent to a variable definition.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "SCHEMA",
                "description": "Location adjacent to a schema definition.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "SCALAR",
                "description": "Location adjacent to a scalar definition.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "OBJECT",
                "description": "Location adjacent to an object type definition.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "FIELD_DEFINITION",
                "description": "Location adjacent to a field definition.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "ARGUMENT_DEFINITION",
                "description": "Location adjacent to an argument definition",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "INTERFACE",
                "description": "Location adjacent to an interface definition.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "UNION",
                "description": "Location adjacent to a union definition.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "ENUM",
                "description": "Location adjacent to an enum definition.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "ENUM_VALUE",
                "description": "Location adjacent to an enum value definition.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "INPUT_OBJECT",
                "description": "Location adjacent to an input object type definition.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "INPUT_FIELD_DEFINITION",
                "description": "Location adjacent to an input object field definition.",
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "__EnumValue",
            "description": "One possible value for a given Enum. Enum values are unique values, not a placeholder for a string or numeric value. However an Enum value is returned in a JSON response as a string.",
            "fields": [
              {
                "name": "name",
                "description": null,
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "String",
                    "ofType": null
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "description",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "isDeprecated",
                "description": null,
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "Boolean",
                    "ofType": null
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "deprecationReason",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "__Field",
            "description": "Object and Interface types are described by a list of Fields, each of which has a name, potentially a list of arguments, and a return type.",
            "fields": [
              {
                "name": "name",
                "description": null,
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "String",
                    "ofType": null
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "description",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "args",
                "description": null,
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "LIST",
                    "name": null,
                    "ofType": {
                      "kind": "NON_NULL",
                      "name": null,
                      "ofType": {
                        "kind": "OBJECT",
                        "name": "__InputValue",
                        "ofType": null
                      }
                    }
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "type",
                "description": null,
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "OBJECT",
                    "name": "__Type",
                    "ofType": null
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "isDeprecated",
                "description": null,
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "Boolean",
                    "ofType": null
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "deprecationReason",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "__InputValue",
            "description": "Arguments provided to Fields or Directives and the input fields of an InputObject are represented as Input Values which describe their type and optionally a default value.",
            "fields": [
              {
                "name": "name",
                "description": null,
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "String",
                    "ofType": null
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "description",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "type",
                "description": null,
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "OBJECT",
                    "name": "__Type",
                    "ofType": null
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "defaultValue",
                "description": "A GraphQL-formatted string representing the default value for this input value.",
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "__Schema",
            "description": "A GraphQL Schema defines the capabilities of a GraphQL server. It exposes all available types and directives on the server, as well as the entry points for query, mutation, and subscription operations.",
            "fields": [
              {
                "name": "description",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "types",
                "description": "A list of all types supported by this server.",
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "LIST",
                    "name": null,
                    "ofType": {
                      "kind": "NON_NULL",
                      "name": null,
                      "ofType": {
                        "kind": "OBJECT",
                        "name": "__Type",
                        "ofType": null
                      }
                    }
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "queryType",
                "description": "The type that query operations will be rooted at.",
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "OBJECT",
                    "name": "__Type",
                    "ofType": null
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "mutationType",
                "description": "If this server supports mutation, the type that mutation operations will be rooted at.",
                "args": [],
                "type": {
                  "kind": "OBJECT",
                  "name": "__Type",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "subscriptionType",
                "description": "If this server support subscription, the type that subscription operations will be rooted at.",
                "args": [],
                "type": {
                  "kind": "OBJECT",
                  "name": "__Type",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "directives",
                "description": "A list of all directives supported by this server.",
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "LIST",
                    "name": null,
                    "ofType": {
                      "kind": "NON_NULL",
                      "name": null,
                      "ofType": {
                        "kind": "OBJECT",
                        "name": "__Directive",
                        "ofType": null
                      }
                    }
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "__Type",
            "description": "The fundamental unit of any GraphQL Schema is the type. There are many kinds of types in GraphQL as represented by the `__TypeKind` enum.\n\nDepending on the kind of a type, certain fields describe information about that type. Scalar types provide no information beyond a name and description, while Enum types provide their values. Object and Interface types provide the fields they describe. Abstract types, Union and Interface, provide the Object types possible at runtime. List and NonNull types compose other types.",
            "fields": [
              {
                "name": "kind",
                "description": null,
                "args": [],
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "ENUM",
                    "name": "__TypeKind",
                    "ofType": null
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "name",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "description",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "fields",
                "description": null,
                "args": [
                  {
                    "name": "includeDeprecated",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "Boolean",
                      "ofType": null
                    },
                    "defaultValue": "false"
                  }
                ],
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "OBJECT",
                      "name": "__Field",
                      "ofType": null
                    }
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "interfaces",
                "description": null,
                "args": [],
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "OBJECT",
                      "name": "__Type",
                      "ofType": null
                    }
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "possibleTypes",
                "description": null,
                "args": [],
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "OBJECT",
                      "name": "__Type",
                      "ofType": null
                    }
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "enumValues",
                "description": null,
                "args": [
                  {
                    "name": "includeDeprecated",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "Boolean",
                      "ofType": null
                    },
                    "defaultValue": "false"
                  }
                ],
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "OBJECT",
                      "name": "__EnumValue",
                      "ofType": null
                    }
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "inputFields",
                "description": null,
                "args": [],
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "OBJECT",
                      "name": "__InputValue",
                      "ofType": null
                    }
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "ofType",
                "description": null,
                "args": [],
                "type": {
                  "kind": "OBJECT",
                  "name": "__Type",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "specifiedByURL",
                "description": "`specifiedByURL` may return a String (in the form of a URL) for custom scalars, otherwise it will return `null`.",
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "ENUM",
            "name": "__TypeKind",
            "description": "An enum describing what kind of type a given `__Type` is.",
            "fields": null,
            "inputFields": null,
            "interfaces": null,
            "enumValues": [
              {
                "name": "SCALAR",
                "description": "Indicates this type is a scalar.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "OBJECT",
                "description": "Indicates this type is an object. `fields` and `interfaces` are valid fields.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "INTERFACE",
                "description": "Indicates this type is an interface. `fields` and `possibleTypes` are valid fields.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "UNION",
                "description": "Indicates this type is a union. `possibleTypes` is a valid field.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "ENUM",
                "description": "Indicates this type is an enum. `enumValues` is a valid field.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "INPUT_OBJECT",
                "description": "Indicates this type is an input object. `inputFields` is a valid field.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "LIST",
                "description": "Indicates this type is a list. `ofType` is a valid field.",
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "NON_NULL",
                "description": "Indicates this type is a non-null. `ofType` is a valid field.",
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "possibleTypes": null
          },
          {
            "kind": "SCALAR",
            "name": "LocalDateTime",
            "description": "A date and time in a particular calendar system.",
            "fields": null,
            "inputFields": null,
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_DetailInfoInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "additionalDocs",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "amendmentNo",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "authorized",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "availableStock",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "currentPosition",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "currentPositionTPL",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput1995",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "docType",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "liveTrackingAll",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "liveTrackingChennai",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "liveTrackingDelhi",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "liveTrackingMumbai",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "modeFlag",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "rowNo",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockStatus",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockStatusCode",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockStatusDesc",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "viewGR",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "positionInfo",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "saleorder_4_SH_ScreenLaunch_PositionInfoInput",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_ItemDetailInfoInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "currency",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customerPoNo",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "itemCode",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "itemDesc",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "itemImage",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "itemPrice",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Float",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "itemRemarks",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "itemType",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "modeFlag",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "orderType",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "quoteNo",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "rowNo",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockDispatchedDate",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockReceivedTime",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockUpdatedDate",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_CustomerMasterInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "categoryCode",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "categoryDesc",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "contextOu",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "currency",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customer",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customerPoNo",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "deliveryTime",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "dispatchDate",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "liveTrack",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "liveTrackingAll",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "liveTrackingChennai",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "liveTrackingDelhi",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "liveTrackingMumbai",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "mode",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "orderType",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "priority",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "quoteNo",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "remarks",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "reqLocation",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "reqStatus",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "reqStatusCode",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "reqStatusDesc",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "rfqDate",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "rfqno",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "saleType",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "totalAmount",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "urgent",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "SCALAR",
            "name": "Any",
            "description": null,
            "fields": null,
            "inputFields": null,
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "SCALAR",
            "name": "Long",
            "description": "The `Long` scalar type represents non-fractional signed whole 64-bit numeric values. Long can represent values between -(2^63) and 2^63 - 1.",
            "fields": null,
            "inputFields": null,
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "SCALAR",
            "name": "BigInt",
            "description": null,
            "fields": null,
            "inputFields": null,
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_out",
            "description": null,
            "fields": [
              {
                "name": "getPositionInfo",
                "description": null,
                "args": [
                  {
                    "name": "customerCode",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customerName",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput1",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput2",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "OBJECT",
                  "name": "saleorder_4_SH_ScreenLaunch_getCustomerCurrentposition",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "deleteCustomerDetail",
                "description": null,
                "args": [
                  {
                    "name": "customerCode",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customerName",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput1",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput2",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "docType",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "rfqNo",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "getCustomerDetail",
                "description": null,
                "args": [
                  {
                    "name": "customerCode",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customerName",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput1",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput2",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "OBJECT",
                  "name": "saleorder_4_SH_ScreenLaunch_getCustomerDetail",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "postCustomerDetail",
                "description": null,
                "args": [
                  {
                    "name": "customerCode",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customerName",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput1",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput2",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "deliveryTime",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "DateTime",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "dispatchDate",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "Date",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "liveTracking",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "mode",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "priority",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "remarks",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "requestingLocation",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "rfqDate",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "Date",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "rfqNo",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "status",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "supportingDocuments",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "totalAmount",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "Float",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "urgent",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "DetailInfoInput",
                    "description": null,
                    "type": {
                      "kind": "LIST",
                      "name": null,
                      "ofType": {
                        "kind": "NON_NULL",
                        "name": null,
                        "ofType": {
                          "kind": "INPUT_OBJECT",
                          "name": "saleorder_4_SH_ScreenLaunch_DetailInfoInput",
                          "ofType": null
                        }
                      }
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "putCustomerDetail",
                "description": null,
                "args": [
                  {
                    "name": "customerCode",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customerName",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput1",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput2",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "deliveryTime",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "DateTime",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "dispatchDate",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "Date",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "liveTracking",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "mode",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "priority",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "remarks",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "requestingLocation",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "rfqDate",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "Date",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "rfqNo",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "status",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "supportingDocuments",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "totalAmount",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "Float",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "urgent",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "DetailInfoInput",
                    "description": null,
                    "type": {
                      "kind": "LIST",
                      "name": null,
                      "ofType": {
                        "kind": "NON_NULL",
                        "name": null,
                        "ofType": {
                          "kind": "INPUT_OBJECT",
                          "name": "saleorder_4_SH_ScreenLaunch_DetailInfoInput",
                          "ofType": null
                        }
                      }
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "getDocType",
                "description": null,
                "args": [
                  {
                    "name": "customInput1",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput2",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "docTypeCode",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "docTypeName",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "OBJECT",
                  "name": "saleorder_4_SH_ScreenLaunch_getCustomerDoctype",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "deleteCustomerDtlInfo",
                "description": null,
                "args": [
                  {
                    "name": "customerCode",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customerName",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput1",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput2",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "itemCode",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "rfqNo",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "getCustomerDtlInfo",
                "description": null,
                "args": [
                  {
                    "name": "customerCode",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customerName",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput1",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput2",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "OBJECT",
                  "name": "saleorder_4_SH_ScreenLaunch_getCustomerItemdetail",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "postCustomerDtlInfo",
                "description": null,
                "args": [
                  {
                    "name": "customerCode",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customerName",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput1",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput2",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "deliveryTime",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "DateTime",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "dispatchDate",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "Date",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "liveTracking",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "mode",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "priority",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "remarks",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "requestingLocation",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "rfqDate",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "Date",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "rfqNo",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "status",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "supportingDocuments",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "totalAmount",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "Float",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "urgent",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "ItemDetailInfoInput",
                    "description": null,
                    "type": {
                      "kind": "LIST",
                      "name": null,
                      "ofType": {
                        "kind": "NON_NULL",
                        "name": null,
                        "ofType": {
                          "kind": "INPUT_OBJECT",
                          "name": "saleorder_4_SH_ScreenLaunch_ItemDetailInfoInput",
                          "ofType": null
                        }
                      }
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "putCustomerDtlInfo",
                "description": null,
                "args": [
                  {
                    "name": "customerCode",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customerName",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput1",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput2",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "deliveryTime",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "DateTime",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "dispatchDate",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "Date",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "liveTracking",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "mode",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "priority",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "remarks",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "requestingLocation",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "rfqDate",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "Date",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "rfqNo",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "status",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "supportingDocuments",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "totalAmount",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "Float",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "urgent",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "ItemDetailInfoInput",
                    "description": null,
                    "type": {
                      "kind": "LIST",
                      "name": null,
                      "ofType": {
                        "kind": "NON_NULL",
                        "name": null,
                        "ofType": {
                          "kind": "INPUT_OBJECT",
                          "name": "saleorder_4_SH_ScreenLaunch_ItemDetailInfoInput",
                          "ofType": null
                        }
                      }
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "getCustomerMaster",
                "description": null,
                "args": [
                  {
                    "name": "customerCode",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customerName",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput1",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput2",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "OBJECT",
                  "name": "saleorder_4_SH_ScreenLaunch_getCustomerMaster",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "postCustomerMaster",
                "description": null,
                "args": [
                  {
                    "name": "customerCode",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customerName",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput1",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput2",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "CustomerMasterInput",
                    "description": null,
                    "type": {
                      "kind": "NON_NULL",
                      "name": null,
                      "ofType": {
                        "kind": "INPUT_OBJECT",
                        "name": "saleorder_4_SH_ScreenLaunch_CustomerMasterInput",
                        "ofType": null
                      }
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "getMetaList",
                "description": null,
                "args": [
                  {
                    "name": "code",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput1",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput2",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "description",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "entityType",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "OBJECT",
                  "name": "saleorder_4_SH_ScreenLaunch_getCustomerMetalist",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "getStockStatus",
                "description": null,
                "args": [
                  {
                    "name": "customInput1",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput2",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "stockStatusName",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "OBJECT",
                  "name": "saleorder_4_SH_ScreenLaunch_getCustomerStockstatus",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "getSummaryInfo",
                "description": null,
                "args": [
                  {
                    "name": "customerCode",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customerName",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput1",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "customInput2",
                    "description": null,
                    "type": {
                      "kind": "SCALAR",
                      "name": "String",
                      "ofType": null
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "OBJECT",
                  "name": "saleorder_4_SH_ScreenLaunch_getCustomerSummary",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "Query",
            "description": null,
            "fields": [
              {
                "name": "message",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "Mutation",
            "description": null,
            "fields": [
              {
                "name": "message",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "saleorder_SH_ScreenLaunch",
                "description": null,
                "args": [],
                "type": {
                  "kind": "OBJECT",
                  "name": "saleorder_4_SH_ScreenLaunch_out",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "SCALAR",
            "name": "String",
            "description": "The `String` scalar type represents textual data, represented as UTF-8 character sequences. The String type is most often used by GraphQL to represent free-form human-readable text.",
            "fields": null,
            "inputFields": null,
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "SCALAR",
            "name": "Boolean",
            "description": "The `Boolean` scalar type represents `true` or `false`.",
            "fields": null,
            "inputFields": null,
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "SCALAR",
            "name": "Int",
            "description": "The `Int` scalar type represents non-fractional signed whole numeric values. Int can represent values between -(2^31) and 2^31 - 1.",
            "fields": null,
            "inputFields": null,
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "SCALAR",
            "name": "DateTime",
            "description": "The `DateTime` scalar represents an ISO-8601 compliant date time type.",
            "fields": null,
            "inputFields": null,
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "SCALAR",
            "name": "Date",
            "description": "The `Date` scalar represents an ISO-8601 compliant date type.",
            "fields": null,
            "inputFields": null,
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "SCALAR",
            "name": "Float",
            "description": "The `Float` scalar type represents signed double-precision fractional values as specified by [IEEE 754](http://en.wikipedia.org/wiki/IEEE_floating_point).",
            "fields": null,
            "inputFields": null,
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_getCustomerCurrentposition",
            "description": null,
            "fields": [
              {
                "name": "data",
                "description": null,
                "args": [
                  {
                    "name": "where",
                    "description": null,
                    "type": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_PositionInfoFilterInput",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "order",
                    "description": null,
                    "type": {
                      "kind": "LIST",
                      "name": null,
                      "ofType": {
                        "kind": "NON_NULL",
                        "name": null,
                        "ofType": {
                          "kind": "INPUT_OBJECT",
                          "name": "saleorder_4_SH_ScreenLaunch_PositionInfoSortInput",
                          "ofType": null
                        }
                      }
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_PositionInfo",
                      "ofType": null
                    }
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "message",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_getCustomerDetail",
            "description": null,
            "fields": [
              {
                "name": "data",
                "description": null,
                "args": [
                  {
                    "name": "where",
                    "description": null,
                    "type": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_DetailInfoFilterInput",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "order",
                    "description": null,
                    "type": {
                      "kind": "LIST",
                      "name": null,
                      "ofType": {
                        "kind": "NON_NULL",
                        "name": null,
                        "ofType": {
                          "kind": "INPUT_OBJECT",
                          "name": "saleorder_4_SH_ScreenLaunch_DetailInfoSortInput",
                          "ofType": null
                        }
                      }
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_DetailInfo",
                      "ofType": null
                    }
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "message",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_getCustomerDoctype",
            "description": null,
            "fields": [
              {
                "name": "data",
                "description": null,
                "args": [
                  {
                    "name": "where",
                    "description": null,
                    "type": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_DocTypeFilterInput",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "order",
                    "description": null,
                    "type": {
                      "kind": "LIST",
                      "name": null,
                      "ofType": {
                        "kind": "NON_NULL",
                        "name": null,
                        "ofType": {
                          "kind": "INPUT_OBJECT",
                          "name": "saleorder_4_SH_ScreenLaunch_DocTypeSortInput",
                          "ofType": null
                        }
                      }
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_DocType",
                      "ofType": null
                    }
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "message",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_getCustomerItemdetail",
            "description": null,
            "fields": [
              {
                "name": "data",
                "description": null,
                "args": [
                  {
                    "name": "where",
                    "description": null,
                    "type": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_ItemDetailInfoFilterInput",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "order",
                    "description": null,
                    "type": {
                      "kind": "LIST",
                      "name": null,
                      "ofType": {
                        "kind": "NON_NULL",
                        "name": null,
                        "ofType": {
                          "kind": "INPUT_OBJECT",
                          "name": "saleorder_4_SH_ScreenLaunch_ItemDetailInfoSortInput",
                          "ofType": null
                        }
                      }
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_ItemDetailInfo",
                      "ofType": null
                    }
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "message",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_getCustomerMaster",
            "description": null,
            "fields": [
              {
                "name": "data",
                "description": null,
                "args": [],
                "type": {
                  "kind": "OBJECT",
                  "name": "saleorder_4_SH_ScreenLaunch_CustomerMaster",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "message",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_getCustomerMetalist",
            "description": null,
            "fields": [
              {
                "name": "data",
                "description": null,
                "args": [
                  {
                    "name": "where",
                    "description": null,
                    "type": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_CustomerMetaInfoFilterInput",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "order",
                    "description": null,
                    "type": {
                      "kind": "LIST",
                      "name": null,
                      "ofType": {
                        "kind": "NON_NULL",
                        "name": null,
                        "ofType": {
                          "kind": "INPUT_OBJECT",
                          "name": "saleorder_4_SH_ScreenLaunch_CustomerMetaInfoSortInput",
                          "ofType": null
                        }
                      }
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_CustomerMetaInfo",
                      "ofType": null
                    }
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "message",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_getCustomerStockstatus",
            "description": null,
            "fields": [
              {
                "name": "data",
                "description": null,
                "args": [
                  {
                    "name": "where",
                    "description": null,
                    "type": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_StockStatusFilterInput",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "order",
                    "description": null,
                    "type": {
                      "kind": "LIST",
                      "name": null,
                      "ofType": {
                        "kind": "NON_NULL",
                        "name": null,
                        "ofType": {
                          "kind": "INPUT_OBJECT",
                          "name": "saleorder_4_SH_ScreenLaunch_StockStatusSortInput",
                          "ofType": null
                        }
                      }
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_StockStatus",
                      "ofType": null
                    }
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "message",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_getCustomerSummary",
            "description": null,
            "fields": [
              {
                "name": "data",
                "description": null,
                "args": [
                  {
                    "name": "where",
                    "description": null,
                    "type": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_SummaryInfoFilterInput",
                      "ofType": null
                    },
                    "defaultValue": null
                  },
                  {
                    "name": "order",
                    "description": null,
                    "type": {
                      "kind": "LIST",
                      "name": null,
                      "ofType": {
                        "kind": "NON_NULL",
                        "name": null,
                        "ofType": {
                          "kind": "INPUT_OBJECT",
                          "name": "saleorder_4_SH_ScreenLaunch_SummaryInfoSortInput",
                          "ofType": null
                        }
                      }
                    },
                    "defaultValue": null
                  }
                ],
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_SummaryInfo",
                      "ofType": null
                    }
                  }
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "message",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_PositionInfoInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "color",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "count",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "position",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_PositionInfoFilterInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "and",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_PositionInfoFilterInput",
                      "ofType": null
                    }
                  }
                },
                "defaultValue": null
              },
              {
                "name": "or",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_PositionInfoFilterInput",
                      "ofType": null
                    }
                  }
                },
                "defaultValue": null
              },
              {
                "name": "color",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "count",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "ComparableNullableOfInt32OperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "position",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_PositionInfoSortInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "color",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "count",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "position",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_DetailInfoFilterInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "and",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_DetailInfoFilterInput",
                      "ofType": null
                    }
                  }
                },
                "defaultValue": null
              },
              {
                "name": "or",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_DetailInfoFilterInput",
                      "ofType": null
                    }
                  }
                },
                "defaultValue": null
              },
              {
                "name": "additionalDocs",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "amendmentNo",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "authorized",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "availableStock",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "ComparableNullableOfInt32OperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "currentPosition",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "currentPositionTPL",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "docType",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "liveTrackingAll",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "liveTrackingChennai",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "liveTrackingDelhi",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "liveTrackingMumbai",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "modeFlag",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "rowNo",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "ComparableNullableOfInt32OperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockStatus",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockStatusCode",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockStatusDesc",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "viewGR",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "positionInfo",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "saleorder_4_SH_ScreenLaunch_PositionInfoFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_DetailInfoSortInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "additionalDocs",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "amendmentNo",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "authorized",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "availableStock",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "currentPosition",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "currentPositionTPL",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "docType",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "liveTrackingAll",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "liveTrackingChennai",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "liveTrackingDelhi",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "liveTrackingMumbai",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "modeFlag",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "rowNo",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockStatus",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockStatusCode",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockStatusDesc",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "viewGR",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "positionInfo",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "saleorder_4_SH_ScreenLaunch_PositionInfoSortInput",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_DocTypeFilterInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "and",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_DocTypeFilterInput",
                      "ofType": null
                    }
                  }
                },
                "defaultValue": null
              },
              {
                "name": "or",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_DocTypeFilterInput",
                      "ofType": null
                    }
                  }
                },
                "defaultValue": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "docTypeCode",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "docTypeName",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_DocTypeSortInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "customOutput1",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "docTypeCode",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "docTypeName",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_ItemDetailInfoFilterInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "and",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_ItemDetailInfoFilterInput",
                      "ofType": null
                    }
                  }
                },
                "defaultValue": null
              },
              {
                "name": "or",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_ItemDetailInfoFilterInput",
                      "ofType": null
                    }
                  }
                },
                "defaultValue": null
              },
              {
                "name": "currency",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customerPoNo",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "itemCode",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "itemDesc",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "itemImage",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "itemPrice",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "ComparableNullableOfSingleOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "itemRemarks",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "itemType",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "modeFlag",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "orderType",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "quoteNo",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "rowNo",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "ComparableNullableOfInt32OperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockDispatchedDate",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "ComparableNullableOfDateTimeOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockReceivedTime",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "ComparableNullableOfDateTimeOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockUpdatedDate",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "ComparableNullableOfDateTimeOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_ItemDetailInfoSortInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "currency",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customerPoNo",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "itemCode",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "itemDesc",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "itemImage",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "itemPrice",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "itemRemarks",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "itemType",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "modeFlag",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "orderType",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "quoteNo",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "rowNo",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockDispatchedDate",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockReceivedTime",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockUpdatedDate",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_CustomerMetaInfoFilterInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "and",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_CustomerMetaInfoFilterInput",
                      "ofType": null
                    }
                  }
                },
                "defaultValue": null
              },
              {
                "name": "or",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_CustomerMetaInfoFilterInput",
                      "ofType": null
                    }
                  }
                },
                "defaultValue": null
              },
              {
                "name": "code",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "descr",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "entityType",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_CustomerMetaInfoSortInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "code",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "descr",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "entityType",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_StockStatusFilterInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "and",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_StockStatusFilterInput",
                      "ofType": null
                    }
                  }
                },
                "defaultValue": null
              },
              {
                "name": "or",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_StockStatusFilterInput",
                      "ofType": null
                    }
                  }
                },
                "defaultValue": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockStatusName",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_StockStatusSortInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "customOutput1",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "stockStatusName",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_SummaryInfoFilterInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "and",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_SummaryInfoFilterInput",
                      "ofType": null
                    }
                  }
                },
                "defaultValue": null
              },
              {
                "name": "or",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "INPUT_OBJECT",
                      "name": "saleorder_4_SH_ScreenLaunch_SummaryInfoFilterInput",
                      "ofType": null
                    }
                  }
                },
                "defaultValue": null
              },
              {
                "name": "color",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "count",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "ComparableNullableOfInt32OperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "docStatus",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "docTemplate",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "StringOperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "rowIndicatior",
                "description": null,
                "type": {
                  "kind": "INPUT_OBJECT",
                  "name": "ComparableNullableOfInt32OperationFilterInput",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_SummaryInfoSortInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "color",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "count",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "docStatus",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "docTemplate",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "rowIndicatior",
                "description": null,
                "type": {
                  "kind": "ENUM",
                  "name": "SortEnumType",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "StringOperationFilterInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "and",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "INPUT_OBJECT",
                      "name": "StringOperationFilterInput",
                      "ofType": null
                    }
                  }
                },
                "defaultValue": null
              },
              {
                "name": "or",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "NON_NULL",
                    "name": null,
                    "ofType": {
                      "kind": "INPUT_OBJECT",
                      "name": "StringOperationFilterInput",
                      "ofType": null
                    }
                  }
                },
                "defaultValue": null
              },
              {
                "name": "eq",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "neq",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "contains",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "ncontains",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "in",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "String",
                    "ofType": null
                  }
                },
                "defaultValue": null
              },
              {
                "name": "nin",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "String",
                    "ofType": null
                  }
                },
                "defaultValue": null
              },
              {
                "name": "startsWith",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "nstartsWith",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "endsWith",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "nendsWith",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "ComparableNullableOfInt32OperationFilterInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "eq",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "neq",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "in",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "Int",
                    "ofType": null
                  }
                },
                "defaultValue": null
              },
              {
                "name": "nin",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "Int",
                    "ofType": null
                  }
                },
                "defaultValue": null
              },
              {
                "name": "gt",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "ngt",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "gte",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "ngte",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "lt",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "nlt",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "lte",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "nlte",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "ENUM",
            "name": "SortEnumType",
            "description": null,
            "fields": null,
            "inputFields": null,
            "interfaces": null,
            "enumValues": [
              {
                "name": "ASC",
                "description": null,
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "DESC",
                "description": null,
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "ComparableNullableOfSingleOperationFilterInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "eq",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Float",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "neq",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Float",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "in",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "Float",
                    "ofType": null
                  }
                },
                "defaultValue": null
              },
              {
                "name": "nin",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "Float",
                    "ofType": null
                  }
                },
                "defaultValue": null
              },
              {
                "name": "gt",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Float",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "ngt",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Float",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "gte",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Float",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "ngte",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Float",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "lt",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Float",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "nlt",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Float",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "lte",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Float",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "nlte",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "Float",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "INPUT_OBJECT",
            "name": "ComparableNullableOfDateTimeOperationFilterInput",
            "description": null,
            "fields": null,
            "inputFields": [
              {
                "name": "eq",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "neq",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "in",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "LocalDateTime",
                    "ofType": null
                  }
                },
                "defaultValue": null
              },
              {
                "name": "nin",
                "description": null,
                "type": {
                  "kind": "LIST",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "LocalDateTime",
                    "ofType": null
                  }
                },
                "defaultValue": null
              },
              {
                "name": "gt",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "ngt",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "gte",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "ngte",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "lt",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "nlt",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "lte",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "nlte",
                "description": null,
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "defaultValue": null
              }
            ],
            "interfaces": null,
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_PositionInfo",
            "description": null,
            "fields": [
              {
                "name": "color",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "count",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "position",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_DetailInfo",
            "description": null,
            "fields": [
              {
                "name": "additionalDocs",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "amendmentNo",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "authorized",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "availableStock",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "currentPosition",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "currentPositionTPL",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "docType",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "liveTrackingAll",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "liveTrackingChennai",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "liveTrackingDelhi",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "liveTrackingMumbai",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "modeFlag",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "rowNo",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "stockStatus",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "stockStatusCode",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "stockStatusDesc",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "viewGR",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "positionInfo",
                "description": null,
                "args": [],
                "type": {
                  "kind": "OBJECT",
                  "name": "saleorder_4_SH_ScreenLaunch_PositionInfo",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_DocType",
            "description": null,
            "fields": [
              {
                "name": "customOutput1",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "docTypeCode",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "docTypeName",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_ItemDetailInfo",
            "description": null,
            "fields": [
              {
                "name": "currency",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "customerPoNo",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "itemCode",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "itemDesc",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "itemImage",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "itemPrice",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "Float",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "itemRemarks",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "itemType",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "modeFlag",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "orderType",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "quoteNo",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "rowNo",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "stockDispatchedDate",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "stockReceivedTime",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "stockUpdatedDate",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_CustomerMaster",
            "description": null,
            "fields": [
              {
                "name": "categoryCode",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "categoryDesc",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "contextOu",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "currency",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "customer",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "customerPoNo",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "deliveryTime",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "dispatchDate",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "liveTrack",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "liveTrackingAll",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "liveTrackingChennai",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "liveTrackingDelhi",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "liveTrackingMumbai",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "mode",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "orderType",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "priority",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "quoteNo",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "remarks",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "reqLocation",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "reqStatus",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "reqStatusCode",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "reqStatusDesc",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "rfqDate",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "LocalDateTime",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "rfqno",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "saleType",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "totalAmount",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "urgent",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_CustomerMetaInfo",
            "description": null,
            "fields": [
              {
                "name": "code",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "descr",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "entityType",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_StockStatus",
            "description": null,
            "fields": [
              {
                "name": "customOutput1",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "stockStatusName",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          },
          {
            "kind": "OBJECT",
            "name": "saleorder_4_SH_ScreenLaunch_SummaryInfo",
            "description": null,
            "fields": [
              {
                "name": "color",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "count",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "customOutput1",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "customOutput2",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "docStatus",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "docTemplate",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              },
              {
                "name": "rowIndicatior",
                "description": null,
                "args": [],
                "type": {
                  "kind": "SCALAR",
                  "name": "Int",
                  "ofType": null
                },
                "isDeprecated": false,
                "deprecationReason": null
              }
            ],
            "inputFields": null,
            "interfaces": [],
            "enumValues": null,
            "possibleTypes": null
          }
        ],
        "directives": [
          {
            "name": "skip",
            "description": "Directs the executor to skip this field or fragment when the `if` argument is true.",
            "locations": [
              "FIELD",
              "FRAGMENT_SPREAD",
              "INLINE_FRAGMENT"
            ],
            "args": [
              {
                "name": "if",
                "description": "Skipped when true.",
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "Boolean",
                    "ofType": null
                  }
                },
                "defaultValue": null
              }
            ]
          },
          {
            "name": "include",
            "description": "Directs the executor to include this field or fragment only when the `if` argument is true.",
            "locations": [
              "FIELD",
              "FRAGMENT_SPREAD",
              "INLINE_FRAGMENT"
            ],
            "args": [
              {
                "name": "if",
                "description": "Included when true.",
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "Boolean",
                    "ofType": null
                  }
                },
                "defaultValue": null
              }
            ]
          },
          {
            "name": "defer",
            "description": "The `@defer` directive may be provided for fragment spreads and inline fragments to inform the executor to delay the execution of the current fragment to indicate deprioritization of the current fragment. A query with `@defer` directive will cause the request to potentially return multiple responses, where non-deferred data is delivered in the initial response and data deferred is delivered in a subsequent response. `@include` and `@skip` take precedence over `@defer`.",
            "locations": [
              "FRAGMENT_SPREAD",
              "INLINE_FRAGMENT"
            ],
            "args": [
              {
                "name": "label",
                "description": "If this argument label has a value other than null, it will be passed on to the result of this defer directive. This label is intended to give client applications a way to identify to which fragment a deferred result belongs to.",
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "if",
                "description": "Deferred when true.",
                "type": {
                  "kind": "SCALAR",
                  "name": "Boolean",
                  "ofType": null
                },
                "defaultValue": null
              }
            ]
          },
          {
            "name": "stream",
            "description": "The `@stream` directive may be provided for a field of `List` type so that the backend can leverage technology such as asynchronous iterators to provide a partial list in the initial response, and additional list items in subsequent responses. `@include` and `@skip` take precedence over `@stream`.",
            "locations": [
              "FIELD"
            ],
            "args": [
              {
                "name": "label",
                "description": "If this argument label has a value other than null, it will be passed on to the result of this stream directive. This label is intended to give client applications a way to identify to which fragment a streamed result belongs to.",
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": null
              },
              {
                "name": "initialCount",
                "description": "The initial elements that shall be send down to the consumer.",
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "Int",
                    "ofType": null
                  }
                },
                "defaultValue": "0"
              },
              {
                "name": "if",
                "description": "Streamed when true.",
                "type": {
                  "kind": "SCALAR",
                  "name": "Boolean",
                  "ofType": null
                },
                "defaultValue": null
              }
            ]
          },
          {
            "name": "deprecated",
            "description": "The @deprecated directive is used within the type system definition language to indicate deprecated portions of a GraphQL service’s schema,such as deprecated fields on a type or deprecated enum values.",
            "locations": [
              "FIELD_DEFINITION",
              "ENUM_VALUE"
            ],
            "args": [
              {
                "name": "reason",
                "description": "Deprecations include a reason for why it is deprecated, which is formatted using Markdown syntax (as specified by CommonMark).",
                "type": {
                  "kind": "SCALAR",
                  "name": "String",
                  "ofType": null
                },
                "defaultValue": "\"No longer supported.\""
              }
            ]
          },
          {
            "name": "specifiedBy",
            "description": "The `@specifiedBy` directive is used within the type system definition language to provide a URL for specifying the behavior of custom scalar definitions.",
            "locations": [
              "SCALAR"
            ],
            "args": [
              {
                "name": "url",
                "description": "The specifiedBy URL points to a human-readable specification. This field will only read a result for scalar types.",
                "type": {
                  "kind": "NON_NULL",
                  "name": null,
                  "ofType": {
                    "kind": "SCALAR",
                    "name": "String",
                    "ofType": null
                  }
                },
                "defaultValue": null
              }
            ]
          }
        ]
      }
    }
  },
"queryMappingObject":{
    // "taskName":"saomainscfth",
    // "queryName":"saleorder_SH_ScreenLaunch.getMetaList",
    //  "sequence": "1"
    },
"controlIdList":[
    {
      "control_id": "chkurgent",
      "view_name": "chkurgent"
    },
    {
      "control_id": "cmbcategory",
      "view_name": "cmbcategory"
    },
    {
      "control_id": "cmbcategory",
      "view_name": "enum_vw_SAO_mainsc_catego"
    },
    {
      "control_id": "cmbreqlocation",
      "view_name": "cmbreqlocation"
    },
    {
      "control_id": "cmbreqstatus",
      "view_name": "cmbreqstatus"
    },
    {
      "control_id": "cmbreqstatus",
      "view_name": "hhdnreqstatus"
    },
    {
      "control_id": "cmbsaletype",
      "view_name": "cmbsaletype"
    },
    {
      "control_id": "datrfqdate",
      "view_name": "datrfqdate"
    },
    {
      "control_id": "dsprfqno",
      "view_name": "dsprfqno"
    },
    {
      "control_id": "dttdispatchdate",
      "view_name": "dttdispatchdate"
    },
    {
      "control_id": "dvhdoctemplate",
      "view_name": "1"
    },
    {
      "control_id": "dvhdoctemplate",
      "view_name": "2"
    },
    {
      "control_id": "dvhdoctemplate",
      "view_name": "3"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "1"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "10"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "1001"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "1002"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "11"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "12"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "13"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "2"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "3"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "4"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "5"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "6"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "7"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "8"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "9"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "1"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "10"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "1001"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "1003"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "11"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "12"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "13"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "2"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "3"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "4"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "5"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "6"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "7"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "8"
    },
    {
      "contr ol_id": "grditemgrid",
      "view_name": "9"
    },
    {
      "control_id": "hdndoctemplate_rid",
      "view_name": "hdndoctemplate_rid"
    },
    {
      "control_id": "HDNhdnrt_stcontrol",
      "view_name": "HDNhdnrt_stcontrol"
    },
    {
      "control_id": "HDNPrj_hdn_ctrl",
      "view_name": "HDNPrj_hdn_ctrl"
    },
    {
      "control_id": "imgsupportdocs",
      "view_name": "hdnsupportdocsDBC"
    },
    {
      "control_id": "imgsupportdocs",
      "view_name": "imgsupportdocs"
    },
    {
      "control_id": "lstcustomer",
      "view_name": "lstcustomer"
    },
    {
      "control_id": "numhdnhdrou",
      "view_name": "numhdnhdrou"
    },
    {
      "control_id": "numtotalamount",
      "view_name": "numtotalamount"
    },
    {
      "control_id": "rbgmode",
      "view_name": "rad_vw_SAO_mainsc_mode1"
    },
    {
      "control_id": "rbgmode",
      "view_name": "rbgmode"
    },
    {
      "control_id": "timdeliverytime",
      "view_name": "timdeliverytime"
    },
    {
      "control_id": "txaremarks",
      "view_name": "txaremarks"
    },
    {
      "control_id": "txtcurrency",
      "view_name": "txtcurrency"
    },
    {
      "control_id": "txtcustomerpono",
      "view_name": "txtcustomerpono"
    },
    {
      "control_id": "txtordertype",
      "view_name": "txtordertype"
    },
    {
      "control_id": "txtpriority",
      "view_name": "txtpriority"
    },
    {
      "control_id": "txtquoteno",
      "view_name": "txtquoteno"
    },
    {
      "control_id": "uicustomerlist",
      "view_name": "uicustomerlist1"
    },
    {
      "control_id": "uicustomerlist",
      "view_name": "uicustomerlist2"
    },
    {
      "control_id": "uidoctypelist",
      "view_name": "uidoctypelist1"
    },
    {
      "control_id": "uidoctypelist",
      "view_name": "uidoctypelist2"
    }
  ],
"taskSequenceList":[
	
	{
		"queryName":"saleorder_SH_ScreenLaunch.deleteCustomerDetail",
		"version":"1.0.0",
    "type": "Mutation",
	},
	{
		"queryName":"saleorder_SH_ScreenLaunch.getMetaList",
		"version":"1.0.0",
    "type": "Mutation",
	},
	{
		"queryName":"saleorder_SH_ScreenLaunch.getStockStatus",
		"version":"1.0.0",
    "type": "Mutation",
	},
	{
		"queryName":"saleorder_SH_ScreenLaunch.getSummaryInfo",
		"version":"1.0.0",
    "type": "Mutation",
	},
	{
		"queryName":"saleorder_SH_ScreenLaunch.getCustomerDetail",
		"version":"1.0.0",
    "type": "Mutation",
	}
],

}