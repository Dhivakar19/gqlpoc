
import { render } from 'react-dom';
import SchemaVisualizer from './SchemaVisualizer'
import * as React from 'react';
import  {loadingData} from './loadingMockData';





class SchemaFunctions {

  constructor() {

  }
  loadInterospectionQuery(query: any,taskObject:any,queryMappingObject:any,controlIdList:any,taskSequenceList:any) {
    render(
      React.createElement(SchemaVisualizer, { introspectionQuery: query,taskObject:taskObject,queryMappingObject:queryMappingObject
        ,controlIdList:controlIdList,taskSequenceList:taskSequenceList }, null),
      document.getElementById('root')
    );
  }
}

var VSFunctions = new SchemaFunctions();
window["VSFunctions"] = VSFunctions;
window.onload = function() {
  const {introspectionQuery,taskObject,queryMappingObject,controlIdList,taskSequenceList} = loadingData;
  VSFunctions.loadInterospectionQuery(introspectionQuery,taskObject,queryMappingObject,controlIdList,taskSequenceList);
};








