export type WorkerCallback = (
  path: string,
  relative: boolean,
) => Promise<Worker>;
