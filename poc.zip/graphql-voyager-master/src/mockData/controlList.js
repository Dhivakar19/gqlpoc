export const controlList = [
    {
      "control_id": "chkurgent",
      "view_name": "chkurgent"
    },
    {
      "control_id": "cmbcategory",
      "view_name": "cmbcategory"
    },
    {
      "control_id": "cmbcategory",
      "view_name": "enum_vw_SAO_mainsc_catego"
    },
    {
      "control_id": "cmbreqlocation",
      "view_name": "cmbreqlocation"
    },
    {
      "control_id": "cmbreqstatus",
      "view_name": "cmbreqstatus"
    },
    {
      "control_id": "cmbreqstatus",
      "view_name": "hhdnreqstatus"
    },
    {
      "control_id": "cmbsaletype",
      "view_name": "cmbsaletype"
    },
    {
      "control_id": "datrfqdate",
      "view_name": "datrfqdate"
    },
    {
      "control_id": "dsprfqno",
      "view_name": "dsprfqno"
    },
    {
      "control_id": "dttdispatchdate",
      "view_name": "dttdispatchdate"
    },
    {
      "control_id": "dvhdoctemplate",
      "view_name": "1"
    },
    {
      "control_id": "dvhdoctemplate",
      "view_name": "2"
    },
    {
      "control_id": "dvhdoctemplate",
      "view_name": "3"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "1"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "10"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "1001"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "1002"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "11"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "12"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "13"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "2"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "3"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "4"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "5"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "6"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "7"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "8"
    },
    {
      "control_id": "grddetgrid",
      "view_name": "9"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "1"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "10"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "1001"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "1003"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "11"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "12"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "13"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "2"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "3"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "4"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "5"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "6"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "7"
    },
    {
      "control_id": "grditemgrid",
      "view_name": "8"
    },
    {
      "contr ol_id": "grditemgrid",
      "view_name": "9"
    },
    {
      "control_id": "hdndoctemplate_rid",
      "view_name": "hdndoctemplate_rid"
    },
    {
      "control_id": "HDNhdnrt_stcontrol",
      "view_name": "HDNhdnrt_stcontrol"
    },
    {
      "control_id": "HDNPrj_hdn_ctrl",
      "view_name": "HDNPrj_hdn_ctrl"
    },
    {
      "control_id": "imgsupportdocs",
      "view_name": "hdnsupportdocsDBC"
    },
    {
      "control_id": "imgsupportdocs",
      "view_name": "imgsupportdocs"
    },
    {
      "control_id": "lstcustomer",
      "view_name": "lstcustomer"
    },
    {
      "control_id": "numhdnhdrou",
      "view_name": "numhdnhdrou"
    },
    {
      "control_id": "numtotalamount",
      "view_name": "numtotalamount"
    },
    {
      "control_id": "rbgmode",
      "view_name": "rad_vw_SAO_mainsc_mode1"
    },
    {
      "control_id": "rbgmode",
      "view_name": "rbgmode"
    },
    {
      "control_id": "timdeliverytime",
      "view_name": "timdeliverytime"
    },
    {
      "control_id": "txaremarks",
      "view_name": "txaremarks"
    },
    {
      "control_id": "txtcurrency",
      "view_name": "txtcurrency"
    },
    {
      "control_id": "txtcustomerpono",
      "view_name": "txtcustomerpono"
    },
    {
      "control_id": "txtordertype",
      "view_name": "txtordertype"
    },
    {
      "control_id": "txtpriority",
      "view_name": "txtpriority"
    },
    {
      "control_id": "txtquoteno",
      "view_name": "txtquoteno"
    },
    {
      "control_id": "uicustomerlist",
      "view_name": "uicustomerlist1"
    },
    {
      "control_id": "uicustomerlist",
      "view_name": "uicustomerlist2"
    },
    {
      "control_id": "uidoctypelist",
      "view_name": "uidoctypelist1"
    },
    {
      "control_id": "uidoctypelist",
      "view_name": "uidoctypelist2"
    }
  ]