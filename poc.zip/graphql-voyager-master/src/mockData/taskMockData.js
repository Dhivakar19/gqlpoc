export const mockTaskData = {
    "tasks": [
      {
        "name": "saomainsccreatetr",
        "type": "Trans",
        "queries": [
          {
            "name": "saleorder_SH_ScreenLaunch",
            "type": "Mutation",
            "version": "1.0.0",
            "sequence": "1",
            "args": [],
            "inputFields": [
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.categoryDesc",
                "control_id": "cmbcategory",
                "view_name": "cmbcategory",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.reqLocation",
                "control_id": "cmbreqlocation",
                "view_name": "cmbreqlocation",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.reqStatusDesc",
                "control_id": "cmbreqstatus",
                "view_name": "cmbreqstatus",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.reqStatusCode",
                "control_id": "cmbreqstatus",
                "view_name": "hhdnreqstatus",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.saleType",
                "control_id": "cmbsaletype",
                "view_name": "cmbsaletype",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.liveTrack",
                "control_id": "dlklivetrack",
                "view_name": "dlklivetrack",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.liveTrackingAll",
                "control_id": "dlklivetrackall",
                "view_name": "dlklivetrackall",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.liveTrackingChennai",
                "control_id": "dlklivetrackch",
                "view_name": "dlklivetrackch",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.liveTrackingDelhi",
                "control_id": "dlklivetrackdh",
                "view_name": "dlklivetrackdh",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.liveTrackingMumbai",
                "control_id": "dlklivetrackmb",
                "view_name": "dlklivetrackmb",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.rfqno",
                "control_id": "dsprfqno",
                "view_name": "dsprfqno",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.docType",
                "control_id": "grddetgrid",
                "view_name": "1",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.liveTrackingAll",
                "control_id": "grddetgrid",
                "view_name": "10",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.stockStatusCode",
                "control_id": "grddetgrid",
                "view_name": "1002",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.liveTrackingChennai",
                "control_id": "grddetgrid",
                "view_name": "11",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.liveTrackingMumbai",
                "control_id": "grddetgrid",
                "view_name": "12",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.liveTrackingDelhi",
                "control_id": "grddetgrid",
                "view_name": "13",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.authorized",
                "control_id": "grddetgrid",
                "view_name": "2",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.amendmentNo",
                "control_id": "grddetgrid",
                "view_name": "3",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.stockStatusDesc",
                "control_id": "grddetgrid",
                "view_name": "4",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.currentPosition",
                "control_id": "grddetgrid",
                "view_name": "5",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.availableStock",
                "control_id": "grddetgrid",
                "view_name": "6",
                "data_type": "Int",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.currentPositionTPL",
                "control_id": "grddetgrid",
                "view_name": "7",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.viewGR",
                "control_id": "grddetgrid",
                "view_name": "8",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.modeFlag",
                "control_id": "grddetgrid",
                "view_name": "modeflag",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDetail.DetailInfoInput.rowNo",
                "control_id": "grddetgrid",
                "view_name": "rowno",
                "data_type": "Int",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.itemCode",
                "control_id": "grditemgrid",
                "view_name": "1",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.orderType",
                "control_id": "grditemgrid",
                "view_name": "10",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.customerPoNo",
                "control_id": "grditemgrid",
                "view_name": "11",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.quoteNo",
                "control_id": "grditemgrid",
                "view_name": "12",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.currency",
                "control_id": "grditemgrid",
                "view_name": "13",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.itemImage",
                "control_id": "grditemgrid",
                "view_name": "2",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.itemDesc",
                "control_id": "grditemgrid",
                "view_name": "3",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.itemType",
                "control_id": "grditemgrid",
                "view_name": "7",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.itemPrice",
                "control_id": "grditemgrid",
                "view_name": "8",
                "data_type": "Int",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.itemRemarks",
                "control_id": "grditemgrid",
                "view_name": "9",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.modeFlag",
                "control_id": "grditemgrid",
                "view_name": "modeflag",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerDtlInfo.ItemDetailInfoInput.rowNo",
                "control_id": "grditemgrid",
                "view_name": "rowno",
                "data_type": "Int",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.contextOu",
                "control_id": "numhdnhdrou",
                "view_name": "numhdnhdrou",
                "data_type": "Int",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.totalAmount",
                "control_id": "numtotalamount",
                "view_name": "numtotalamount",
                "data_type": "Int",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.mode",
                "control_id": "rbgmode",
                "view_name": "rbgmode",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.remarks",
                "control_id": "txaremarks",
                "view_name": "txaremarks",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.currency",
                "control_id": "txtcurrency",
                "view_name": "txtcurrency",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.customerPoNo",
                "control_id": "txtcustomerpono",
                "view_name": "txtcustomerpono",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.orderType",
                "control_id": "txtordertype",
                "view_name": "txtordertype",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.priority",
                "control_id": "txtpriority",
                "view_name": "txtpriority",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.quoteNo",
                "control_id": "txtquoteno",
                "view_name": "txtquoteno",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.postCustomerMaster.CustomerMasterInput.customer",
                "control_id": "uicustomerlist",
                "view_name": "uicustomerlist",
                "data_type": "String",
                "mapped":"yes"
              }
            ],
            "fields": []
          }
        ]
      },
      {
        "name": "saomainscfth",
        "type": "Fetch",
        "queries": [
          {
            "name": "saleorder_SH_ScreenLaunch.getMetaList",
            "alias": "Location",
            "type": "Mutation",
            "version": "1.0.0",
            "sequence": "1",
            "args": [
              {
                "default_value": "Location",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.getMetaList.entityType",
                "control_id": "",
                "view_name": "",
                "data_type": "String",
                "mapped":"no"
              }
            ],
            "inputFields": [],
            "fields": [
              {
                "usage": "lookup value",
                "name": "saleorder_SH_ScreenLaunch.getMetaList.data.descr",
                "control_id": "cmbreqlocation",
                "view_name": "cmbreqlocation",
                "data_type": "String",
                "mapped":"yes"
              }
            ]
          },
          {
            "name": "saleorder_SH_ScreenLaunch.getMetaList",
            "alias": "StockStatus",
            "type": "Mutation",
            "version": "1.0.0",
            "sequence": "2",
            "args": [
              {
                "default_value": "StockStatus",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.getMetaList.entityType",
                "control_id": "",
                "view_name": "",
                "data_type": "String"
              }
            ],
            "inputFields": [],
            "fields": [
              {
                "usage": "lookup value",
                "name": "saleorder_SH_ScreenLaunch.getMetaList.data.code",
                "control_id": "grddetgrid",
                "view_name": "1002",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "lookup value",
                "name": "saleorder_SH_ScreenLaunch.getMetaList.data.descr",
                "control_id": "grddetgrid",
                "view_name": "4",
                "data_type": "String",
                "mapped":"yes"
              }
            ]
          },
          {
            "name": "saleorder_SH_ScreenLaunch.getMetaList",
            "alias": "Customer",
            "type": "Mutation",
            "version": "1.0.0",
            "sequence": "3",
            "args": [
              {
                "default_value": "Customer",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.getMetaList.entityType",
                "control_id": "",
                "view_name": "",
                "data_type": "String"
              }
            ],
            "inputFields": [],
            "fields": [
              {
                "usage": "lookup value",
                "name": "saleorder_SH_ScreenLaunch.getMetaList.data.descr",
                "control_id": "uicustomerlist",
                "view_name": "uicustomerlist1",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "lookup value",
                "name": "saleorder_SH_ScreenLaunch.getMetaList.data.code",
                "control_id": "uicustomerlist",
                "view_name": "uicustomerlist2",
                "data_type": "String",
                "mapped":"yes"
              }
            ]
          },
          {
            "name": "saleorder_SH_ScreenLaunch.getMetaList",
            "alias": "Status",
            "type": "Mutation",
            "version": "1.0.0",
            "sequence": "4",
            "args": [
              {
                "default_value": "Status",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.getMetaList.entityType",
                "control_id": "",
                "view_name": "",
                "data_type": "String"
              }
            ],
            "inputFields": [],
            "fields": [
              {
                "usage": "lookup value",
                "name": "saleorder_SH_ScreenLaunch.getMetaList.data.descr",
                "control_id": "cmbreqstatus",
                "view_name": "cmbreqstatus",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "lookup value",
                "name": "saleorder_SH_ScreenLaunch.getMetaList.data.code",
                "control_id": "cmbreqstatus",
                "view_name": "hhdnreqstatus",
                "data_type": "String",
                "mapped":"yes"
              }
            ]
          },
          {
            "name": "saleorder_SH_ScreenLaunch.getMetaList",
            "alias": "Type",
            "type": "Mutation",
            "version": "1.0.0",
            "sequence": "5",
            "args": [
              {
                "default_value": "Type",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.getMetaList.entityType",
                "control_id": "",
                "view_name": "",
                "data_type": "String"
              }
            ],
            "inputFields": [],
            "fields": [
              {
                "usage": "lookup value",
                "name": "saleorder_SH_ScreenLaunch.getMetaList.data.descr",
                "control_id": "grditemgrid",
                "view_name": "7",
                "data_type": "String",
                "mapped":"yes"
              }
            ]
          },
          {
            "name": "saleorder_SH_ScreenLaunch.getMetaList",
            "alias": "SaleType",
            "type": "Mutation",
            "version": "1.0.0",
            "sequence": "6",
            "args": [
              {
                "default_value": "SaleType",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.getMetaList.entityType",
                "control_id": "",
                "view_name": "",
                "data_type": "String"
              }
            ],
            "inputFields": [],
            "fields": [
              {
                "usage": "lookup value",
                "name": "saleorder_SH_ScreenLaunch.getMetaList.data.descr",
                "control_id": "cmbsaletype",
                "view_name": "cmbsaletype",
                "data_type": "String",
                "mapped":"yes"
              }
            ]
          },
          {
            "name": "saleorder_SH_ScreenLaunch.getMetaList",
            "alias": "Category",
            "type": "Mutation",
            "version": "1.0.0",
            "sequence": "7",
            "args": [
              {
                "default_value": "Category",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.getMetaList.entityType",
                "control_id": "",
                "view_name": "",
                "data_type": "String"
              }
            ],
            "inputFields": [],
            "fields": [
              {
                "usage": "lookup value",
                "name": "saleorder_SH_ScreenLaunch.getMetaList.data.descr",
                "control_id": "cmbcategory",
                "view_name": "cmbcategory",
                "data_type": "String",
                "mapped":"yes"
              }
            ]
          },
          {
            "name": "saleorder_SH_ScreenLaunch",
            "type": "Mutation",
            "version": "1.0.0",
            "sequence": "8",
            "args": [
              {
                "default_value": "",
                "required": "no",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.customerCode",
                "control_id": "uicustomerlist",
                "view_name": "uicustomerlist",
                "data_type": "String"
              }
            ],
            "inputFields": [],
            "fields": [
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.urgent",
                "control_id": "chkurgent",
                "view_name": "chkurgent",
                "data_type": "Int",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.categoryCode",
                "control_id": "cmbcategory",
                "view_name": "cmbcategory",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.reqLocation",
                "control_id": "cmbreqlocation",
                "view_name": "cmbreqlocation",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.reqStatus",
                "control_id": "cmbreqstatus",
                "view_name": "cmbreqstatus",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.saleType",
                "control_id": "cmbsaletype",
                "view_name": "cmbsaletype",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.rfqDate",
                "control_id": "datrfqdate",
                "view_name": "datrfqdate",
                "data_type": "LocalDateTime",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.liveTrack",
                "control_id": "dlklivetrack",
                "view_name": "dlklivetrack",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.liveTrackingAll",
                "control_id": "dlklivetrackall",
                "view_name": "dlklivetrackall",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.liveTrackingChennai",
                "control_id": "dlklivetrackch",
                "view_name": "dlklivetrackch",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.liveTrackingDelhi",
                "control_id": "dlklivetrackdh",
                "view_name": "dlklivetrackdh",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.liveTrackingMumbai",
                "control_id": "dlklivetrackmb",
                "view_name": "dlklivetrackmb",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.rfqno",
                "control_id": "dsprfqno",
                "view_name": "dsprfqno",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.dispatchDate",
                "control_id": "dttdispatchdate",
                "view_name": "dttdispatchdate",
                "data_type": "LocalDateTime",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.docType",
                "control_id": "grddetgrid",
                "view_name": "1",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.liveTrackingAll",
                "control_id": "grddetgrid",
                "view_name": "10",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.liveTrackingChennai",
                "control_id": "grddetgrid",
                "view_name": "11",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.liveTrackingMumbai",
                "control_id": "grddetgrid",
                "view_name": "12",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.liveTrackingDelhi",
                "control_id": "grddetgrid",
                "view_name": "13",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.authorized",
                "control_id": "grddetgrid",
                "view_name": "2",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.amendmentNo",
                "control_id": "grddetgrid",
                "view_name": "3",
                "data_type": "String",
                "mapped":"yes"
                
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.stockStatusCode",
                "control_id": "grddetgrid",
                "view_name": "4",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.currentPosition",
                "control_id": "grddetgrid",
                "view_name": "5",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.availableStock",
                "control_id": "grddetgrid",
                "view_name": "6",
                "data_type": "Int",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.currentPositionTPL",
                "control_id": "grddetgrid",
                "view_name": "7",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.viewGR",
                "control_id": "grddetgrid",
                "view_name": "8",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDetail.data.additionalDocs",
                "control_id": "grddetgrid",
                "view_name": "9",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.itemCode",
                "control_id": "grditemgrid",
                "view_name": "1",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.orderType",
                "control_id": "grditemgrid",
                "view_name": "10",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.customerPoNo",
                "control_id": "grditemgrid",
                "view_name": "11",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.quoteNo",
                "control_id": "grditemgrid",
                "view_name": "12",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.currency",
                "control_id": "grditemgrid",
                "view_name": "13",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.itemImage",
                "control_id": "grditemgrid",
                "view_name": "2",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.itemDesc",
                "control_id": "grditemgrid",
                "view_name": "3",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.stockUpdatedDate",
                "control_id": "grditemgrid",
                "view_name": "4",
                "data_type": "LocalDateTime",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.stockDispatchedDate",
                "control_id": "grditemgrid",
                "view_name": "5",
                "data_type": "LocalDateTime",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.stockReceivedTime",
                "control_id": "grditemgrid",
                "view_name": "6",
                "data_type": "LocalDateTime",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.itemType",
                "control_id": "grditemgrid",
                "view_name": "7",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.itemPrice",
                "control_id": "grditemgrid",
                "view_name": "8",
                "data_type": "Float",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerDtlInfo.data.itemRemarks",
                "control_id": "grditemgrid",
                "view_name": "9",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.customer",
                "control_id": "lstcustomer",
                "view_name": "lstcustomer",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.contextOu",
                "control_id": "numhdnhdrou",
                "view_name": "numhdnhdrou",
                "data_type": "Int",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.totalAmount",
                "control_id": "numtotalamount",
                "view_name": "numtotalamount",
                "data_type": "Int",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.mode",
                "control_id": "rbgmode",
                "view_name": "rbgmode",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.deliveryTime",
                "control_id": "timdeliverytime",
                "view_name": "timdeliverytime",
                "data_type": "LocalDateTime",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.remarks",
                "control_id": "txaremarks",
                "view_name": "txaremarks",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.currency",
                "control_id": "txtcurrency",
                "view_name": "txtcurrency",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.customerPoNo",
                "control_id": "txtcustomerpono",
                "view_name": "txtcustomerpono",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.orderType",
                "control_id": "txtordertype",
                "view_name": "txtordertype",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.priority",
                "control_id": "txtpriority",
                "view_name": "txtpriority",
                "data_type": "String",
                "mapped":"yes"
              },
              {
                "usage": "value",
                "name": "saleorder_SH_ScreenLaunch.getCustomerMaster.data.quoteNo",
                "control_id": "txtquoteno",
                "view_name": "txtquoteno",
                "data_type": "String",
                "mapped":"yes"
              }
            ]
          }
        ]
      }
    ],
    "hidden_views": {
      "cmbreqstatus": [
        {
          "view_name": "cmbreqstatus",
          "hidden_view_name": "hhdnreqstatus",
          "datalength": 500,
          "btsynonym": "hdnreqstatus",
          "datatype": "Char"
        }
      ],
      "imgsupportdocs": [
        {
          "view_name": "imgsupportdocs",
          "hidden_view_name": "hdnsupportdocsDBC",
          "datalength": 60,
          "btsynonym": "supportdocsdbc",
          "datatype": "Char"
        }
      ],
      "grddetgrid": [
        {
          "view_name": "4",
          "hidden_view_name": "1002",
          "datalength": 500,
          "btsynonym": "hdnstockstatus",
          "datatype": "Char"
        },
        {
          "view_name": "9",
          "hidden_view_name": "1001",
          "datalength": 60,
          "btsynonym": "additionaldocsdbc",
          "datatype": "Char"
        }
      ],
      "grditemgrid": [
        {
          "view_name": "2",
          "hidden_view_name": "1001",
          "datalength": 60,
          "btsynonym": "item_imagedbc",
          "datatype": "Char"
        }
      ]
    },
    "subscription": {
      "saomainsccurrechp": {
        "linkid": "1010",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "ordertypervw",
        "dataitems": [
          {
            "name": "currency",
            "control_id": "txtcurrency",
            "view_name": "txtcurrency",
            "flow_direction": "2"
          },
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          }
        ]
      },
      "saomainsccustophp": {
        "linkid": "1009",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "ordertypervw",
        "dataitems": [
          {
            "name": "customerpono",
            "control_id": "txtcustomerpono",
            "view_name": "txtcustomerpono",
            "flow_direction": "2"
          }
        ]
      },
      "saomainsclivetalk": {
        "linkid": "1003",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackinggql",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "reqstatus",
            "control_id": "cmbreqstatus",
            "view_name": "cmbreqstatus",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          }
        ]
      },
      "saomainsclivetclk": {
        "linkid": "1005",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackingrvw",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "deliverytime",
            "control_id": "timdeliverytime",
            "view_name": "timdeliverytime",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "reqstatus",
            "control_id": "cmbreqstatus",
            "view_name": "cmbreqstatus",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          }
        ]
      },
      "saomainsclivetklk": {
        "linkid": "1006",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackingrvw",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "deliverytime",
            "control_id": "timdeliverytime",
            "view_name": "timdeliverytime",
            "flow_direction": "1"
          },
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "reqstatus",
            "control_id": "cmbreqstatus",
            "view_name": "cmbreqstatus",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          }
        ]
      },
      "saomainsclivetmlk": {
        "linkid": "1004",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackinggql",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "reqstatus",
            "control_id": "cmbreqstatus",
            "view_name": "cmbreqstatus",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          }
        ]
      },
      "saomainscorderthp": {
        "linkid": "1007",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "ordertypegql",
        "dataitems": [
          {
            "name": "ordertype",
            "control_id": "txtordertype",
            "view_name": "txtordertype",
            "flow_direction": "2"
          }
        ]
      },
      "saomainscpriorihp": {
        "linkid": "1001",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "salespriority",
        "dataitems": [
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "2"
          }
        ]
      },
      "saomainscpriorllk": {
        "linkid": "1006",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackingrvw",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "reqstatus",
            "control_id": "cmbreqstatus",
            "view_name": "cmbreqstatus",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          }
        ]
      },
      "saomainscpriormlk": {
        "linkid": "1004",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackinggql",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "deliverytime",
            "control_id": "timdeliverytime",
            "view_name": "timdeliverytime",
            "flow_direction": "1"
          },
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "reqstatus",
            "control_id": "cmbreqstatus",
            "view_name": "cmbreqstatus",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          }
        ]
      },
      "saomainscpriortlk": {
        "linkid": "1003",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackinggql",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "deliverytime",
            "control_id": "timdeliverytime",
            "view_name": "timdeliverytime",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "reqstatus",
            "control_id": "cmbreqstatus",
            "view_name": "cmbreqstatus",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          }
        ]
      },
      "saomainscpriorylk": {
        "linkid": "1005",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackingrvw",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "reqstatus",
            "control_id": "cmbreqstatus",
            "view_name": "cmbreqstatus",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          }
        ]
      },
      "saomainscquotenhp": {
        "linkid": "1008",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "ordertypegql",
        "dataitems": [
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          },
          {
            "name": "quoteno",
            "control_id": "txtquoteno",
            "view_name": "txtquoteno",
            "flow_direction": "2"
          }
        ]
      },
      "saomainscvwadddlk": {
        "linkid": "1011",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackinggql",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "reqstatus",
            "control_id": "cmbreqstatus",
            "view_name": "cmbreqstatus",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          }
        ]
      },
      "saotblta_curreyhp": {
        "linkid": "1010",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackingrvw",
        "dataitems": [
          {
            "name": "currencyml",
            "control_id": "grditemgrid",
            "view_name": "13",
            "flow_direction": "2"
          },
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          }
        ]
      },
      "saotblta_custoohp": {
        "linkid": "1009",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackingrvw",
        "dataitems": [
          {
            "name": "customerponoml",
            "control_id": "grditemgrid",
            "view_name": "11",
            "flow_direction": "2"
          }
        ]
      },
      "saotblta_orderyhp": {
        "linkid": "1007",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackinggql",
        "dataitems": [
          {
            "name": "ordertypeml",
            "control_id": "grditemgrid",
            "view_name": "10",
            "flow_direction": "2"
          }
        ]
      },
      "saotblta_quoteohp": {
        "linkid": "1008",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackinggql",
        "dataitems": [
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          },
          {
            "name": "quotenoml",
            "control_id": "grditemgrid",
            "view_name": "12",
            "flow_direction": "2"
          }
        ]
      },
      "saotbltabamendmhp": {
        "linkid": "1002",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "salespriority",
        "dataitems": [
          {
            "name": "amendmentno",
            "control_id": "grddetgrid",
            "view_name": "3",
            "flow_direction": "2"
          }
        ]
      },
      "saotbltablivetblk": {
        "linkid": "1004",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackinggql",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "deliverytime",
            "control_id": "timdeliverytime",
            "view_name": "timdeliverytime",
            "flow_direction": "1"
          },
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          },
          {
            "name": "stockstatus",
            "control_id": "grddetgrid",
            "view_name": "4",
            "flow_direction": "1"
          }
        ]
      },
      "saotbltablivetdlk": {
        "linkid": "1006",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackingrvw",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "hdnhdrou",
            "control_id": "numhdnhdrou",
            "view_name": "numhdnhdrou",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          },
          {
            "name": "stockstatus",
            "control_id": "grddetgrid",
            "view_name": "4",
            "flow_direction": "1"
          }
        ]
      },
      "saotbltablivethlk": {
        "linkid": "1005",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackingrvw",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          },
          {
            "name": "stockstatus",
            "control_id": "grddetgrid",
            "view_name": "4",
            "flow_direction": "1"
          }
        ]
      },
      "saotbltablivetllk": {
        "linkid": "1003",
        "target_component": "saleorder",
        "target_activity": "saleshub",
        "target_ui": "livetrackinggql",
        "dataitems": [
          {
            "name": "customer",
            "control_id": "lstcustomer",
            "view_name": "lstcustomer",
            "flow_direction": "1"
          },
          {
            "name": "deliverytime",
            "control_id": "timdeliverytime",
            "view_name": "timdeliverytime",
            "flow_direction": "1"
          },
          {
            "name": "priority",
            "control_id": "txtpriority",
            "view_name": "txtpriority",
            "flow_direction": "1"
          },
          {
            "name": "reqlocation",
            "control_id": "cmbreqlocation",
            "view_name": "cmbreqlocation",
            "flow_direction": "1"
          },
          {
            "name": "rfqdate",
            "control_id": "datrfqdate",
            "view_name": "datrfqdate",
            "flow_direction": "1"
          },
          {
            "name": "rfqno",
            "control_id": "dsprfqno",
            "view_name": "dsprfqno",
            "flow_direction": "1"
          },
          {
            "name": "stockstatus",
            "control_id": "grddetgrid",
            "view_name": "4",
            "flow_direction": "1"
          }
        ]
      }
    },
    "publications": {
      "1014": [
        {
          "name": "additionaldocs",
          "control_id": "grddetgrid",
          "view_name": "9",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "amendmentno",
          "control_id": "grddetgrid",
          "view_name": "3",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "authorized",
          "control_id": "grddetgrid",
          "view_name": "2",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "availablestock",
          "control_id": "grddetgrid",
          "view_name": "6",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "category",
          "control_id": "cmbcategory",
          "view_name": "cmbcategory",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "csou",
          "control_id": "rvwrt_lctxt_ou",
          "view_name": "rvwrt_lctxt_ou",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "currency",
          "control_id": "txtcurrency",
          "view_name": "txtcurrency",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "currencyml",
          "control_id": "grditemgrid",
          "view_name": "13",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "currentposition",
          "control_id": "grddetgrid",
          "view_name": "5",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "currentpositiontpl",
          "control_id": "grddetgrid",
          "view_name": "7",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "customer",
          "control_id": "lstcustomer",
          "view_name": "lstcustomer",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "customerpono",
          "control_id": "txtcustomerpono",
          "view_name": "txtcustomerpono",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "customerponoml",
          "control_id": "grditemgrid",
          "view_name": "11",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "deliverytime",
          "control_id": "timdeliverytime",
          "view_name": "timdeliverytime",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "dispatchdate",
          "control_id": "dttdispatchdate",
          "view_name": "dttdispatchdate",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "doccount",
          "control_id": "dvhdoctemplate",
          "view_name": "2",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "docstatus",
          "control_id": "dvhdoctemplate",
          "view_name": "1",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "doctemplate_rid",
          "control_id": "hdndoctemplate_rid",
          "view_name": "hdndoctemplate_rid",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "doctplid",
          "control_id": "dvhdoctemplate",
          "view_name": "3",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "doctype",
          "control_id": "grddetgrid",
          "view_name": "1",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "hdnhdrou",
          "control_id": "numhdnhdrou",
          "view_name": "numhdnhdrou",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "hdnrt_stcontrol",
          "control_id": "hdnhdnrt_stcontrol",
          "view_name": "hdnhdnrt_stcontrol",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_code",
          "control_id": "grditemgrid",
          "view_name": "1",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_desc",
          "control_id": "grditemgrid",
          "view_name": "3",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_image",
          "control_id": "grditemgrid",
          "view_name": "2",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_price",
          "control_id": "grditemgrid",
          "view_name": "8",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_remarks",
          "control_id": "grditemgrid",
          "view_name": "9",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_type",
          "control_id": "grditemgrid",
          "view_name": "7",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "livetrackallml",
          "control_id": "grddetgrid",
          "view_name": "10",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "livetrackchml",
          "control_id": "grddetgrid",
          "view_name": "11",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "livetrackdhml",
          "control_id": "grddetgrid",
          "view_name": "13",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "livetrackmbml",
          "control_id": "grddetgrid",
          "view_name": "12",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "ordertype",
          "control_id": "txtordertype",
          "view_name": "txtordertype",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "ordertypeml",
          "control_id": "grditemgrid",
          "view_name": "10",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "priority",
          "control_id": "txtpriority",
          "view_name": "txtpriority",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "prj_hdn_ctrl",
          "control_id": "hdnprj_hdn_ctrl",
          "view_name": "hdnprj_hdn_ctrl",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "quoteno",
          "control_id": "txtquoteno",
          "view_name": "txtquoteno",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "quotenoml",
          "control_id": "grditemgrid",
          "view_name": "12",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "remarks",
          "control_id": "txaremarks",
          "view_name": "txaremarks",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "reqlocation",
          "control_id": "cmbreqlocation",
          "view_name": "cmbreqlocation",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "reqstatus",
          "control_id": "cmbreqstatus",
          "view_name": "cmbreqstatus",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "rfqdate",
          "control_id": "datrfqdate",
          "view_name": "datrfqdate",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "rfqno",
          "control_id": "dsprfqno",
          "view_name": "dsprfqno",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "saletype",
          "control_id": "cmbsaletype",
          "view_name": "cmbsaletype",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "stock_dispatched_date",
          "control_id": "grditemgrid",
          "view_name": "5",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "stock_received_time",
          "control_id": "grditemgrid",
          "view_name": "6",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "stock_updated_date",
          "control_id": "grditemgrid",
          "view_name": "4",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "stockstatus",
          "control_id": "grddetgrid",
          "view_name": "4",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "supportdocs",
          "control_id": "imgsupportdocs",
          "view_name": "imgsupportdocs",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "totalamount",
          "control_id": "numtotalamount",
          "view_name": "numtotalamount",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "urgent",
          "control_id": "chkurgent",
          "view_name": "chkurgent",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "viewgr",
          "control_id": "grddetgrid",
          "view_name": "8",
          "flow_direction": "0",
          "multi_instance": "no"
        }
      ],
      "1015": [
        {
          "name": "additionaldocs",
          "control_id": "grddetgrid",
          "view_name": "9",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "amendmentno",
          "control_id": "grddetgrid",
          "view_name": "3",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "authorized",
          "control_id": "grddetgrid",
          "view_name": "2",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "availablestock",
          "control_id": "grddetgrid",
          "view_name": "6",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "category",
          "control_id": "cmbcategory",
          "view_name": "cmbcategory",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "csou",
          "control_id": "rvwrt_lctxt_ou",
          "view_name": "rvwrt_lctxt_ou",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "currency",
          "control_id": "txtcurrency",
          "view_name": "txtcurrency",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "currencyml",
          "control_id": "grditemgrid",
          "view_name": "13",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "currentposition",
          "control_id": "grddetgrid",
          "view_name": "5",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "currentpositiontpl",
          "control_id": "grddetgrid",
          "view_name": "7",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "customer",
          "control_id": "lstcustomer",
          "view_name": "lstcustomer",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "customerpono",
          "control_id": "txtcustomerpono",
          "view_name": "txtcustomerpono",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "customerponoml",
          "control_id": "grditemgrid",
          "view_name": "11",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "deliverytime",
          "control_id": "timdeliverytime",
          "view_name": "timdeliverytime",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "dispatchdate",
          "control_id": "dttdispatchdate",
          "view_name": "dttdispatchdate",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "doccount",
          "control_id": "dvhdoctemplate",
          "view_name": "2",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "docstatus",
          "control_id": "dvhdoctemplate",
          "view_name": "1",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "doctemplate_rid",
          "control_id": "hdndoctemplate_rid",
          "view_name": "hdndoctemplate_rid",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "doctplid",
          "control_id": "dvhdoctemplate",
          "view_name": "3",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "doctype",
          "control_id": "grddetgrid",
          "view_name": "1",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "hdnhdrou",
          "control_id": "numhdnhdrou",
          "view_name": "numhdnhdrou",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "hdnrt_stcontrol",
          "control_id": "hdnhdnrt_stcontrol",
          "view_name": "hdnhdnrt_stcontrol",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_code",
          "control_id": "grditemgrid",
          "view_name": "1",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_desc",
          "control_id": "grditemgrid",
          "view_name": "3",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_image",
          "control_id": "grditemgrid",
          "view_name": "2",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_price",
          "control_id": "grditemgrid",
          "view_name": "8",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_remarks",
          "control_id": "grditemgrid",
          "view_name": "9",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "item_type",
          "control_id": "grditemgrid",
          "view_name": "7",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "livetrackallml",
          "control_id": "grddetgrid",
          "view_name": "10",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "livetrackchml",
          "control_id": "grddetgrid",
          "view_name": "11",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "livetrackdhml",
          "control_id": "grddetgrid",
          "view_name": "13",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "livetrackmbml",
          "control_id": "grddetgrid",
          "view_name": "12",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "ordertype",
          "control_id": "txtordertype",
          "view_name": "txtordertype",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "ordertypeml",
          "control_id": "grditemgrid",
          "view_name": "10",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "priority",
          "control_id": "txtpriority",
          "view_name": "txtpriority",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "prj_hdn_ctrl",
          "control_id": "hdnprj_hdn_ctrl",
          "view_name": "hdnprj_hdn_ctrl",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "quoteno",
          "control_id": "txtquoteno",
          "view_name": "txtquoteno",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "quotenoml",
          "control_id": "grditemgrid",
          "view_name": "12",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "remarks",
          "control_id": "txaremarks",
          "view_name": "txaremarks",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "reqlocation",
          "control_id": "cmbreqlocation",
          "view_name": "cmbreqlocation",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "reqstatus",
          "control_id": "cmbreqstatus",
          "view_name": "cmbreqstatus",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "rfqdate",
          "control_id": "datrfqdate",
          "view_name": "datrfqdate",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "rfqno",
          "control_id": "dsprfqno",
          "view_name": "dsprfqno",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "saletype",
          "control_id": "cmbsaletype",
          "view_name": "cmbsaletype",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "stock_dispatched_date",
          "control_id": "grditemgrid",
          "view_name": "5",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "stock_received_time",
          "control_id": "grditemgrid",
          "view_name": "6",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "stock_updated_date",
          "control_id": "grditemgrid",
          "view_name": "4",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "stockstatus",
          "control_id": "grddetgrid",
          "view_name": "4",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "supportdocs",
          "control_id": "imgsupportdocs",
          "view_name": "imgsupportdocs",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "totalamount",
          "control_id": "numtotalamount",
          "view_name": "numtotalamount",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "urgent",
          "control_id": "chkurgent",
          "view_name": "chkurgent",
          "flow_direction": "0",
          "multi_instance": "no"
        },
        {
          "name": "viewgr",
          "control_id": "grddetgrid",
          "view_name": "8",
          "flow_direction": "0",
          "multi_instance": "no"
        }
      ]
    },
    "disposal": "saomainscdis",
    "posttask": {
      "saomainsccustophp": {
        "posthelp": "saomainsccustoeui"
      },
      "saomainscpriortlk": {
        "postlink": "saomainscprintstr"
      }
    }
  }
  