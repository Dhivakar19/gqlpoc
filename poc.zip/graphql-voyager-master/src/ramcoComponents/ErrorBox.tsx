import * as React from 'react';
import { Dialog } from 'primereact/dialog';
import './PrimeTable.css';

const ErrorBox = (props:any) =>{
    const [visible, setVisible] = React.useState(false);
    const {errorMsg,resetErrorDialogShow,errorFlag} = props;
    React.useEffect(()=>{
        if(errorFlag){
            setVisible(true)
        }   
    },[errorFlag]);


    const onClose =() =>{
        setVisible(false);
        resetErrorDialogShow();
    }

    return (
        <div>
            <div className="card">
            <Dialog header="Error" visible={visible} style={{ width: '50vw' }}  onHide={onClose}>
                    <p className="errorMsg" >{errorMsg}</p>
                </Dialog>

            </div>
        </div>
    )
};

export default ErrorBox;