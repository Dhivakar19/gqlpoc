import * as React from 'react';
import * as PropTypes from 'prop-types';
import { Typography, TextField, Checkbox, Dialog, DialogTitle, DialogContent, Theme } from '@material-ui/core/';
import { createStyles, withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import './PrimeTable.css'
import PrimeTable from './PrimeTable';
import SearchBar from "material-ui-search-bar";
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@material-ui/core';






let globalArgumentList = [];
let globalTempParentArgument: any;

const styles = () =>
    createStyles({
        textFieldDropDown: {
            backgroundColor: "#FFFFFF",
            width: 270,
            height: 50,
            marginLeft: 20,
        },

        mt10: {
            marginTop: 10
        },
        argumentLabel: {
            marginLeft: 20
        },
        possibleQueryLabel: {
            marginLeft: 55
        },
        controlTableLabel: {
            marginLeft: 50
        },
        containedDropDownContent: {
            marginLeft: -290,
            marginTop: 25
        },
        argumentTreeView: {
            marginTop: 15
        },
        controlDataTable: {
            marginTop: -100,
            marginLeft: 420
        },
        controlDropDown: {
            marginTop: -85,
            marginLeft: 420
        },
        saveButton: {
            marginTop: 10,
            marginLeft: 590
        },
        closeButton: {
            position: 'absolute',
            right: 8,
            top: 24 ,
           
          },
    });









const StyledTableCell = withStyles((theme: Theme) =>
    createStyles({
        head: {
            backgroundColor: theme.palette.common.black,
            color: theme.palette.common.white,
            fontSize: 17
        },
        body: {
            fontSize: 14,
        },
    }),
)(TableCell);

const StyledTableRow = withStyles((theme: Theme) =>
    createStyles({
        root: {
            '&:nth-of-type(odd)': {
                backgroundColor: theme.palette.action.hover,
            },
        },
    }),
)(TableRow);


const RamcoDialog = withStyles(styles)((props: any) => {
    const { onClose, open, rootValue, classes, taskData, queryMappingObject, controlList, updateTaskObject,
        renderErrorDialog } = props;
    const [rootQueryList, setQueryList] = React.useState<any[]>([]);
    const [modifyQueryList, setModifyQueryList] = React.useState<any[]>([]);
    const [selectedQuery, setSelectedQuery] = React.useState(rootValue.queryList[0]);
    const [rootArgumentList, setArgumentList] = React.useState<any[]>([]);
    const [mappedControlList, setMappedControlList] = React.useState<any[]>([]);
    const [selected, setSelected] = React.useState<string>('');
    const [searched, setSearched] = React.useState<string>("");
    const [filteredControlIdRows, setFilteredControlIdRows] = React.useState<any[]>();
    const [showErrorDialog, setShowErrorDialog] = React.useState(false);
    const [errorMessage, setErrorMessage] = React.useState('');

    React.useEffect(() => {
        setQueryList(rootValue.queryList);
        setModifyQueryList(rootValue.queryList)
        setArgumentList(rootValue.argumentList)
        generateArgumentControlTableValue(rootValue.argumentList);
    }, [])


    React.useEffect(() => {
        if (selected != '' && selected != undefined) {
            handleArgumentQueryFormation(selected)
        }
    }, [selected])


    React.useEffect(() => {
        frameMappedControlList(mappedControlList, controlList);
    }, [mappedControlList])


    React.useEffect(() => {
        if (selectedQuery != '' && selected != undefined) {
            generateFieldMappedTableData()
        }
    }, [selectedQuery])

    React.useEffect(() => {
        if (showErrorDialog && errorMessage != '') {
            renderErrorDialog(showErrorDialog,errorMessage);
            onClose();
        }

    }, [showErrorDialog,errorMessage])


   

  


    const frameMappedControlList = (fieldMappedControlList, controlIdList) => {
        try {
            if (controlIdList.length != 0) {
                if (fieldMappedControlList.length != 0) {
                    fieldMappedControlList.forEach((mappedControl: any) => {
                        var tempList = controlIdList.filter((control: any) => {
                            if (control.control_id == mappedControl.control_id
                                && control.view_name == mappedControl.view_name) {
                                return control;
                            }
                        })
                        tempList[0].mapped = mappedControl.mapped;
                    })
                } else {
                    controlIdList.map((control) => {
                        control.mapped = 'no';
                    })
                }
            }
            setFilteredControlIdRows([...controlIdList]);

        } catch (error) {
            setShowErrorDialog(true);
            setErrorMessage(error.message);
        }

    }




    const trackArgumentParent = (SearchingArgumentItem: any, searchingNodeId: any) => {
        try {
            if (SearchingArgumentItem && SearchingArgumentItem.data &&
                SearchingArgumentItem.data.id == searchingNodeId) {
                globalArgumentList.unshift(SearchingArgumentItem.data.id);
    
                if (SearchingArgumentItem.data.hasOwnProperty('parentId')) {
                    trackArgumentParent(globalTempParentArgument, SearchingArgumentItem.data.parentId)
                }
            }
            else {
                if (SearchingArgumentItem.hasOwnProperty('children')) {
                    var childrenArgumentList = SearchingArgumentItem.children;
                    childrenArgumentList.forEach((item: any) => {
                        trackArgumentParent(item, searchingNodeId);
                    });
                }
    
            }
        } catch (error) {
            setShowErrorDialog(true);
            setErrorMessage(error.message);
        }
      
    }


    const generateArgumentControlTableValue = (argumentList: any) => {
        try {
            if (Array.isArray(argumentList) && rootValue && rootValue.hasOwnProperty('queryList') && rootValue.queryList.length != 0) {
                var finalArgumentTable = []
                var root = rootValue.queryList[0];
                argumentList.map((arg: any) => {
                    finalArgumentTable.push(generateArgumentMappedTableValue(arg, root));
                })
                setMappedControlList([...finalArgumentTable]);
            }
        } catch (error) {
            setShowErrorDialog(true);
            setErrorMessage(error.message);
        }
      

    }

    const generateArgumentMappedTableValue = (argumnentObject: any, root: any) => {
        try {
            let filterMappedName:any;
            if (argumnentObject && argumnentObject.hasOwnProperty("data") && root != '') {
                filterMappedName = `${root}.${argumnentObject.data.name}`;
    
                var mappedList = generateArgumentMappedTableData(filterMappedName);
    
                argumnentObject.data.mappedArgumentList = mappedList;
                if (mappedList.length === 1) {
                    argumnentObject.data.view_name = mappedList[0].view_name;
                    argumnentObject.data.control_id = mappedList[0].control_id;
                    argumnentObject.data.default_value = mappedList[0].default_value;
                    argumnentObject.data.processingType = mappedList[0].processingType;
                }
                if (argumnentObject.hasOwnProperty("children")) {
                    argumnentObject.children.map((child: any) => {
                        generateArgumentMappedTableValue(child, filterMappedName);
                    })
                }
            }
    
            return argumnentObject;
            
        } catch (error) {
            setShowErrorDialog(true);
            setErrorMessage(error.message);
        }
       
    }


    const handleArgumentQueryFormation = (selectedNodeId: string) => {
        try {            
        var argQueryPathList = [];
        var selectedId = '';
        var argStringNameList = [];
        var tempList = [];
        var argumentList = [];
        selectedId = selectedNodeId;

        tempList = [...rootQueryList];
        argumentList = [...rootArgumentList];
        globalArgumentList = [];
        argumentList.map((argumentItem: any) => {
            globalTempParentArgument = argumentItem;
            trackArgumentParent(argumentItem, selectedId)
        });
        globalArgumentList.forEach((value: any) => {
            argStringNameList = value.split('::');
            argQueryPathList.push(argStringNameList[argStringNameList.length - 1])
        });
        tempList[0] = `${tempList[0]}.${argQueryPathList.join(".")}`;
        setModifyQueryList(tempList);
        return tempList[0];
            
        } catch (error) {
            setShowErrorDialog(true);
            setErrorMessage(error.message);
        }

    };


    const selectQueryValue = (event: any) => {
        var text = event.target.value ? event.target.value : '';
        setSelectedQuery(text);
    }




    const generateFieldMappedTableData = () => {
        try {
            var TableList = [];
            if (Object.keys(taskData).length != 0 &&
            Object.keys(queryMappingObject).length != 0) {
            taskData.tasks.map((task: any) => {
                if (task.name == queryMappingObject.taskName) {
                    task.queries.forEach((query: any) => {
                        query.fields.map((field: any) => {
                            if (field.name == selectedQuery && field.mapped == 'yes') {
                                TableList.push(field);
                            }
                        })
                    })
                }
            })
        }

        setMappedControlList([...TableList])
        } catch (error) {
            setShowErrorDialog(true);
            setErrorMessage(error.message);
        }
       
      

    }

    const generateArgumentMappedTableData = (selectedArgumentQuery: any) => {
        try {
            var argumentTableList = [];
            if (Object.keys(taskData).length != 0 &&
                Object.keys(queryMappingObject).length != 0) {
                taskData.tasks.map((task: any) => {
                    if (task.name == queryMappingObject.taskName) {
                        task.queries.forEach((query: any) => {
                            if (query.args.length != 0) {
                                query.args.map((arg: any) => {
                                    if (arg.name == selectedArgumentQuery) {
                                        argumentTableList.push(arg);
                                    }
                                })
                            }
                            if (query.inputFields.length != 0) {
                                query.inputFields.map((inputField: any) => {
                                    if (inputField.name == selectedArgumentQuery) {
                                        argumentTableList.push(inputField);
                                    }
                                })
                            }
    
                        })
                    }
                })
            }
    
            return argumentTableList;
            
        } catch (error) {
            setShowErrorDialog(true);
            setErrorMessage(error.message);
        }
       


    }

    const handleClose = () => {
        onClose();
    };

    const handleCheckBox = (e, row: any) => {
        try {
            var tempList = [...filteredControlIdRows];
        tempList.map((control: any) => {
            if (control.control_id == row.control_id && control.view_name == row.view_name) {
                if (e.target.checked) {
                    control.mapped = 'yes';
                } else {
                    control.mapped = 'no';
                }
                var tempObj = {
                    "usage": "value",
                    "name": rootQueryList[0],
                    "data_type": rootValue.selectedFieldType || '',
                    "control_id": control.control_id,
                    "view_name": control.view_name,
                    "mapped": control.mapped
                }

                updateTaskObject(tempObj, 'field');
            }
        })

        setFilteredControlIdRows([...tempList]);
            
        } catch (error) {
            setShowErrorDialog(true);
            setErrorMessage(error.message);
        }
        

    }


    const requestSearch = (searchedVal: string) => {
        try {
            if (Array.isArray(controlList) && controlList.length != 0) {
                const filteredRows = controlList.filter((row) => {
                    if (row.control_id && row.control_id != '' && row.control_id.toLowerCase().includes(searchedVal.toLowerCase())
                        || (row.view_name && row.view_name != '' && row.view_name.toLowerCase().includes(searchedVal.toLowerCase()))) {
                        return row;
                    }
                });
                if (filteredRows.length != 0) {
                    setFilteredControlIdRows(filteredRows);
                } else {
                    setFilteredControlIdRows([...controlList]);
                }
    
            }
        } catch (error) {
            setShowErrorDialog(true);
            setErrorMessage(error.message);
        }
      
    };

    const cancelSearch = () => {
        setSearched("");
        requestSearch(searched);
    };



    const renderSelectableControlTable = (list: any) => {
        return (
            <Paper>
                <SearchBar
                    value={searched}
                    onChange={(searchVal) => requestSearch(searchVal)}
                    onCancelSearch={() => cancelSearch()}

                />
                <TableContainer component={Paper} >
                    <Table stickyHeader aria-label="simple table">
                        <TableHead>
                            <TableRow>
                                <StyledTableCell >Select</StyledTableCell>
                                <StyledTableCell >Control-id</StyledTableCell>
                                <StyledTableCell align="right">View Name</StyledTableCell>

                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {list.map((row: any, index: any) => {
                                const isItemSelected = row.mapped == 'yes' ? true : false;
                                const labelId = `enhanced-table-checkbox-${index}`;

                                return (
                                    <StyledTableRow key={`${row.control_id}-${row.view_name}-${index}`}>
                                        <StyledTableCell padding="checkbox">
                                            <Checkbox
                                                color="primary"
                                                checked={isItemSelected}
                                                inputProps={{ 'aria-labelledby': labelId }}
                                                onChange={(e) => handleCheckBox(e, row)}
                                            />
                                        </StyledTableCell>
                                        <StyledTableCell component="th" scope="row">
                                            {row.control_id}
                                        </StyledTableCell>
                                        <StyledTableCell align="right">{row.view_name}</StyledTableCell>
                                    </StyledTableRow>)

                            })}
                        </TableBody>
                    </Table>
                </TableContainer>
            </Paper>
        )
    }



    return (
<div>
        <Dialog onClose={handleClose} aria-labelledby="simple-dialog-title" open={open}
            fullWidth={true}
            maxWidth="lg">
            <DialogTitle id="simple-dialog-title">
                {
                    <><Typography variant="h4"> Query Builder</Typography>
                    <IconButton aria-label="close" className={classes.closeButton}  onClick={handleClose}>
                    <CloseIcon />
                  </IconButton>
                  </>
                }
            </DialogTitle>
            <DialogContent dividers>
                {
                    <div>
                        <Grid container >
                            <Grid container item xs={12}>
                                {modifyQueryList.length != 0 && <Grid container direction="column" item xs={6}>
                                    <Grid item className={classes.possibleQueryLabel} xs={6}>
                                        <Typography variant="h6"> Query Path </Typography>
                                    </Grid>
                                    <Grid item xs={6} className={classes.containedDropDownContent}>
                                        <TextField
                                            select
                                            value={selectedQuery}
                                            margin='dense'
                                            onChange={selectQueryValue}
                                            InputProps={{ className: classes.textFieldDropDown }}
                                            SelectProps={{
                                                native: true,
                                            }}
                                            variant="outlined"
                                        >
                                            {modifyQueryList.map((item: any, index: any) => (
                                                <option key={index} value={item}>
                                                    {item}
                                                </option>
                                            ))}
                                        </TextField>
                                    </Grid>

                                </Grid>}


                            </Grid>
                            {(rootArgumentList.length == 0 && Object.keys(queryMappingObject).length != 0
                                && queryMappingObject.queryName != '' && Array.isArray(filteredControlIdRows) && filteredControlIdRows.length != 0)
                                && <Grid container direction="row" item xs={12} >
                                    <Grid item xs={12} className={classes.controlDropDown}>
                                        {
                                            renderSelectableControlTable(filteredControlIdRows)
                                        }
                                    </Grid>
                                    {/* <Grid item className={classes.saveButton} xs={6}>
                                        {
                                            <div>
                                                <Button variant="contained" color="primary" onClick={handleClose}>
                                                    Close
                                                </Button>
                                            </div>
                                        }
                                    </Grid> */}

                                </Grid>}
                            {rootArgumentList.length != 0 && <Grid container direction="column" item xs={12}>
                                <Grid item xs={12} className={classes.argumentTreeView}>
                                    {rootArgumentList.length != 0 &&
                                        <PrimeTable rootArgumentList={rootArgumentList} handleArgumentQueryFormation={handleArgumentQueryFormation} controlList={filteredControlIdRows}
                                            updateTaskObject={updateTaskObject} setSelected={setSelected}
                                            renderErrorDialog={renderErrorDialog} onClose={onClose}/>
                                    }
                                </Grid>

                            </Grid>}
                        </Grid>
                    </div>

                }
            </DialogContent>

           
        </Dialog >
</div>

    );
})


RamcoDialog.propTypes = {
    onClose: PropTypes.func.isRequired,
    open: PropTypes.bool.isRequired,
    rootValue: PropTypes.object.isRequired,
    queryMappingObject: PropTypes.object.isRequired,
    taskData: PropTypes.object.isRequired,
    controlList: PropTypes.array.isRequired,
    updateTaskObject: PropTypes.func.isRequired,
    renderErrorDialog:PropTypes.func.isRequired
};

export default RamcoDialog;




