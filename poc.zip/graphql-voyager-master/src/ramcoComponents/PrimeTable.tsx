import * as React from 'react';
import { Column } from 'primereact/column';
import { TreeTable } from 'primereact/treetable';
import { InputText } from 'primereact/inputtext';
import { Dropdown } from 'primereact/dropdown';
import './PrimeTable.css';




const PrimeTable = (props: any) => {
    const { rootArgumentList, controlList,updateTaskObject,handleArgumentQueryFormation,renderErrorDialog,
        onClose} = props
    // const [selectedNodes, setSelectedNodes] = React.useState([]);
    const [treeData, setTreeData] = React.useState([]);
    const [controlOptions, setControlOptions] = React.useState([]);
    const [showErrorDialog, setShowErrorDialog] = React.useState(false);
    const [errorMessage, setErrorMessage] = React.useState('');
    const processingOptions = [
        {name:"PSR",value:"PSR"},
        {name:"PMR",value:"PMR"},
        {name:"PSMR",value:"PSMR"}
    ]
   


   
    React.useEffect(() => {
        setTreeData([...rootArgumentList]);
        frameControlList(controlList)
    }, []);


    React.useEffect(() => {
        if (showErrorDialog && errorMessage != '') {
            renderErrorDialog(showErrorDialog,errorMessage);
            onClose();
        }

    }, [showErrorDialog,errorMessage])



    const frameControlList = (controlIdList: any) => {
        try {
            if (controlIdList.length != 0) {
                controlIdList.map((control: any) => {
                    control.uniqueKey = `${control.control_id}::${control.view_name}`
                })
                setControlOptions([...controlIdList]);
            }
        } catch (error) {
            setShowErrorDialog(true);
            setErrorMessage(error.message);
        }
       
    }






    const onControlValueChange = (value, row) => {
        try {
            var controlSplitList;
            if (value != '' && Object.keys(row).length != 0) {
                controlSplitList = value.split('::');
                if (controlSplitList.length == 2) {
                    row.control_id = controlSplitList[0];
                    row.view_name = controlSplitList[1];
                    if (row.mappedArgumentList.length != 0) {
                        row.mappedArgumentList[0].control_id = controlSplitList[0];
                        row.mappedArgumentList[0].view_name = controlSplitList[1];
                    }
    
                };
                
                    updateTreeData(row);
                
               
            }
            
        } catch (error) {
            setShowErrorDialog(true);
            setErrorMessage(error.message);
        }
       
    }

    const onTextValueChange = (value, row) => {
        try {
            row.default_value = value ;
        if (row.mappedArgumentList.length != 0) {
            row.mappedArgumentList[0].default_value = value ;
        }
      
        updateTreeData(row);
        } catch (error) {
            setShowErrorDialog(true);
            setErrorMessage(error.message);
        }
        
    }

    const onProcessingTypeChange = (value, row) => {
        row.processingType= value;
        updateTreeData(row);
    }

    const updateTreeData = (row:any) =>{
        try {
            var tempList = treeData;
            var tempObj:any={};
            var framedQueryName = ''
                tempList.map((treeItem:any)=>{
                    if(row.hasOwnProperty('parentId')){
                          if(treeItem.key  == row.parentId){
                                treeItem.children.map((child:any)=>{
                                    if(child.key == row.id ){
                                        child = row;
                                    }
                                })
                          }
                    }
                    else {
                       if (treeItem.key == row.id){
                        treeItem = row;
                       }     
                    }
                });
                if((row.control_id == '' && row.default_value!='') || 
                (row.control_id == '' && row.default_value =='') ||
                ((row.control_id != '' && row.default_value ==''))){
                    setTreeData([...tempList]);
                    framedQueryName = handleArgumentQueryFormation(row.id);
                    tempObj = {
                        "default_value": row.default_value ,
                        "required": "no",
                        "name": framedQueryName,
                        "data_type": row.dataType,
                        "control_id": row.control_id,
                        "view_name": row.view_name,
                        "source":row.source || '',
                        "mapped": 'yes',
                        "processingType":row.processingType
                    }
                   
                    updateTaskObject(tempObj,'argument');
                } 
                else{
                    alert("Either choose Control-id or Default- value");
                }
            
        } catch (error) {
            setShowErrorDialog(true);
            setErrorMessage(error.message);
            
        }
     
                                
            
          
    }


  

    const fieldEditor = (options) => {
        let node = options?.node;
        let temp = {}
        temp = template(options.props.field,node);
        return temp;

    }

    const template = (type,node) => {
        let temp;
        switch (type) {
            case 'control_id':
                temp = controlDropDownTemplate(node);
                break;
            case 'processingType':
                    temp =processingDropDownTemplate(node);
                    break;
            case 'default_value':
                temp = textTemplate(node);
                break;
            default:
                temp = <></>
                break;
        }

        return temp;
    }

   
    const controlDropDownTemplate = (node) => {
        let temp = <></>;
        if ( !node.hasOwnProperty('children')) {
            temp = <Dropdown id={`${node.key}`} style={{width: 200}} value={`${node.data.control_id}::${node.data.view_name}`} options={controlOptions} optionLabel="uniqueKey" optionValue="uniqueKey"
                onChange={(e) => onControlValueChange(e.value, node.data)} placeholder="Select Control-ID" />
        } 
        return temp;
    }

    const processingDropDownTemplate = (node) => {
        let temp = <></>;
        if (node.hasOwnProperty('children') && node.data.processingFlag) {
            temp = <Dropdown id={`${node.key}`} style={{width: 200}} value={node.data.processingType} options={processingOptions} optionLabel="name" optionValue="value"
                onChange={(e) => onProcessingTypeChange(e.value, node.data)} placeholder="Select Processing-Type" />
        } 
        return temp;
    }

    const textTemplate = (node) => {
        let temp = <></>;
        if ( !node.hasOwnProperty('children')) {
            temp = <InputText type="text" key={node.key}  value={node.data.default_value} onChange={(e) => onTextValueChange(e.target.value, node.data)}  />
        }
        return temp;
    }

    return (

        <TreeTable value={treeData} resizableColumns scrollable  columnResizeMode="expand" scrollHeight="200px" showGridlines 
       >
            <Column expander field='name' header="Name">
            </Column>
            <Column field='control_id' header="Control-id" editor={fieldEditor} body={controlDropDownTemplate}>
            </Column>
            <Column field='view_name' header="View Name" align='right'></Column>
            <Column field='processingType' header="Processing Type" editor={fieldEditor} body={processingDropDownTemplate}>
            </Column>
            <Column field='default_value' header="Default Value" editor={fieldEditor} body={textTemplate}
         >
            </Column>
        </TreeTable>
     
    )

}
export default PrimeTable;