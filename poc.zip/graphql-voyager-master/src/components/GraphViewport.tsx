import * as React from 'react';
import LoadingAnimation from './utils/LoadingAnimation';

import { Viewport } from './../graph/';
import TaskBuilder from '../../schemavisualizer/taskBuilder';
import ErrorBox from '../ramcoComponents/ErrorBox';




interface GraphViewportProps {
  svgRenderer: any;
  typeGraph: any;
  displayOptions: any;
  selectedTypeID: string;
  selectedEdgeID: string;
  fieldHighLightHandler: () => void;
  updateTaskObject: (checkedField: any, type: any) => void;
  setQueryMappingObject: (mappingQuery: any) => void;
  queryMappingObject: any;
  onSelectNode: (id: string, child?: Element, childType?: string, nodeList?: any) => void;
  onSelectEdge: (id: string) => void;
  taskData: any;
  errorFlag:any;
  errorMsg:any
  resetErrorDialogShow : () => void;
  renderErrorDialog: (errorShow:boolean,msg:string) => void;

}

export default class GraphViewport extends React.Component<GraphViewportProps> {
  state = { typeGraph: null, displayOptions: null, svgViewport: null };


  // Handle async graph rendering based on this example
  // https://gist.github.com/bvaughn/982ab689a41097237f6e9860db7ca8d6
  _currentTypeGraph = null;
  _currentDisplayOptions = null;

  static getDerivedStateFromProps(props, state) {
    const { typeGraph, displayOptions } = props;

    if (
      typeGraph !== state.typeGraph ||
      displayOptions !== state.displayOptions
    ) {
      return { typeGraph, displayOptions, svgViewport: null };
    }

    return null;
  }

  componentDidMount() {
    const { typeGraph, displayOptions } = this.props;
    this._renderSvgAsync(typeGraph, displayOptions);
  }

  componentDidUpdate(prevProps, prevState) {
    const { svgViewport } = this.state;

    if (svgViewport == null) {
      const { typeGraph, displayOptions } = this.props;
      this._renderSvgAsync(typeGraph, displayOptions);
      return;
    }

    const isJustRendered = prevState.svgViewport == null;
    const { selectedTypeID, selectedEdgeID, fieldHighLightHandler } = this.props;

    if (prevProps.selectedTypeID !== selectedTypeID || isJustRendered) {
      svgViewport.selectNodeById(selectedTypeID);
    }

    if (prevProps.selectedEdgeID !== selectedEdgeID || isJustRendered) {
      svgViewport.selectEdgeById(selectedEdgeID);
    }
    
    fieldHighLightHandler();
  }

  componentWillUnmount() {
    this._currentTypeGraph = null;
    this._currentDisplayOptions = null;
    this._cleanupSvgViewport();
  }



  _renderSvgAsync(typeGraph, displayOptions) {
    if (typeGraph == null || displayOptions == null) {
      return; // Nothing to render
    }

    if (
      typeGraph === this._currentTypeGraph &&
      displayOptions === this._currentDisplayOptions
    ) {
      return; // Already rendering in background
    }

    this._currentTypeGraph = typeGraph;
    this._currentDisplayOptions = displayOptions;

    const { svgRenderer, onSelectNode, onSelectEdge, updateTaskObject,renderErrorDialog } = this.props;
    svgRenderer
      .renderSvg(typeGraph, displayOptions)
      .then((svg) => {
        if (
          typeGraph !== this._currentTypeGraph ||
          displayOptions !== this._currentDisplayOptions
        ) {
          return; // One of the past rendering jobs finished
        }

        this._cleanupSvgViewport();
        const containerRef = this.refs['viewport'] as HTMLElement;
        const svgViewport = new Viewport(
          svg,
          containerRef,
          onSelectNode,
          onSelectEdge,
          updateTaskObject,
          renderErrorDialog
        );
        this.setState({ svgViewport });
      })
      .catch((error) => {
        this._currentTypeGraph = null;
        this._currentDisplayOptions = null;

        error.message = error.message || 'Unknown error';
        this.setState(() => {
          throw error;
        });
      });
  }

  render() {
    const isLoading = this.state.svgViewport == null;
    const { taskData, setQueryMappingObject,errorFlag,errorMsg,resetErrorDialogShow,renderErrorDialog } = this.props
    console.log("taskData", taskData);
    return (
      <>
        {taskData && taskData.tasks && taskData.tasks.length != 0 &&

          <TaskBuilder taskData={taskData} setQueryMappingObject={setQueryMappingObject} renderErrorDialog={renderErrorDialog} />

        }

        <div ref="viewport" className="viewport" />
        <ErrorBox errorMsg={errorMsg} errorFlag={errorFlag} resetErrorDialogShow={resetErrorDialogShow}  />

        <LoadingAnimation loading={isLoading} />
      </>
    );
  }

  resize() {
    const { svgViewport } = this.state;
    if (svgViewport) {
      svgViewport.resize();
    }
  }

  focusNode(id) {
    const { svgViewport } = this.state;
    if (svgViewport) {
      svgViewport.focusElement(id);
    }
  }

  _cleanupSvgViewport() {
    const { svgViewport } = this.state;
    if (svgViewport) {
      svgViewport.destroy();
    }
  }
}
