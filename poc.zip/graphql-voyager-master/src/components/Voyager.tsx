import { getIntrospectionQuery } from 'graphql/utilities';
import { getSchema, extractTypeId } from '../introspection';
import { SVGRender, getTypeGraph } from '../graph/';
import { WorkerCallback } from '../utils/types';

import * as React from 'react';
import * as PropTypes from 'prop-types';
import { theme } from './MUITheme';
import { MuiThemeProvider } from '@material-ui/core/styles';


import GraphViewport from './GraphViewport';
import DocExplorer from './doc-explorer/DocExplorer';
import Settings from './settings/Settings';

import './Voyager.css';
import './viewport.css';

import RamcoDialog from '../ramcoComponents/RamcoDialog';


let highLightFieldIdList = [];
let globalTypeIdList = [];



type IntrospectionProvider = (query: string) => Promise<any>;


// {change in the file in state added two property openDialog,rootValue  }

export interface VoyagerDisplayOptions {
  rootType?: string;
  skipRelay?: boolean;
  skipDeprecated?: boolean;
  showLeafFields?: boolean;
  sortByAlphabet?: boolean;
  hideRoot?: boolean;
}

export interface RenderArgTree {
  id: string;
  name: string;
  children?: RenderArgTree[];
}

const defaultDisplayOptions = {
  rootType: undefined,
  skipRelay: true,
  skipDeprecated: true,
  sortByAlphabet: false,
  showLeafFields: true,
  hideRoot: false,
};

const rootOptions = {
  queryList: []
}

function normalizeDisplayOptions(options) {
  return options != null
    ? { ...defaultDisplayOptions, ...options }
    : defaultDisplayOptions;
}

export interface VoyagerProps {
  introspection: IntrospectionProvider | Object;
  taskObject: Object;
  queryMappingObject: Object
  displayOptions?: VoyagerDisplayOptions;
  hideDocs?: boolean;
  hideSettings?: boolean;
  workerURI?: string;
  loadWorker?: WorkerCallback;
  setTaskObject: any;
  setQueryMappingObject:any;
  controlIdList: any;
  children?: React.ReactNode;
  sequenceErrorMsg:string;
}

export interface RootProps {
  queryList: any[],
  argumentList: any[],
  selectedFieldType: string
}




export default class Voyager extends React.Component<VoyagerProps> {
  static propTypes = {
    introspection: PropTypes.oneOfType([
      PropTypes.func.isRequired,
      PropTypes.object.isRequired,
    ]).isRequired,
    displayOptions: PropTypes.shape({
      rootType: PropTypes.string,
      skipRelay: PropTypes.bool,
      skipDeprecated: PropTypes.bool,
      sortByAlphabet: PropTypes.bool,
      hideRoot: PropTypes.bool,
      showLeafFields: PropTypes.bool,
    }),
    hideDocs: PropTypes.bool,
    hideSettings: PropTypes.bool,
    workerURI: PropTypes.string,
    loadWorker: PropTypes.func,
    taskObject: PropTypes.object.isRequired,
    setTaskObject: PropTypes.func,
    setQueryMappingObject:PropTypes.func,
    queryMappingObject: PropTypes.object.isRequired,
    controlIdList: PropTypes.array.isRequired,
    sequenceErrorMsg:PropTypes.string,
  };

  state = {
    introspectionData: null,
    schema: null,
    typeGraph: null,
    displayOptions: defaultDisplayOptions,
    selectedTypeID: null,
    selectedEdgeID: null,
    openDialog: false,
    rootValue: rootOptions,
    taskData: null,
    queryMappingObject: null,
    controlList: [],
    typeIdList: [],
    errorDialogShow:false,
    errorMsg:''

  };

  svgRenderer: SVGRender;
  viewportRef = React.createRef<GraphViewport>();
  instospectionPromise = null;


  constructor(props) {
    super(props);
    this.svgRenderer = new SVGRender(
      this.props.workerURI,
      this.props.loadWorker,
    );
  }

  componentDidMount() {
    this.fetchIntrospection();
  }





  fetchIntrospection() {
    const displayOptions = normalizeDisplayOptions(this.props.displayOptions);

    if (typeof this.props.introspection !== 'function') {
      this.updateIntrospection(this.props.introspection, displayOptions, this.props.taskObject, this.props.queryMappingObject
        , this.props.controlIdList);
      return;
    }

    let promise = this.props.introspection(getIntrospectionQuery());

    if (!isPromise(promise)) {
      throw new Error(
        'SchemaProvider did not return a Promise for introspection.',
      );
    }

    this.setState({
      introspectionData: null,
      schema: null,
      typeGraph: null,
      displayOptions: null,
      selectedTypeID: null,
      selectedEdgeID: null,
      openDialog: false,
      rootValue: {},
      taskData: null,
      controlList: [],
      typeIdList: [],
      queryMappingObject: null,
      errorDialogShow:false,
      errorMsg:''
    });

    this.instospectionPromise = promise;
    promise.then((introspectionData) => {
      if (promise === this.instospectionPromise) {
        this.instospectionPromise = null;
        this.updateIntrospection(introspectionData, displayOptions, this.state.taskData,
          this.state.queryMappingObject, this.state.controlList);
      }
    });
  };

  trackTypeId(rootObject) {
    rootObject.map(() => {

    })
  }


  generateQueryNameTypeIdList(graphObj: any, queryNameList) {
    try {
      var nodeObj = graphObj.nodes
      globalTypeIdList.push(graphObj.rootId);
      for (let index = 0; index < queryNameList.length; index++) {
        var fieldName = queryNameList[index];
        for (const key in nodeObj) {
          var fieldObj = nodeObj[key].fields;
          for (const fieldKey in fieldObj) {
            if (fieldKey == fieldName) {
              // if (fieldObj[fieldKey].type.kind == 'OBJECT') {
                globalTypeIdList.push(fieldObj[fieldKey].type.id)
              // }
            }
          }
  
        }
  
      }
    } catch (error) {
      this.renderErrorDialog(true,error.message);
    }
   

    console.log("nodeObj", nodeObj);

  }

  trackAllRelatedTypeIdList(typeId: any, nodeObj: any) {
    try {
      for (const key in nodeObj) {
        if (typeId == key) {
          var fieldObj = nodeObj[key].fields;
          for (const fieldKey in fieldObj) {
            if (fieldObj[fieldKey].type.kind == 'OBJECT') {
              globalTypeIdList.push(fieldObj[fieldKey].type.id);
              this.trackAllRelatedTypeIdList(fieldObj[fieldKey].type.id, nodeObj);
            }
          }
        }
      }
    } catch (error) {
      this.renderErrorDialog(true,error.message);
    }
    
  }


  removeUnmappedField(typeId: any, nodeObj: any, fieldName: any) {
    try {
      for (const key in nodeObj) {
        if (typeId == key) {
          var fieldObj = nodeObj[key].fields;
          if (fieldObj.hasOwnProperty(fieldName)) {
            for (const fieldKey in fieldObj) {
              if (fieldKey !== fieldName) {
                delete fieldObj[fieldKey];
              }
            }
          }
  
        }
      }
  
      return nodeObj;
      
    } catch (error) {
      this.renderErrorDialog(true,error.message);
    }
   
  }

  updateIntrospection(introspectionData, displayOptions, taskObject: any, queryMappingObject: any, controlList: any) {
    const schema = getSchema(
      introspectionData,
      displayOptions.sortByAlphabet,
      displayOptions.skipRelay,
      displayOptions.skipDeprecated,
    );
    let typeGraph = getTypeGraph(
      schema,
      displayOptions.rootType,
      displayOptions.hideRoot,
    );

    console.log("schema", schema);
    console.log("typeGraph", typeGraph);

    var nodeObj = typeGraph.nodes;
    var errorMsg = '';
    var errorFlag = false;
    try {
      if ( Object.keys(queryMappingObject).length != 0 && queryMappingObject.queryName != '') {
        var queryNameList = queryMappingObject.queryName.split('.');
        this.generateQueryNameTypeIdList(typeGraph, queryNameList);
        nodeObj = this.removeUnmappedField(globalTypeIdList[globalTypeIdList.length - 2], nodeObj, queryNameList[queryNameList.length - 1])
        this.trackAllRelatedTypeIdList(globalTypeIdList[globalTypeIdList.length - 1], nodeObj)
        if (globalTypeIdList.length != 0) {
          globalTypeIdList = globalTypeIdList.filter((c, index) => {
            return globalTypeIdList.indexOf(c) === index;
          });
          for (const key in nodeObj) {
            if (!globalTypeIdList.includes(key)) {
              delete nodeObj[key];
            }
          }
          typeGraph.nodes = nodeObj;
        }
      }
    } catch (error) {
      this.renderErrorDialog(true,error.message);
    }
   



    this.setState({
      introspectionData,
      schema,
      typeGraph,
      displayOptions,
      selectedTypeID: null,
      selectedEdgeID: null,
      rootValue: {},
      openDialog: false,
      taskData: taskObject,
      queryMappingObject: queryMappingObject,
      controlList: controlList,
      typeIdList: globalTypeIdList,
      errorDialogShow:errorFlag,
      errorMsg:errorMsg
    });
    globalTypeIdList = [];
  }

  componentDidUpdate(prevProps: VoyagerProps) {
    if (this.props.introspection !== prevProps.introspection) {
      this.fetchIntrospection();
    } else if (this.props.displayOptions !== prevProps.displayOptions
      || this.props.taskObject !== prevProps.taskObject
      || this.props.queryMappingObject !== prevProps.queryMappingObject) {
      this.updateIntrospection(
        this.state.introspectionData,
        normalizeDisplayOptions(this.props.displayOptions),
        this.props.taskObject ,
        this.props.queryMappingObject,
        this.state.controlList
      );
    }

    if (this.props.hideDocs !== prevProps.hideDocs) {
      this.viewportRef.current.resize();
    }
    if(this.props.sequenceErrorMsg !== ''){
        this.renderErrorDialog(true,this.props.sequenceErrorMsg);
    }
  }

  handleCloseDialog = () => {
    this.setState({ openDialog: false, rootValue: {} });
  }

  render() {
    const { hideDocs = false, hideSettings = false } = this.props;

    return (
      <MuiThemeProvider theme={theme}>
        <div className="graphql-voyager">
          {!hideDocs && this.renderPanel()}
          {!hideSettings && this.renderSettings()}
          {this.renderGraphViewport()}
          {this.renderQueryBuilderDialog() && <RamcoDialog open={this.state.openDialog} onClose={this.handleCloseDialog} rootValue={this.state.rootValue}
            taskData={this.state.taskData} queryMappingObject={this.state.queryMappingObject} controlList={this.state.controlList}
            updateTaskObject={this.updateTaskObject} renderErrorDialog={this.renderErrorDialog} 
             />}
        </div>
      </MuiThemeProvider>
    );
  }

  renderQueryBuilderDialog() {

    if (Object.keys(this.state.rootValue).length != 0 && this.state.rootValue.queryList.length != 0
      && Object.keys(this.state.queryMappingObject).length != 0 && Object.keys(this.state.taskData).length != 0
      && this.state.controlList.length != 0) {
      return true;
    }
    return false;
  }

  resetErrorDialogShow = ()=>{
    console.log("errorDialogShow");
   this.setState({errorMsg:'', errorDialogShow:false})
  }

  renderErrorDialog = (errorShow,msg) => {
    this.setState({errorMsg:msg,errorDialogShow:errorShow});
  }

  renderPanel() {
    const children = React.Children.toArray(this.props.children);
    const panelHeader = children.find(
      (child: React.ReactElement<any>) => child.type === Voyager.PanelHeader,
    );

    const { typeGraph, selectedTypeID, selectedEdgeID } = this.state;
    const onFocusNode = (id) => this.viewportRef.current.focusNode(id);

    return (
      <div className="doc-panel">
        <div className="contents">
          {panelHeader}
          <DocExplorer
            typeGraph={typeGraph}
            selectedTypeID={selectedTypeID}
            selectedEdgeID={selectedEdgeID}
            onFocusNode={onFocusNode}
            onSelectNode={this.handleSelectNode}
            onSelectEdge={this.handleSelectEdge}
          />
        </div>
      </div>
    );
  }

  renderSettings() {
    const { schema, displayOptions } = this.state;

    if (schema == null) return null;

    return (
      <Settings
        schema={schema}
        options={displayOptions}
        onChange={this.handleDisplayOptionsChange}
        typeDropDownList={this.state.typeIdList}
      />
    );
  }

  renderGraphViewport() {
    const {
      displayOptions,
      typeGraph,
      selectedTypeID,
      selectedEdgeID,
      queryMappingObject
    } = this.state;

    return (
      <GraphViewport
        svgRenderer={this.svgRenderer}
        typeGraph={typeGraph}
        displayOptions={displayOptions}
        selectedTypeID={selectedTypeID}
        selectedEdgeID={selectedEdgeID}
        onSelectNode={this.handleSelectNodeEx}
        onSelectEdge={this.handleSelectEdge}
        ref={this.viewportRef}
        queryMappingObject={queryMappingObject}
        setQueryMappingObject={this.props.setQueryMappingObject}
        taskData = {this.state.taskData}
        fieldHighLightHandler={this.fieldHighLightHandler}
        updateTaskObject={this.updateTaskObject}
        errorFlag = {this.state.errorDialogShow}
        errorMsg = {this.state.errorMsg}
        renderErrorDialog={this.renderErrorDialog}
        resetErrorDialogShow = {this.resetErrorDialogShow}
      />
    );
  }

  handleDisplayOptionsChange = (delta) => {
    console.log("delta", delta);
    globalTypeIdList = this.state.typeIdList;
    const displayOptions = { ...this.state.displayOptions, ...delta };
    this.updateIntrospection(this.state.introspectionData, displayOptions, this.state.taskData, this.state.queryMappingObject, this.state.controlList);
  };

  handleSelectNode = (selectedTypeID) => {
    if (selectedTypeID !== this.state.selectedTypeID) {
      this.setState({ selectedTypeID, selectedEdgeID: null });
    }
  };

  updateTaskObject = (updatedField: any, type: any) => {
    try {
      var insertField = true;
      var { taskData, queryMappingObject } = this.state;
      if (Object.keys(taskData).length != 0 && taskData.tasks && taskData.tasks.length != 0 &&
        Object.keys(updatedField).length != 0) {
        taskData.tasks.map((task: any) => {
          if (task.name == queryMappingObject.taskName) {
            task.queries.map((query: any) => {
              if (query.queryName == queryMappingObject.queryName && query.sequence == queryMappingObject.sequence
              ) {
                if (type == 'field') {
                  if (query.fields.length != 0) {
                    for (var i = 0; i < query.fields.length; i++) {
                      if (query.fields[i].name == updatedField.name
                        && query.fields[i].control_id == updatedField.control_id
                        && query.fields[i].view_name == updatedField.view_name) {
                        query.fields[i].mapped = updatedField.mapped
                        insertField = false;
                        break;
                      }
                    }
                  }
                  if (insertField) {
                    query.fields.push(updatedField);
                  }
                }
                if (type == 'argument') {
                  if (updatedField.source == 'args') {
                    if (query.args.length != 0) {
                      for (var i = 0; i < query.args.length; i++) {
                        if (query.args[i].name == updatedField.name) {
                          query.args[i].control_id = updatedField.control_id;
                          query.args[i].view_name = updatedField.view_name;
                          query.args[i].default_value = updatedField.default_value;
                          query.args[i].processingType = updatedField.processingType;
                          query.args[i].mapped = 'yes'
                          insertField = false;
                          break;
                        }
                      }
                    }
                    if (insertField) {
                      delete updatedField.source
                      query.args.push(updatedField);
                    }
                  }
                  if (updatedField.source == 'inputFields') {
                    if (query.inputFields.length != 0) {
                      for (var i = 0; i < query.inputFields.length; i++) {
                        if (query.inputFields[i].name == updatedField.name) {
                          query.inputFields[i].control_id = updatedField.control_id;
                          query.inputFields[i].view_name = updatedField.view_name;
                          query.inputFields[i].default_value = updatedField.default_value;
                          query.inputFields[i].processingType = updatedField.processingType;
                          query.inputFields[i].mapped = 'yes'
                          insertField = false;
                          break;
                        }
                      }
                    }
                    if (insertField) {
                      delete updatedField.source;
                      query.inputFields.push(updatedField);
                    }
  
                  }
  
  
                }
  
  
              }
            })
          }
        });
  
        console.log("updatedTask", taskData);
        this.props.setTaskObject(taskData);
  
      }
      
    } catch (error) {
      this.renderErrorDialog(true,error.message);
    }
  
  };


  generateArgTreeViewObj = (argumentObj: any) => {
    try {
      let treeViewObj: any
      let argumentInput: any;
      for (const argumentKey in argumentObj) {
        if (argumentObj.type != undefined) {
          argumentInput = argumentObj
        }
        else {
          argumentInput = argumentObj[argumentKey]
        }
        treeViewObj = {
          key: argumentInput.id,
          data: {
            id: argumentInput.id,
            name: argumentInput.name,
            dataType: argumentInput.type.name,
            mappedArgumentList: [],
            view_name: '',
            control_id: '',
            source: 'args',
            default_value: '',
            processingFlag: argumentInput.typeWrappers.includes("LIST"),
            processingType: ''
  
          }
        }
        if (argumentInput.type.kind == "INPUT_OBJECT") {
          let inputFields = argumentInput.type.inputFields;
          Object.keys(inputFields).forEach((key) => {
            let objchild = this.generateArgTreeViewObj(inputFields[key]);
            objchild.data.parentId = argumentInput.id;
            objchild.data.source = 'inputFields';
            if (treeViewObj["children"] != undefined && treeViewObj["children"].length != 0) {
              treeViewObj["children"].push(objchild);
            } else {
              treeViewObj["children"] = [];
              treeViewObj["children"].push(objchild)
            }
          });
        }
  
      }
      return treeViewObj;
    } catch (error) {
      this.renderErrorDialog(true,error.message);
    }
   
  }

  highlighterFieldListGenerator = (fieldList: any, rootNodeFields: any) => {
    try {
      if (rootNodeFields && fieldList.length != 0) {
        fieldList.map((field: any) => {
          if (field.name != '') {
            var tempFieldList = field.name.split('.');
            tempFieldList.forEach((fieldName: any) => {
              if (rootNodeFields.hasOwnProperty(fieldName)) {
                var fieldObject = rootNodeFields[fieldName];
                if (fieldObject.type.kind == "OBJECT") {
                  var filterList = tempFieldList.filter((value: any) => { return value != fieldName })
                  var tempList = [{
                    name: filterList.toString().replace(/,/g, '.')
                  }]
                  this.highlighterFieldListGenerator(tempList, fieldObject.type.fields)
                }
                else {
                  highLightFieldIdList.push(fieldObject.id)
                }
              }
  
            });
          }
        })
      }
    } catch (error) {
      this.renderErrorDialog(true,error.message);
    }
    
  }


  fieldHighLightHandler = () => {
    try {
      var typeGraphObj = this.state.typeGraph;
      var taskDataObject = this.state.taskData;
      var taskMappingObject = this.state.queryMappingObject
      if (typeGraphObj && typeGraphObj.nodes && taskDataObject && taskDataObject.tasks &&
        taskMappingObject && taskMappingObject.taskName) {
        var rootNode = typeGraphObj.nodes[typeGraphObj.rootId];
        var rootFields = rootNode.fields;
        taskDataObject.tasks.map((task: any) => {
          if (task.name == taskMappingObject.taskName) {
            task.queries.forEach((query: any) => {
              this.highlighterFieldListGenerator(query.fields, rootFields)
            })
          }
        })
      }
      var tempList = highLightFieldIdList;
      if (tempList && tempList.length != 0) {
        highLightFieldIdList = tempList.filter((id, index) => {
          return tempList.indexOf(id) === index;
        });
        this.highlightTheMappedField()
      }
      
    } catch (error) {
      this.renderErrorDialog(true,error.message);
    }
  
  }

  highlightTheMappedField = () => {
    try {
      if (highLightFieldIdList && highLightFieldIdList.length != 0) {
        highLightFieldIdList.forEach((id: any) => {
          var element = document.getElementById(id);
          if (element) {
            element.classList.add('field-mapped');
          }
        })
      }
    } catch (error) {
      this.renderErrorDialog(true,error.message);
    }
  
  }





  handleSelectNodeEx = (selectedParentID, SelectedChild: Element, childType: string, nodeList: any) => {
    try {
      if (SelectedChild &&  SelectedChild.classList.contains('field-name')) {
        var parentStringList = selectedParentID.split('::');
        var parentName = parentStringList[parentStringList.length - 1]
        var typeGraphObj = this.state.typeGraph;
        var argumentList = [];
        var queryList = [];
        var insertQuery = false;
  
        if (typeGraphObj && typeGraphObj.nodes && selectedParentID != '') {
          for (const key in typeGraphObj.nodes) {
            if (typeGraphObj.nodes[key].name == parentName) {
              var fieldObj = typeGraphObj.nodes[key].fields
              for (const fieldKey in fieldObj) {
                var fieldArgs = fieldObj[fieldKey].args
                var fieldName = fieldObj[fieldKey].name;
                if (fieldName == SelectedChild.innerHTML) {
                  if (Object.keys(fieldArgs).length != 0 && fieldObj[fieldKey].typeWrappers.length == 0) {
                    Object.keys(fieldArgs).forEach((key) => {
                      let argTreeViewObj = this.generateArgTreeViewObj(fieldArgs[key]);
                      argumentList.push(argTreeViewObj);
                    });
                    insertQuery = true;
                  }
                  if (Object.keys(fieldArgs).length == 0 && fieldObj[fieldKey].typeWrappers.length == 0
                    && fieldObj[fieldKey].type.kind == "SCALAR") {
                    insertQuery = true;
                  }
                }
              }
            }
          }
        }
  
        if (insertQuery) {
          queryList = nodeList.map((item: any) => {
            if (item !== undefined) {
              var tempString = item.replace(/,/g, '.');
              return item = `${tempString}.${SelectedChild.innerHTML}`
            }
          })
          queryList = queryList.filter((values) => {
            return values != undefined
          })
        };
        var rootValue: RootProps = {
          queryList: queryList,
          argumentList: argumentList,
          selectedFieldType: childType
        }
        this.setState({
          openDialog: true,
          rootValue: rootValue
        });
      }
      this.handleSelectNode(selectedParentID);
      
    } catch (error) {
      this.renderErrorDialog(true,error.message);
    }
    
  };

  handleSelectEdge = (selectedEdgeID) => {
    if (selectedEdgeID === this.state.selectedEdgeID) {
      // deselect if click again
      this.setState({ selectedEdgeID: null });
    } else {
      const selectedTypeID = extractTypeId(selectedEdgeID);
      this.setState({ selectedTypeID, selectedEdgeID });
    }
  };

  static PanelHeader = (props) => {
    return props.children || null;
  };
}

// Duck-type promise detection.
function isPromise(value) {
  return typeof value === 'object' && typeof value.then === 'function';
}
