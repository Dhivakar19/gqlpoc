import * as React from 'react';
import * as classNames from 'classnames';

import './LoadingAnimation.css';


import RamcoIcon from '../icons/ramco-icon.svg';

interface LoadingAnimationProps {
  loading: boolean;
}

export default class LoadingAnimation extends React.Component<
  LoadingAnimationProps
> {
  render() {
    const { loading } = this.props;
    return (
      <div className={classNames({ 'loading-box': true, visible: loading })}>
        <span className="loading-animation">
          <RamcoIcon />
          <h1> Ramco Broadcast... </h1>
        </span>
      </div>
    );
  }
}
